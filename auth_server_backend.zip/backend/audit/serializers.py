from rest_framework import serializers
from .models import AuditLogEntry
from roles.models import Application  # Adjust import based on your project structure


class AuditLogEntrySerializer(serializers.ModelSerializer):
    application = serializers.PrimaryKeyRelatedField(queryset=Application.objects.all())

    class Meta:
        model = AuditLogEntry
        fields = ['application', 'action_type', 'object_id', 'details']

    def validate(self, data):
        # Additional validation if needed
        return data

    def create(self, validated_data):
        # Assuming user is available in context
        user = self.context['request'].user  # Adjust based on your authentication setup

        audit_log = AuditLogEntry.objects.create(
            user=user,
            action_type=validated_data['action_type'],
            object_id=validated_data['object_id'],
            application=validated_data['application'],
            details=validated_data.get('details'),
        )
        return audit_log


class AuditLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuditLogEntry
        fields = ['id', 'user', 'application', 'action_type', 'timestamp', 'object_id', 'object_type', 'details']
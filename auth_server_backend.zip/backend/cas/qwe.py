from django.shortcuts import render
from rest_framework.views import APIView
from audit.utils import *
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.response import Response
from rest_framework import status
from .serializers import *
from django.contrib.auth import update_session_auth_hash
from rest_framework_simplejwt.views import TokenRefreshView,TokenObtainPairView
from django.shortcuts import redirect
from rest_framework import generics


# Create your views here.

#
# class LoginAPIView(APIView):
#     serializer_class = LoginSerializer
#
#     def post(self, request, *args, **kwargs):
#         serializer = self.serializer_class(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         user = serializer.validated_data['user']
#
#         log_audit_entry(user, Application.objects.get(name=''), 'Login', user.id, 'User Login')
#
#         refresh = RefreshToken.for_user(user)
#         token = {
#             'refresh': str(refresh),
#             'access': str(refresh.access_token),
#         }
#
#         return Response(token, status=status.HTTP_200_OK)
#


#
# class LoginAPIView(TokenObtainPairView):
#     serializer_class = LoginSerializer
#
#     def post(self, request, *args, **kwargs):
#         serializer = self.get_serializer(data=request.data)
#         serializer.is_valid(raise_exception=True)
#         user = serializer.validated_data['user']
#         roles = serializer.validated_data['roles']
#
#         # Create JWT token
#         token_response = super().post(request, *args, **kwargs)
#         token_response.data['roles'] = roles  # Add roles to response data
#         return Response(token_response.data, status=status.HTTP_200_OK)




class LoginView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        application_id = request.data.get('application_id')

        if not username or not password or not application_id:
            return Response({"error": "Username, password, and  service ID are required."},
                            status=status.HTTP_400_BAD_REQUEST)
        user = authenticate(username=username, password=password)
        if not user:
            return Response({"error": "Invalid credentials."}, status=status.HTTP_401_UNAUTHORIZED)

        try:
            application = Application.objects.get(id=application_id, active=True)
        except Application.DoesNotExist:
            return Response({"error": "Invalid or inactive service."}, status=status.HTTP_400_BAD_REQUEST)

        ticket = Ticket.objects.create_ticket(user=user, application=application)


        return Response({
            "ticket": ticket.ticket,
            "expires": ticket.expires.isoformat(),
        }, status=status.HTTP_200_OK)






""" Added this new part for logout """
class LogoutAPIView(APIView):
    def post(self,request,*args,**kwargs):
        refresh_token = request.data.get('refresh')

        if refresh_token:
            try:
                token = RefreshToken(refresh_token)
                token.blacklist()
                user = request.user

                log_audit_entry(user,Application.objects.get(name='Your cas Application'), 'Logout',user.id, 'user logout')

                return redirect('login/')

            except Exception as e:
                return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)

        return Response({'detail':'Refresh token is missing'})



class CustomTokenRefreshView(TokenRefreshView):
    pass


class ChangePasswordAPIView(APIView):
    serializer_class = ChangePasswordSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = request.user
        new_password = serializer.validated_data['new_password']

        user.set_password(new_password)
        user.save()
        update_session_auth_hash(request, user)  # Keep the user logged in after password change

        return Response({'message': 'Password updated successfully.'}, status=status.HTTP_200_OK)


class CreateTicketAPIView(APIView):
    def post(self, request, *args, **kwargs):
        service_id = request.data.get('service_id')
        try:
            service = Service.objects.get(id=service_id)
        except Service.DoesNotExist:
            return Response({'error': 'Service not found'}, status=status.HTTP_404_NOT_FOUND)

        ticket = Ticket.objects.create_ticket(user=request.user, service=service)
        serializer = TicketSerializer(ticket)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class ValidateTicketAPIView(APIView):
    def post(self, request, *args, **kwargs):
        ticket_str = request.data.get('ticket')
        service_id = request.data.get('service_id')

        try:
            service = Service.objects.get(id=service_id)
        except Service.DoesNotExist:
            return Response({'error': 'Service not found'}, status=status.HTTP_404_NOT_FOUND)

        try:
            ticket = Ticket.objects.validate_ticket(ticket_str, service)
            return Response({'valid': True, 'message': 'Ticket is valid.'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'valid': False, 'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class ConsumeTicketAPIView(APIView):
    def post(self, request, *args, **kwargs):
        ticket_str = request.data.get('ticket')
        try:
            ticket = Ticket.objects.get(ticket=ticket_str)
            if ticket.is_consumed:
                return Response({'message': 'Ticket already consumed.'}, status=status.HTTP_400_BAD_REQUEST)
            ticket.consume()
            return Response({'message': 'Ticket marked as consumed.'}, status=status.HTTP_200_OK)
        except Ticket.DoesNotExist:
            return Response({'error': 'Ticket not found'}, status=status.HTTP_404_NOT_FOUND)


class ServiceListCreateAPIView(generics.ListCreateAPIView):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer

class ServiceRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer


class IssuePGTAPIView(APIView):
    def post(self, request, *args, **kwargs):
        service_ticket_str = request.data.get('service_ticket')
        try:
            service_ticket = ServiceTicket.objects.get(ticket=service_ticket_str)
            pgt = ProxyGrantingTicket.objects.create_ticket(user=request.user, service=service_ticket.service)
            pgt.iou = f"PGTIOU-{int(timezone.time())}"
            pgt.save()
            return Response({'ticket': pgt.ticket, 'iou': pgt.iou}, status=status.HTTP_201_CREATED)
        except ServiceTicket.DoesNotExist:
            return Response({'error': 'Service Ticket not found'}, status=status.HTTP_404_NOT_FOUND)


# class LogoutAPIView(APIView):
#     def post(self, request, *args, **kwargs):
#         try:
#             refresh_token = request.data.get('refresh_token')
#             token = RefreshToken(refresh_token)
#             token.blacklist()  # Blacklist the refresh token
#             return Response({'message': 'Logged out successfully.'}, status=status.HTTP_200_OK)
#         except Exception as e:
#             return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

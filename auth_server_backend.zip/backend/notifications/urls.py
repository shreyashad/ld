from django.urls import path
from .views import *

urlpatterns = [
    path('notifications/', NotificationListView.as_view(), name='notification-list'),
    path('notifications/<int:pk>/', NotificationDetailView.as_view(), name='notification-detail'),
    path('notifications/<int:pk>/update/', NotificationUpdateView.as_view(), name='notification-update'),
    path('notifications/<int:pk>/delete/', NotificationDeleteView.as_view(), name='notification-delete'),
    path('notifications/<int:pk>/mark-as-read/', MarkNotificationAsReadView.as_view(),
         name='notification-mark-as-read'),
]

from import_export.admin import ImportExportModelAdmin
from django.contrib import admin
from .models import *
# Register your models here.


@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    list_display = ('name', 'org_type')



@admin.register(OrganizationSubType)
class OrganizationSubTypeAdmin(admin.ModelAdmin):
    list_display = ('org_type', 'subtype')


@admin.register(Locations)
class LocationAdmin(ImportExportModelAdmin,admin.ModelAdmin):
    list_display = ('org_type', 'org_name','location_type','location_name')


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ['name']


@admin.register(Designation)
class DesignationAdmin(admin.ModelAdmin):
    list_display = ['name']

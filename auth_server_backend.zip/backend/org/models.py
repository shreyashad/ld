from django.db import models
from accounts.models import BaseModel
# Create your models here.

class OrgType(models.TextChoices):
    MDINDIA = 'MDIndia', 'MDIndia'
    INSURANCE_COMPANY = 'Insurance Company', 'Insurance Company'
    BROKER = 'Broker', 'Broker'
    CORPORATE = 'Corporate', 'Corporate'

class LocationType(models.TextChoices):
    HO = 'HO', 'HO'
    RO = 'RO', 'RO'
    DO = 'DO', 'DO'
    UO = 'UO', 'UO'
    BRANCH = 'Branch', 'Branch'


class Organization(BaseModel):
    name = models.CharField(max_length=250,unique=True)
    org_type = models.CharField(max_length=150,choices=OrgType.choices)

    class Meta:
        verbose_name = "Organization"
        verbose_name_plural = "Organizations"


    def __str__(self):
        return f"{self.org_type} - {self.name}"


class OrganizationSubType(BaseModel):
    org_type = models.CharField(max_length=150, choices=OrgType.choices)
    subtype = models.CharField(max_length=250, unique=True)



    class Meta:
        verbose_name = "Organization Sub Type"
        verbose_name_plural = "Organization Sub Types"

    def __str__(self):
        return self.subtype


class Locations(BaseModel):
    org_type = models.CharField(max_length=150, choices=OrgType.choices)
    org_name = models.CharField(max_length=250, )
    location_type = models.CharField(max_length=150, choices=LocationType.choices)
    location_name = models.CharField(max_length=250)
    location_code = models.CharField(max_length=150)

    class Meta:
        verbose_name = "Location"
        verbose_name_plural = "Locations"

    def __str__(self):
        return f"{self.org_type}- {self.location_name}"


class Department(BaseModel):
    name = models.CharField(max_length=250, unique=True)

    class Meta:
        verbose_name = "Department"
        verbose_name_plural = "Departments"

    def __str__(self):
        return self.name


class Designation(BaseModel):
    name = models.CharField(max_length=250, unique=True)

    class Meta:
        verbose_name = "Designation"
        verbose_name_plural = "Designations"


    def __str__(self):
        return self.name


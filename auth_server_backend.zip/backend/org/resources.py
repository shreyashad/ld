from import_export import resources, fields
from import_export.widgets import IntegerWidget, CharWidget
from .models import *
from accounts.models import CustomUser

from uuid import UUID

class UUIDWidget(CharWidget):
    def clean(self, value):
        # Attempt to convert the incoming string to a UUID
        if value:
            try:
                return UUID(value)
            except ValueError:
                raise ValueError(f"Invalid UUID value: {value}")
        return None



class LocationsResource(resources.ModelResource):
    created_by = fields.Field(
        column_name='created_by',
        attribute='created_by',
        widget=UUIDWidget()
    )
    updated_by = fields.Field(
        column_name='updated_by',
        attribute='updated_by',
        widget=UUIDWidget()
    )

    class Meta:
        model = Locations
        import_id_fields = ('id',)
        fields = (
            'id', 'org_type', 'org_name', 'location_type',
            'location_name', 'location_code', 'created_by', 'updated_by'
        )
        skip_unchanged = True
        report_skipped = True

    def before_import_row(self, row, **kwargs):
        # Convert string values to appropriate choices
        for field in ['org_type', 'location_type']:
            if row.get(field) in dict(Locations._meta.get_field(field).choices):
                row[field] = row.get(field)
            else:
                row[field] = None  # Handle invalid choices as needed

    def import_obj(self, instance, **kwargs):
        user_id = kwargs.pop('user_id', None)
        if user_id:
            user = CustomUser.objects.filter(id=user_id).first()
            if user:
                if not instance.pk:  # If instance is being created
                    instance.created_by = user
                instance.updated_by = user
        super().import_obj(instance, **kwargs)



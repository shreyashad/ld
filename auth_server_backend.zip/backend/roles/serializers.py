from rest_framework import serializers
from .models import *
from accounts.models import CustomUser, AuthenticatorFilterSettings


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id','username']  # Adjust fields as needed


class ApplicationSerializer(serializers.ModelSerializer):
    created_by = UserSerializer(read_only=True)
    updated_by = UserSerializer(read_only=True)

    class Meta:
        model = Application
        fields = ['id', 'name', 'description', 'base_url', 'active', 'created_at', 'updated_at', 'created_by',
                  'updated_by']

    def create(self, validated_data):
        # If you need custom logic on create
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # If you need custom logic on update
        return super().update(instance, validated_data)


class ApplicationSerializerForOthers(serializers.ModelSerializer):
    class Meta:
        model = Application
        fields = ['id', 'name']


class PermissionSerializer(serializers.ModelSerializer):
    created_by = UserSerializer(read_only=True)
    updated_by = UserSerializer(read_only=True)
    application = ApplicationSerializerForOthers(read_only=True)

    class Meta:
        model = Permission
        fields = ['id', 'name', 'description', 'application',  'created_at',
                  'updated_at', 'created_by', 'updated_by']

    def create(self, validated_data):
        # If you need custom logic on create
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # If you need custom logic on update
        return super().update(instance, validated_data)


class PermissionSerializerForOther(serializers.ModelSerializer):
    created_by = UserSerializer(read_only=True)
    updated_by = UserSerializer(read_only=True)
    application = ApplicationSerializerForOthers(read_only=True)

    class Meta:
        model = Permission
        fields = ['id', 'name', 'description', 'application',  'created_at',
                  'updated_at', 'created_by', 'updated_by']



class RoleSerializer(serializers.ModelSerializer):
    created_by = UserSerializer(read_only=True)
    updated_by = UserSerializer(read_only=True)
    application = ApplicationSerializerForOthers(read_only=True)
    permissions = PermissionSerializerForOther(many=True, read_only=True)

    class Meta:
        model = Role
        fields = ['id', 'name', 'description', 'application', 'permissions', 'created_at', 'updated_at', 'created_by',
                  'updated_by']

    def create(self, validated_data):
        # If you need custom logic on create
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # If you need custom logic on update
        return super().update(instance, validated_data)

class RoleSerializerForOthers(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ['id', 'name']

#
# class UserRoleSerializer(serializers.ModelSerializer):
#     created_by = UserSerializer(read_only=True)
#     updated_by = UserSerializer(read_only=True)
#     user = serializers.PrimaryKeyRelatedField(queryset=CustomUser.objects.all())
#     role = serializers.PrimaryKeyRelatedField(queryset=Role.objects.all())
#     application = serializers.PrimaryKeyRelatedField(queryset=Application.objects.all())
#
#     class Meta:
#         model = UserRole
#         fields = ['id', 'user', 'role', 'application',
#                   'created_at', 'updated_at', 'created_by', 'updated_by']
#
#     def create(self, validated_data):
#         # If you need custom logic on create
#         return super().create(validated_data)
#
#     def update(self, instance, validated_data):
#         # If you need custom logic on update
#         return super().update(instance, validated_data)


class UserRoleSerializerForDisplayList(serializers.ModelSerializer):
    created_by = UserSerializer(read_only=True)
    updated_by = UserSerializer(read_only=True)
    user = UserSerializer(read_only=True)
    role = RoleSerializerForOthers(read_only=True)
    application = ApplicationSerializerForOthers(read_only=True)

    class Meta:
        model = UserRole
        fields = ['id', 'user', 'role', 'application',
                  'created_at', 'updated_at', 'created_by', 'updated_by']


class UserRoleSerializer(serializers.ModelSerializer):
    user = serializers.UUIDField()  # Change this line
    role = serializers.UUIDField()
    application = serializers.UUIDField()
    class Meta:
        model = UserRole
        fields = ['id', 'user', 'role', 'application',
                  'created_at', 'updated_at', 'created_by', 'updated_by']

    def create(self, validated_data):
        print("Validated data:", validated_data)
        user_id = validated_data.get('user')
        print("Fetching user with ID:", user_id)
        role_id = validated_data.get('role')
        application_id = validated_data.get('application')

        # Validate that the IDs are provided and fetch related objects
        try:
            user = CustomUser.objects.get(id=user_id)
            role = Role.objects.get(id=role_id)
            application = Application.objects.get(id=application_id)
        except CustomUser.DoesNotExist:
            raise serializers.ValidationError("User does not exist.")
        except Role.DoesNotExist:
            raise serializers.ValidationError("Role does not exist.")
        except Application.DoesNotExist:
            raise serializers.ValidationError("Application does not exist.")

        # Create the UserRole instance
        user_role = UserRole.objects.create(
            user=user,
            role=role,
            application=application,
            created_by=self.context['request'].user,
            updated_by=self.context['request'].user
        )
        return user_role

    def update(self, instance, validated_data):
        # Optional: Implement custom update logic here if needed
        # Example: Update user, role, application if provided
        user_id = validated_data.get('user')
        role_id = validated_data.get('role')
        application_id = validated_data.get('application')

        if user_id:
            instance.user = CustomUser.objects.get(id=user_id)
        if role_id:
            instance.role = Role.objects.get(id=role_id)
        if application_id:
            instance.application = Application.objects.get(id=application_id)

        # Save the instance
        instance.save()
        return instance



class AssignRolesAuthServerSerializers(serializers.ModelSerializer):
    class Meta:
        model = UserRole
        fields = ['id', 'user', 'role', 'application',
                  'created_at', 'updated_at', 'created_by', 'updated_by']

        filter_org_type = serializers.BooleanField(required=False)
        filter_org_name = serializers.BooleanField(required=False)
        filter_org_sub_type = serializers.BooleanField(required=False)
        filter_location_type = serializers.BooleanField(required=False)
        filter_location_name = serializers.BooleanField(required=False)
        filter_department = serializers.BooleanField(required=False)

        # For Site Admin
        site_admin_application = serializers.PrimaryKeyRelatedField(queryset=Application.objects.all(), required=False)

    def create(self, validated_data):
        # Extract filter settings for Authenticator
        filters_data = {key: validated_data.pop(key) for key in
                        ['filter_org_type', 'filter_org_name', 'filter_org_sub_type',
                         'filter_location_type', 'filter_location_name', 'filter_department']
                        if key in validated_data}

        user_role = UserRole.objects.create(**validated_data)

        if validated_data['role'].name == 'Authenticator':
            AuthenticatorFilterSettings.objects.update_or_create(
                user=validated_data['user'],
                defaults=filters_data
            )
        elif validated_data['role'].name == 'Site Admin':
            SiteAdminFilterSettings.objects.update_or_create(
                user=validated_data['user'],
                application=validated_data['application']
            )

        return user_role

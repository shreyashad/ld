from django.db import models
from accounts.models import BaseModel, CustomUser
from django.db import models

# Create your models here.



class Team(BaseModel):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField(blank=True, null=True)
    users = models.ManyToManyField(
        CustomUser,
        through='TeamMembership',
        through_fields=('team', 'user')
    )

    def add_user(self, user, role='Member'):
        membership, created = TeamMembership.objects.get_or_create(
            user=user, team=self, role=role)

        if not created and membership.role != role:
            membership.role = role
            membership.save()

        return membership

    def remove_user(self, user):
        membership = TeamMembership.objects.filter(user=user, team=self)
        if membership.exists():
            membership.delete()
            return f"User {user.username} removed from {self.name}"
        else:
            return f"User {user.username} is not a member of {self.name}"


    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Team'
        verbose_name_plural = 'Teams'




class TeamMembership(BaseModel):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    role = models.CharField(max_length=50, choices=[
        ('Leader', 'Leader'),
        ('Member', 'Member'),

    ], default='Member')
    joined_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'team')

    def __str__(self):
        return f'{self.user.username} - {self.team.name} ({self.role})'

    def get_role_display(self):
        return dict(self._meta.get_field('role').choices).get(self.role, self.role)




class TeamInvite(BaseModel):
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    invited_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='invitations_sent')
    invitee = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='invitations_received')
    status = models.CharField(max_length=20, choices=[
        ('Pending', 'Pending'),
        ('Accepted', 'Accepted'),
        ('Declined', 'Declined'),
    ], default='Pending')
    sent_at = models.DateTimeField(auto_now_add=True)
    responded_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        verbose_name = 'Team Invite'
        verbose_name_plural = 'Team Invites'
        unique_together = ('team', 'invitee')

    def __str__(self):
        return f'Invite from {self.invited_by.username} to {self.invitee.username} for {self.team.name}'





class TeamNotification(BaseModel):
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    message = models.TextField()

    class Meta:
        verbose_name = 'Team Notification'
        verbose_name_plural = 'Team Notifications'

    def __str__(self):
        return f'Notification for {self.team.name} - {self.user.username}'

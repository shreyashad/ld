from rest_framework import serializers
from .models import *
from rest_framework.exceptions import ValidationError

# Serializer for TeamMembership (for adding and managing team members)
class TeamMembershipSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(queryset=CustomUser.objects.all())  # Default empty queryset
    role = serializers.ChoiceField(choices=[('Leader', 'Leader'), ('Member', 'Member')])
    joined_at = serializers.DateTimeField(read_only=True)

    class Meta:
        model = TeamMembership
        fields = ['user', 'role', 'joined_at']

    # def __init__(self, *args, **kwargs):
    #     # Access the request to get the user making the request
    #     request = kwargs.get('context', {}).get('request')
    #     if request and hasattr(request, 'user'):
    #         user = request.user
    #         department = user.department  # Assuming CustomUser has a `department` field
    #
    #         # Filter the queryset based on the user's department
    #         self.fields['user'].queryset = CustomUser.objects.filter(department=department)
    #
    #     super(TeamMembershipSerializer, self).__init__(*args, **kwargs)

    def create(self, validated_data):
        team = validated_data['team']
        user = validated_data['user']
        role = validated_data.get('role', 'Member')

        try:
            # The user ID should be a valid UUID string, which Django can convert into a UUID instance
            user_instance = CustomUser.objects.get(id=user)
        except CustomUser.DoesNotExist:
            raise ValidationError(f"User with ID {user} does not exist.")

        # Ensure unique team-user combination (user should not be added multiple times to the same team)
        membership, created = TeamMembership.objects.get_or_create(
            team=team, user=user_instance, defaults={'role': role}
        )
        if not created:
            membership.role = role  # Update the role if membership already exists
            membership.save()

        return membership

# Serializer for Team (for creating and updating teams)
class TeamSerializer(serializers.ModelSerializer):
    users = TeamMembershipSerializer(many=True, required=False)  # Users as members

    class Meta:
        model = Team
        fields = ['id', 'name', 'description', 'users']

    def create(self, validated_data):
        users_data = validated_data.pop('users', [])
        team = Team.objects.create(**validated_data)
        for user_data in users_data:
            TeamMembership.objects.create(team=team, **user_data)
        return team

    def update(self, instance, validated_data):
        users_data = validated_data.pop('users', None)
        instance.name = validated_data.get('name', instance.name)
        instance.description = validated_data.get('description', instance.description)
        instance.save()

        if users_data:
            # Update members
            for user_data in users_data:
                membership, created = TeamMembership.objects.get_or_create(
                    team=instance, user=user_data['user']
                )
                membership.role = user_data.get('role', membership.role)
                membership.save()
        return instance


class TeamSerializerList(serializers.ModelSerializer):
    users = serializers.SerializerMethodField()
    created_by_username = serializers.SerializerMethodField()
    updated_by_username = serializers.SerializerMethodField()
    member_count = serializers.SerializerMethodField()

    class Meta:
        model = Team
        fields = ['id', 'name', 'description', 'created_by', 'updated_by', 'users', 'created_by_username', 'updated_by_username', 'member_count']

    def get_users(self, obj):
        return [user.username for user in obj.users.all()]

    def get_created_by_username(self, obj):
        return obj.created_by.username if obj.created_by else None

    def get_updated_by_username(self, obj):
        return obj.updated_by.username if obj.updated_by else None

    def get_member_count(self, obj):
        # Count the number of members in the team
        return obj.users.count()






class TeamDetailSerializer(serializers.ModelSerializer):
    memberships = TeamMembershipSerializer(many=True, read_only=True)  # Nested serializer for memberships (users and roles)

    class Meta:
        model = Team
        fields = ['id', 'name', 'description', 'memberships']








#
# # Serializer for TeamInvite (for inviting users)
# class TeamInviteSerializer(serializers.ModelSerializer):
#     invitee = serializers.PrimaryKeyRelatedField(queryset=CustomUser.objects.all())
#     invited_by = serializers.PrimaryKeyRelatedField(queryset=CustomUser.objects.all())
#     team = serializers.PrimaryKeyRelatedField(queryset=Team.objects.all())
#
#     class Meta:
#         model = TeamInvite
#         fields = ['id', 'team', 'invited_by', 'invitee', 'status', 'sent_at', 'responded_at']
#
#
# # Serializer for TeamNotification (for team notifications)
# class TeamNotificationSerializer(serializers.ModelSerializer):
#     user = serializers.PrimaryKeyRelatedField(queryset=CustomUser.objects.all())
#     team = serializers.PrimaryKeyRelatedField(queryset=Team.objects.all())
#
#     class Meta:
#         model = TeamNotification
#         fields = ['id', 'team', 'user', 'message']
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#

#
# class TeamSerializer(serializers.ModelSerializer):
#     users = serializers.SerializerMethodField()
#     class Meta:
#         model = Team
#         fields = ['id','name', 'description','users','created_at', 'updated_at', 'created_by', 'updated_by',]
#     def get_users(self, obj):
#         return [user.id for user in obj.users.all()]
#
# class TeamMembershipSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = TeamMembership
#         fields = '__all__'
#
# class TeamInviteSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = TeamInvite
#         fields = '__all__'
#
# class TeamNotificationSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = TeamNotification
#         fields = '__all__'

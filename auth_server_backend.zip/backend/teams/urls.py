from django.urls import path

from .views import *

urlpatterns = [
    path('create-teams/', TeamCreateView.as_view(), name='create_teams'),
    path('teams-all-list/', AllTeamListView.as_view(), name='all_teams_list'),
    path('team-list-by-user/', TeamListByUserView.as_view(), name='user_related_teams_list'),
    path('team-list-by-role/', TeamListByRoleView.as_view(), name='role_related_teams_list'),
    path('teams/<uuid:pk>/details/',TeamDetailView .as_view(), name='team_details'),



    # path('teams-all-list/', AllTeamListAPIView.as_view(), name='team-all-list'),
    # path('users-teams-list/', UserTeamsView.as_view(), name='user-teams-list'),
    # path('createdby-team-list', CreatedTeamsView.as_view(), name='createdby-team-list'),
    # path('create-teams/',TeamCreateAPIView.as_view(), name='teams-create'),
    # path('teams/<uuid:pk>/details/', TeamRetrieveUpdateDestroyAPIView.as_view(), name='team-retrieve-update-destroy'),
    # path('teams/<uuid:pk>/members/', TeamMembersAPIView.as_view(), name='team-members'),
    #
    # path('team-memberships/', TeamMembershipListCreateAPIView.as_view(), name='team-membership-list-create'),
    # path('team-memberships/<uuid:pk>/', TeamMembershipRetrieveUpdateDestroyAPIView.as_view(), name='team-membership-retrieve-update-destroy'),
    #
    # path('team-invites/', TeamInviteListCreateAPIView.as_view(), name='team-invite-list-create'),
    # path('team-invites/<uuid:pk>/respond/', TeamInviteRetrieveUpdateDestroyAPIView.as_view(), name='team-invite-respond'),
    #
    # path('team-notifications/', TeamNotificationListCreateAPIView.as_view(), name='team-notification-list-create'),
    # path('team-notifications/<uuid:pk>/', TeamNotificationRetrieveUpdateDestroyAPIView.as_view(), name='team-notification-retrieve-update-destroy'),
]
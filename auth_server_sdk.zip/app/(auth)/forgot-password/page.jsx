"use client";
import { getpasswordResetRequest } from "@/app/api/server/route";
import { Button } from "@/components/ui/button";
import { Card, CardTitle, CardDescription, CardHeader, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PhoneInput } from "@/components/ui/phone-input";
import { PasswordResetRequestSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";

export default function PasswordResetRequest() {
  const [message, setMessage] = useState('');
  const [token, setToken] = useState('');
  const router = useRouter();

  const {
    register, // Added back the register function
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(PasswordResetRequestSchema),
  });

  const onSubmit = async (data) => {
    const formData = new FormData();
    formData.append('username', data.username);
    formData.append('emp_code', data.emp_code);
    formData.append('mobile', data.mobile);

    const result = await getpasswordResetRequest(formData);
    if (result.token) {
      setToken(result.token); // Store token for use in password reset
      setMessage('Password reset token generated. Use the token to reset your password.');
      router.push(`/forgot-password/password-reset?token=${result.token}`);
    } else {
      setMessage(result.error || 'An error occurred. Please try again.');
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto mt-40">
      <CardHeader>
        <CardTitle>Reset Password</CardTitle>
        <CardDescription>Enter your username, mobile number, and employee code to reset your password.</CardDescription>
      </CardHeader>
      <CardContent>
        <form className="space-y-4" onSubmit={handleSubmit(onSubmit)}>
          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              type="text"
              placeholder="Enter your username"
              {...register('username')} // Register input with react-hook-form
              required
            />
            {errors.username && <p className="text-red-500">{errors.username.message}</p>}
          </div>
          <div className="space-y-2">
            <Label htmlFor="mobile">Mobile Number</Label>
            {/* <PhoneInput 
              id="mobile"
              type="tel"
              placeholder="Enter your mobile number"
              {...register('mobile')} // Register input with react-hook-form
              required
            /> */}
            
            
            <Input
              id="mobile"
              type="tel"
              placeholder="Enter your mobile number"
              {...register('mobile')} // Register input with react-hook-form
              required
            />
            {errors.mobile && <p className="text-red-500">{errors.mobile.message}</p>}
          </div>
          <div className="space-y-2">
            <Label htmlFor="emp_code">Employee Code</Label>
            <Input
              id="emp_code"
              type="text"
              placeholder="Enter your employee code"
              {...register('emp_code')} // Register input with react-hook-form
              required
            />
            {errors.emp_code && <p className="text-red-500">{errors.emp_code.message}</p>}
          </div>
          <Button type="submit" className="w-full">
            Reset Password
          </Button>
        </form>
        <div className="mt-4 text-center text-sm">
                            Don&apos;t have an account?{" "}
                            <Link href="/register" className="underline">Sign Up</Link>
                        </div>
        {message && <p className="text-red-500 mt-4">{message}</p>}
      </CardContent>
    </Card>
  );
}

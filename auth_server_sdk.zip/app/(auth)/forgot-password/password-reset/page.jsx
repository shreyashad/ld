"use client";
import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardTitle, CardDescription, CardHeader, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getResetPassword } from "@/app/api/server/route";
import Link from "next/link";

export default function PasswordResetView() {
  const [message, setMessage] = useState("");
  const [passwords, setPasswords] = useState({
    new_password: "",
    confirm_password: "",
  });
  const searchParams = useSearchParams();
  const token = searchParams.get('token'); // Get token from query parameters

  const router = useRouter();

  const handleChange = (e) => {
    setPasswords({ ...passwords, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    if (passwords.new_password !== passwords.confirm_password) {
      setMessage("Passwords do not match.");
      return;
    }

    try {
      const result = await getResetPassword({
        token: token,
        new_password: passwords.new_password,
        confirm_password: passwords.confirm_password,  // Include confirm_password in the payload
      });

      if (result.status === "Password reset successful") {
        setMessage("Password has been reset successfully.");
        router.push("/login");  // Redirect to login page after success
      } else {
        setMessage(result.error || "Password reset failed.");
      }
    } catch (error) {
      setMessage("An error occurred during the password reset.");
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto mt-40">
      <CardHeader>
        <CardTitle>Reset Your Password</CardTitle>
        <CardDescription>Please enter your new password and confirm it.</CardDescription>
      </CardHeader>
      <CardContent>
        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="token">Token</Label>
            <Suspense>
             <Input id="token" type="text" value={token} readOnly />
            </Suspense>
          </div>
          <div className="space-y-2">
            <Label htmlFor="new_password">New Password</Label>
            <Input
              id="new_password"
              name="new_password"
              type="password"
              placeholder="Enter your new password"
              value={passwords.new_password}
              onChange={handleChange}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="confirm_password">Confirm Password</Label>
            <Input
              id="confirm_password"
              name="confirm_password"
              type="password"
              placeholder="Confirm your new password"
              value={passwords.confirm_password}
              onChange={handleChange}
              required
            />
          </div>
          <Button type="submit" className="w-full">
            Reset Password
          </Button>
        </form>
        <div className="mt-4 text-center text-sm">
                            Get back to {" "}
                            <Link href="/login" className="underline">Sign In</Link>
                            
                        </div>
        {message && <p>{message}</p>}
      </CardContent>
    </Card>
  );
}

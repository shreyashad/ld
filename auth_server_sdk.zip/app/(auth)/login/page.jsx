"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { signIn, useSession } from "next-auth/react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function LoginPage() {
    const [formData, setFormData] = useState({
        username: '',
        password: '',
    });

    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [roleMessage, setRoleMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { data: session, status } = useSession();
    const router = useRouter();

    useEffect(() => {
        if (status === 'loading') return; // Wait for session to load

        if (session?.user) {
            // Check user role and redirect accordingly
            const userRole = session.user.roles; // Adjust according to how roles are provided
            
            if (!userRole) {
                setRoleMessage("User role not found. Please contact support.");
                return;
            }

            switch (userRole) {
                case "Administrator":
                    router.push("/dashboard/administrator");
                    break;
                case "Authenticator":
                    router.push("/dashboard/authenticator");
                    break;
                case "Site Admin":
                    router.push("/dashboard/site-admin");
                    break;
                default:
                    router.push("/");
            }
        }
    }, [session, status, router]);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setIsLoading(true);
        setErrorMessage('');
        setSuccessMessage('');
        setRoleMessage('');
        
        const { username, password } = formData;
        // const data = { username, password };
        
        try {
            const result = await signIn('credentials', {
                username,
                password,
                redirect: false,
            });

            if (result?.error) {
                setErrorMessage(result.error);
                console.log("this is the error message:",result.error);
            } else {
                setSuccessMessage("Login successful. Redirecting...");
                // setTimeout(() => {
                router.reload(); // Trigger session reload after successful sign-in
                // }, 1000); 
            }
        } catch (error) {
            console.error('Login error:', error.response ? error.response.data : error.message);
            setErrorMessage(error.message || 'An unexpected error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleChange = (event) => {
        setFormData({ ...formData, [event.target.name]: event.target.value });
    };

    return (
        <div className="w-full lg:grid lg:min-h-[500px] lg:grid-cols-2 xl:min-h-[600px]">
            <div className="flex items-center justify-center py-10">
                <Card className="mx-auto max-w-sm">
                    <CardHeader>
                        <CardTitle className="text-2xl text-center">Login</CardTitle>
                        <CardDescription>
                            Enter your credentials below to login to your account
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid gap-4">
                            {(errorMessage || successMessage || roleMessage) && (
                                <div
                                    className={`${
                                        errorMessage || roleMessage ? 'bg-red-100 border border-red-400 text-red-700' : 'bg-green-100 border border-green-400 text-green-700'
                                    } px-4 py-3 rounded relative`}
                                    role="alert"
                                >
                                    <strong className="font-bold">{errorMessage ? 'Error:' : 'Success:'} </strong>
                                    <span className="block sm:inline">{errorMessage || successMessage || roleMessage}</span>
                                </div>
                            )}
                            <form onSubmit={handleSubmit}>
                                <div className="grid gap-2">
                                    <Label>Username</Label>
                                    <Input 
                                        type="text"
                                        id="username"
                                        name="username"
                                        value={formData.username}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <div className="grid gap-2">
                                    <div className="flex items-center">
                                        <Label>Password</Label>
                                        <Link href="/forgot-password" className="ml-auto inline-block text-sm underline">
                                            Forgot password?
                                        </Link>
                                    </div>
                                    <Input
                                        type="password"
                                        id="password"
                                        name="password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                <Button type="submit" className="w-full mt-4">Login</Button>
                            </form>
                        </div>
                        <div className="mt-4 text-center text-sm">
                            Don&apos;t have an account?{" "}
                            <Link href="/register" className="underline">Sign Up</Link>
                        </div>
                    </CardContent>
                </Card>
            </div>
            <div className="hidden bg-muted lg:block">
                <Image
                    src="/boy-with-rocket-light.png"
                    alt="Image"
                    width="1920"
                    height="1080"
                    className="h-full w-full object-cover dark:brightness-[0.2] dark:grayscale"
                />
            </div>
        </div>
    );
}

import { fetchApplicationListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import ApplicationClient from "@/components/admin/applications/application-client";
import { ApplicationColumns } from "@/components/admin/applications/application-columns";
import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";



export default async function ApplicationManagement() {
    const session = await auth();
    console.log("sesiion deatisl:" ,session.accessToken);
    
    const appData = await fetchApplicationListData(session.accessToken);
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb
                homelink="administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="administrator/application-management/"
                mdipagetitle="Application Management"
                pagetitle="Applicaion"
            />
            
            <ApplicationClient />
            <Separator />
            <div>
                <DataTable columns={ApplicationColumns} data={appData} />
            </div>
        </div>
    );
}

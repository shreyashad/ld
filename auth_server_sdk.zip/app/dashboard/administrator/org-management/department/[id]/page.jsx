import { fetchDepartmentDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DepartmentForm } from "@/components/admin/department/department-form";

function getDeptId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode dept ID');
        return data;
    }
}

export default async function EditDepartment({ params }) {
    const { id } = params;
    console.log("params details:", id);
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    let deptData = null;

    if (id === "new") {
        // Handle the case for creating a new organization
        deptData = {}; // Pass an empty object for a new organization
    } else {
        // Handle the case for editing an existing organization
        const deptId = getDeptId(id);
        deptData = await fetchDepartmentDetails(deptId, session.accessToken);
    }

    return (
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
                <DepartmentForm initialData={deptData || {}} />
            </div>
        </div>
    );

};
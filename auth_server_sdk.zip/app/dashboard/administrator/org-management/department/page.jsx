import { fetchDepartmentListData} from "@/app/api/server/route";
import { auth } from "@/auth";
import DepartmentClient from "@/components/admin/department/department-client";
import { DepartmentColumns } from "@/components/admin/department/department-columns";
import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";



export default async function DepartmentManagement() {
    const session = await auth();
    console.log("sesiion deatisl:" ,session.accessToken);
    
    const departmentData = await fetchDepartmentListData(session.accessToken);
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb
                homelink="administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="administrator/org-management/"
                mdipagetitle="Organization Management"
                pagetitle="Department"
            />
            
            <DepartmentClient />
            <Separator />
            <div>
                <DataTable columns={DepartmentColumns} data={departmentData} />
            </div>
        </div>
    );
}

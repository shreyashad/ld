import { fetchDesignationDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DesignationForm } from "@/components/admin/designation/designation-form";

function getDesigId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode designation ID');
        return data;
    }
}

export default async function EditDesignation({ params }) {
    const { id } = params;
    console.log("params details: ", id);
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    let designationData = null;
    if (id === "new") {
        designationData = {};
    } else {
        const designId = getDesigId(id);
        designationData = await fetchDesignationDetails(designId, session.accessToken);
    }

    return (
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
                <DesignationForm initialData={designationData || {}} />
            </div>
        </div>
    );
};
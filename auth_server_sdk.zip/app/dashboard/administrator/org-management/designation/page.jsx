import { fetchDesignationListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import DesignationClient from "@/components/admin/designation/designation-client";
import { DesignationColumns } from "@/components/admin/designation/designation-columns";
import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";




export default async function DesignationsManagement() {
    const session = await auth();
    const desigData = await fetchDesignationListData(session.accessToken);

    return (
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb
                 homelink="/dashboard/administrator"
                 hometitle="Dashboard"
                 mdipagelink="/dashboard/administrator/org-management/"
                 mdipagetitle="Organization Management"
                 pagetitle="Designation"
            />
            
            <DesignationClient />
            <Separator />
            <div>
                <DataTable columns={DesignationColumns} data={desigData} />
            </div>
        </div>
    );
};
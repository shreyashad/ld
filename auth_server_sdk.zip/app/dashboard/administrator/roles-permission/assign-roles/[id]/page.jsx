import { fetchUserRolesDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { UserRoleForm } from "@/components/admin/assigned-role/assigned-role-form";

function getUserRoleId(data) {
    try {
       return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode User ID');
        return data;
    }
}

export default async function EditUserRole({ params }) {
    const { id } = params; // Get the organization ID from params
    console.log("params details: ", id);
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    let userRoleData = null;

    if (id === "new") {
        // Handle the case for creating a new organization
        userRoleData = {}; // Pass an empty object for a new organization
    } else {
        // Handle the case for editing an existing organization
        const UserRoleId = getUserRoleId(id);
        console.log('UserIdUserIdUserId',UserRoleId)
        userRoleData = await fetchUserRolesDetails(session.accessToken, UserRoleId,);
        console.log("user assigned roles details:", userRoleData);
    }

    return (
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
                <UserRoleForm initialData={userRoleData || {}} />
            </div>
        </div>
    );
};

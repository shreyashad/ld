import { fetchApplicationdetails, fetchAuthServerUserRolesDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { AuthServerUserRoleForm } from "@/components/admin/assign-role-auth-server/auth-server-user-form";

function getAuthServerUserRoleId(data) {
    try {
        return decodeURIComponent(data);
     } catch (error) {
         console.error('Failed to decode User ID');
         return data;
     }
}

export default async function EditAuthServerUserRole({ params }) {
    const { id } = params;
    const session = await auth();
    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    let authServerUserRoleData = null;

    if (id=== "new") {
        authServerUserRoleData = {};
    } else {
        const AuthServerUserRoleId = getAuthServerUserRoleId(id);
        authServerUserRoleData = await fetchAuthServerUserRolesDetails(session.accessToken, AuthServerUserRoleId)
    }

    const defaultApplicationId = await fetchApplicationdetails();
    return(
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
                <AuthServerUserRoleForm initialData={ authServerUserRoleData || {}} 
                    defaultApplicationId={defaultApplicationId.app.id}
                />
            </div>
        </div>
    );
}
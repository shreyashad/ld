
import { fetchAuthServerUserRolesListData} from "@/app/api/server/route";
import { auth } from "@/auth";
import AuthServerUserRoleClient from "@/components/admin/assign-role-auth-server/auth-server-user-client";
import { AuthServerUserRoleColumns } from "@/components/admin/assign-role-auth-server/auth-server-user-columns";
import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";



export default async function AuthServerUserRoleManagement() {
    const session = await auth();
    const userroledata = await fetchAuthServerUserRolesListData(session.accessToken);
    console.log("userroledata:",userroledata);
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb
                homelink="/dashboard/administrator"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/roles-permission/auth-server-roles"
                mdipagetitle="Roles & Permissions"
                pagetitle="Auth Server User Roles"
            />
            
            <AuthServerUserRoleClient />
            <Separator />
            <div>
                <DataTable columns={AuthServerUserRoleColumns} data={userroledata} />
            </div>
        </div>
    );
}

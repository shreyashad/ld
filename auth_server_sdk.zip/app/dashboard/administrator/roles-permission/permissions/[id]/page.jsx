import { fetchPermissionDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { PermissionForm } from "@/components/admin/permissions/permission-form";

function getPermissionId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode org ID');
        return data;
    }
}

export default async function EditPermissions({ params }) {
    const { id } = params; // Get the organization ID from params
    console.log("params details: ", id);
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    let permissionData = null;

    if (id === "new") {
        // Handle the case for creating a new organization
        permissionData = {}; // Pass an empty object for a new organization
    } else {
        // Handle the case for editing an existing organization
        const permissionId = getPermissionId(id);
        permissionData = await fetchPermissionDetails(permissionId, session.accessToken);
    }
    return (
        <div className="flex flex-col">
            <div className="flex-1 space-y-4 p-4 md:p-8">
                <PermissionForm initialData={permissionData || {}} />
            </div>
        </div>
    );
}
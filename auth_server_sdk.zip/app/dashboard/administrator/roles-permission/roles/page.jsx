import { fetchRolesListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import RolesClient from "@/components/admin/roles/roles-client";
import { RolesColumns } from "@/components/admin/roles/roles-columns";
import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";





export default async function RolesManagement() {
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
    }

    const rolesData = await fetchRolesListData(session.accessToken);
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb
                homelink="/dashboard/administrator/dashboard"
                hometitle="Dashboard"
                mdipagelink="/dashboard/administrator/roles-permission/roles"
                mdipagetitle="Roles & Permissions"
                pagetitle="Roles"
            />
            <RolesClient />
            <Separator />
            <div>
                <DataTable columns={RolesColumns} data={rolesData} />
            </div>
        </div>
    );
}
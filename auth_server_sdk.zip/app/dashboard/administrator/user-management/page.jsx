"use server";
import { fetchAdminUserCount, fetchAuthenticatorCount, fetchPendingVerificationCount, fetchSiteAdminCount, fetchUserListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import UserClient from "@/components/admin/user-management/user-client";
import { UserColumns } from "@/components/admin/user-management/user-columns";
import { MyBreadCrumb } from "@/components/dashboard/mybreadcrumb";
import StatsCard from "@/components/dashboard/stats-card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";



export default async function UserManagement() {
    const session = await auth();

    if (!session) {
        return new Response("Unauthorized", { status: 401 });
      }
      
    const userdata = await fetchUserListData(session.accessToken);
    const adminuser = await fetchAdminUserCount(session.accessToken);
    const authenticatoruser = await fetchAuthenticatorCount(session.accessToken);
    const siteadminuser = await fetchSiteAdminCount(session.accessToken);
    const unverifiedUser = await fetchPendingVerificationCount(session.accessToken);
    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <MyBreadCrumb
                 homelink="/dashboard/administrator"
                 hometitle="Dashboard"
                 mdipagelink="/dashboard/administrator/user-management/"
                 mdipagetitle="User Management"
                 pagetitle="Users"
            />
            <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-4">
                <StatsCard title="Total Administrator" value={adminuser.admin_user} description="Total number of user that are been registered" />
                <StatsCard title="Total Authenticator" value={authenticatoruser.authenticator_user} description="Total number of Active user"  />
                <StatsCard title="Total Site Admin" value={siteadminuser.siteadmin_user} description="Total number of application been registered" />
                <StatsCard title="Pending Verifications" value={unverifiedUser.unverified_users} description="Total number of user pending for verifications"  /> 
            </div>
            <UserClient />
            <Separator />
            <div>
                <DataTable columns={UserColumns} data={userdata} />
            </div>
        </div>
    );
}
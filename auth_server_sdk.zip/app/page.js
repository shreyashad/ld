import Image from "next/image";
import LoginPage from "./(auth)/login/page";


export const metadata = {
  title: "MDIndia CAS",
  description: "Login page for CAS application",
};


export default function Home() {
  return (
    
      <LoginPage />
    
  );
}

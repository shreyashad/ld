import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { fetchApplicationdetails, validateTicket } from "./app/api/server/route";
import axios from "axios";


const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";


export const { handlers, signIn, signOut, auth } = NextAuth({
    providers: [
        CredentialsProvider({
            name: 'Credentials',
            credentials: {
                username: { label: "Username", type: "text" },
                password: { label: "Password", type: "password" },
               
            },
            async authorize(credentials) {
                try {
                  const application = await fetchApplicationdetails();
                  const applicationId = application.app.id;
              
                  const response = await axios.post(`${API_BASE_URL}api/login/`, {
                      username: credentials.username,
                      password: credentials.password,
                      application_id: applicationId,
                  });
                  
                  if (response.status !== 200) {
                    throw new Error("Invalid credentials or application issue");
                  }
              
                  const user = response.data;
                  const userDetails = await validateTicket(user.service_ticket , applicationId);
                  
                  
                  if (userDetails) {
                      return {
                          id: userDetails.id || user.id,
                          roles: userDetails.roles,
                          permissions: userDetails.permissions,
                          profile_picture: userDetails.profile_picture,
                          first_name: userDetails.first_name,
                          last_name: userDetails.last_name,
                          org_type: userDetails.org_type,
                          org_name: userDetails.org_name,
                          org_sub_type: userDetails.org_sub_type,
                          location_type: userDetails.location_type,
                          location_name: userDetails.location_name,
                          location_code: userDetails.location_code,
                          emp_code: userDetails.emp_code,
                          department: userDetails.department,
                          designation: userDetails.designation,
                          accessToken: user.access, // Ensure token is passed
                          refreshToken: user.refresh,
                          sessionKey: user.session_key,
                          service_ticket: user.service_ticket, 
                          sessionExp: new Date(user.session_expires_at).getTime(),
                      };
                  } else {
                    throw new Error("Invalid service ticket");
                  }
                } catch (error) {
                    let  errorMessage = error.response?.data?.error || error.message;
                    console.error('Authentication failed:', errorMessage);
                    throw new Error(getCustomErrorMessage(errorMessage));
                    // const errorMessage = error.response?.data
                    // console.error('Authentication failed:', error.response?.data?.error || error.message);
                    // throw new Error(error.response?.data?.error || "Authentication failed");
                }
            },
              
        }),
    ],
    pages: {
        signIn: '/login',
    },
    callbacks: {
       
        async jwt({ token, user }) {
            if (user) {
                token.accessToken = user.accessToken;
                token.refreshToken = user.refreshToken;
                token.sessionKey = user.sessionKey;
                token.sessionExp = user.sessionExp;
                token.user = user;
            }
            
            if (Date.now() > token.sessionExp) {
                try {
                    const response = await axios.post(`${API_BASE_URL}api/token/refresh/`, {
                        refresh: token.refreshToken,
                    });

                    if (response.status === 200) {
                        token.accessToken = response.data.access;
                        token.refreshToken = response.data.refresh;
                        token.sessionExp = Date.now() + (60 * 60 * 1000); // Update expiration time
                    } else {
                        throw new Error("Token refresh failed");
                    }
                } catch (error) {
                    console.error("Error refreshing token:", error);
                    throw new Error("Session expired, please log in again.");
                  // Optionally, you might want to clear the tokens or redirect to sign-in
              }
            }
            return token;
          },
          
          async session({ session, token }) {
              if (!token || !token.accessToken) {
                  // If there's no valid token, handle it as expired
                  session.error = "Session expired, please log in again.";
                  return session;
              }

              session.accessToken = token.accessToken;
              session.refreshToken = token.refreshToken;
              session.sessionKey = token.sessionKey;
              session.sessionExp = token.sessionExp;
              session.user = token.user
              console.log("user session details:", session);
              return session;
          }
          
          // async session({ session, token }) {
          //   session.accessToken = token.accessToken;
          //   session.refreshToken = token.refreshToken;
          //   session.sessionKey = token.sessionKey;
          //   session.sessionExp = token.sessionExp;
          //   session.user = token.user  // This should match the structure returned in `jwt`
          
           
          //   console.log("user session details:", session);
          //   return session;

          // }
          
    },
    session: { 
      strategy: 'jwt'
    },
    server: {
      trustedHosts: ['localhost:3000']
    },
});


function getCustomErrorMessage(errorMessage) {
    switch (errorMessage) {
        case "Invalid credentials":
            return "The username or password you entered is incorrect.";
        case "Invalid service ticket":
            return "Your session has expired. Please log in again.";
        case "Token refresh failed":
            return "Failed to refresh your session. Please log in again.";
        case "Network Error": // Example case for network errors
            return "Please check your internet connection.";
        default:
            return "An unexpected error occurred. Please try again.";
    }
}
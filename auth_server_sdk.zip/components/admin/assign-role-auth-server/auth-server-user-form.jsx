"use client";
import { createNewAuthServerUserRoles, fetchApplicationListData, fetchRolesListByApplication, fetchUserListData, updateAuthServerUserRolesDetails } from "@/app/api/server/route";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserRoleFormSchema } from "@/schemas";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { ScrollArea } from "@/components/ui/scroll-area";

export const AuthServerUserRoleForm = ({ initialData, defaultApplicationId }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const title = initialData?.id ? "Edit Auth Server User Role" : "Create Auth Server User Role";
    const toastMessage = initialData?.id ? "Auth Server User Role updated successfully" : "Auth Server User Role created successfully";
    const action = initialData?.id ? "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(UserRoleFormSchema),
        defaultValues: {
            application: defaultApplicationId || "",
            role: initialData?.role || "",
            user: initialData?.user || ""
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        console.log('Form submitted with values:', values);
        setLoading(true);
        try {
            if (initialData?.id) {
                await updateAuthServerUserRolesDetails(session.accessToken, initialData.id, values);
            } else {
                await createNewAuthServerUserRoles(session.accessToken, values);
            }
            toast.success(toastMessage);
            router.push('/dashboard/administrator/roles-permission/auth-server-roles');
        } catch (error) {
            toast.error(error.message);
        } finally {
            setLoading(false);
        }
    };

    const [userData, setUserData] = useState([]);
    const [roleData, setRoleData] = useState([]);
    const [applicationsData, setApplicationsData] = useState([]);
    const [selectedUser, setSelectedUser] = useState(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [isSearchFocused, setIsSearchFocused] = useState(false);
    const [searchResults, setSearchResults] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            if (session?.accessToken) {
                try {
                    const userRes = await fetchUserListData(session.accessToken);
                    const appRes = await fetchApplicationListData(session.accessToken);
                    const roleRes = await fetchRolesListByApplication(session.accessToken, defaultApplicationId);
                    setUserData(userRes);
                    setApplicationsData(appRes);
                    setRoleData(roleRes);
                } catch (error) {
                    toast.error("Error fetching data");
                }
            }
        };
        fetchData();
    }, [session]);

    useEffect(() => {
        if (searchTerm) {
            const results = userData.filter(user => user.username.toLowerCase().includes(searchTerm.toLowerCase()));
            setSearchResults(results);
        } else {
            setSearchResults([]);
        }
    }, [searchTerm, userData]);

    const handleUserSelect = (user) => {
        setSelectedUser(user);
        setSearchTerm(user.username);
        setIsSearchFocused(false);
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>
                    <DashHeading title={title} />
                    {initialData?.id && (
                        <Button
                            disabled={loading}
                            variant="destructive"
                            size="icon"
                            onClick={() => {/* Handle delete logic */}}
                        >
                            <Trash className="h-4 w-4" />
                        </Button>
                    )}
                </CardTitle>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid-cols-2 gap-8 md:grid">
                            <FormField
                                control={form.control}
                                name="role"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Roles</FormLabel>
                                        <FormControl>
                                            <Select
                                                onValueChange={(value) => {
                                                    field.onChange(value);
                                                }}
                                                value={field.value || ""}
                                                disabled={loading}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue placeholder="Select Role" />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {roleData.map((role) => (
                                                        <SelectItem key={role.id} value={role.name}>
                                                            {role.name}
                                                        </SelectItem>
                                                    ))}
                                                </SelectContent>
                                            </Select>
                                        </FormControl>
                                    </FormItem>
                                )}
                            />

                            <div className="space-y-2">
                                <FormField
                                    control={form.control}
                                    name="user"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel htmlFor="user-search">Search User</FormLabel>
                                            <FormControl>
                                                <Input
                                                    id="user-search"
                                                    type="text"
                                                    placeholder="Start typing to search users..."
                                                    value={searchTerm}
                                                    onChange={(e) => {
                                                        setSearchTerm(e.target.value);
                                                        field.onChange(e.target.value); // Update form state
                                                    }}
                                                    onFocus={() => setIsSearchFocused(true)}
                                                    onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                                                />
                                            </FormControl>
                                            {isSearchFocused && searchResults.length > 0 && (
                                                <ScrollArea className="h-[200px] w-full rounded-md border">
                                                    <div className="p-4">
                                                        {searchResults.map((user) => (
                                                            <div
                                                                key={user.id}
                                                                className="cursor-pointer p-2 hover:bg-gray-100 rounded"
                                                                onClick={() => handleUserSelect(user)}
                                                            >
                                                                {user.username}
                                                            </div>
                                                        ))}
                                                    </div>
                                                </ScrollArea>
                                            )}
                                        </FormItem>
                                    )}
                                />


                            {selectedUser && (
                                <div className="text-sm text-gray-500">
                                    Selected User: {selectedUser.username}
                                </div>
                            )}
                        </div>
                            {/* Conditional Rendering for Authenticator Role */}
                            {form.watch("role") === "Authenticator" && (
                                <div className="mt-4">
                                    <h3 className="text-lg font-semibold">Authenticator Filter Settings</h3>
                                    <FormField
                                        control={form.control}
                                        name="filter_org_type"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Filter by Organization Type</FormLabel>
                                                <FormControl>
                                                    <Input type="checkbox" {...field} />
                                                </FormControl>
                                            </FormItem>
                                        )}
                                    />
                                </div>
                            )}

                            {/* Conditional Rendering for Site Admin Role */}
                            {form.watch("role") === "Site Admin" && (
                                <div className="mt-4">
                                    <h3 className="text-lg font-semibold">Site Admin Filter Settings</h3>
                                    <FormField
                                        control={form.control}
                                        name="application"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Application</FormLabel>
                                                <FormControl>
                                                    <Select
                                                        onValueChange={field.onChange}
                                                        value={field.value || ""}
                                                        disabled={loading}
                                                    >
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select Application" />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            {applicationsData.map((app) => (
                                                                <SelectItem key={app.id} value={app.id}>
                                                                    {app.name}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                </FormControl>
                                            </FormItem>
                                        )}
                                    />
                                </div>
                            )}
                        </div>
                        <div className="space-x-4 mt-6">
                            <Button disabled={loading} type="submit">
                                {action}
                            </Button>
                            <Button
                                disabled={loading}
                                type="button"
                                onClick={() => router.back()}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};

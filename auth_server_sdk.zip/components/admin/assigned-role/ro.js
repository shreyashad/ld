"use client";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";

import { Button } from "@/components/ui/button";
import { Trash } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserRoleFormSchema } from "@/schemas";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { createNewUserRoles, deleteUserRolesDetails, fetchRolesListData, updateUserRolesDetails, fetchApplicationListData, fetchUserListData } from "@/app/api/server/route";
import { useSession } from "next-auth/react";

export const UserRoleForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit User Role" : "Create User Role";
    const description = initialData && initialData.id ? "Edit a User Role" : "Create a new User Role";
    const toastMessage = initialData && initialData.id ? "User Role updated successfully" : "User Role created successfully";
    const action = initialData && initialData.id ? "Save Changes" : "Create";
    
    
    const form = useForm({
        resolver: zodResolver(UserRoleFormSchema),
        defaultValues: initialData || {
            user: "",
            role: "",
            application: "",
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);


    const onSubmit = async (values) => {
        setLoading(true);
        try {
            console.log('Submitting values:', values); // Debugging
            if (initialData && initialData.id) {
                await updateUserRolesDetails(session.accessToken, initialData.id, values);
            } else {
                await createNewUserRoles(session.accessToken, values);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/roles-permission/assign-roles`);
        } catch (err) {
            console.error('Submission error:', err); // Debugging
            toast.error(err.message);
        }
        setLoading(false);
    };

    const onDelete = async () => {
        setLoading(true);
        try {
            await deleteUserRolesDetails(initialData.id, session.accessToken);
            toast.success("User Role deleted successfully");
            router.push(`/dashboard/administrator/roles-permission/assign-roles`);
        } catch (err) {
            console.error('Deletion error:', err); // Debugging
            toast.error(err.message);
        }
        setLoading(false);
    };

    const [userData, setUserData] = useState([]);
    const [roleData, setRoleData] = useState([]);
    const [applicationsData, setApplicationsData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                if (session?.accessToken) {
                    const userRes = await fetchUserListData(session.accessToken);
                    const roleRes = await fetchRolesListData(session.accessToken);
                    const appRes = await fetchApplicationListData(session.accessToken);
                    setUserData(userRes);
                    setRoleData(roleRes);
                    setApplicationsData(appRes);
                }
            } catch (error) {
                toast.error("Error fetching data");
            }
        };
        fetchData();
    }, [session]);

    return (
        <>
            <div className="flex items-center justify-between">
                <DashHeading title={title} description={description} />
                {initialData && initialData.id && (
                    <Button
                        disabled={loading}
                        variant="destructive"
                        size="icon"
                        onClick={() => setOpen(true)}
                    >
                        <Trash className="h-4 w-4" />
                    </Button>
                )}
            </div>
            <Separator />
            <Form {...form}>
                <form
                    onSubmit={form.handleSubmit(onSubmit)}
                    className="w-full space-y-8"
                >
                    <div className="grid-cols-2 gap-8 md:grid">
                        <FormField
                            control={form.control}
                            name="user"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>User</FormLabel>
                                    <FormControl>
                                        <Select
                                            onValueChange={field.onChange}
                                            value={field.value}
                                            disabled={loading}
                                        >
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select a User" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {userData.map((users) => (
                                                    <SelectItem key={users.id} value={users.id}>
                                                        {users.username}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="role"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Role</FormLabel>
                                    <FormControl>
                                        <Select
                                            onValueChange={field.onChange}
                                            value={field.value}
                                            disabled={loading}
                                        >
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select a Role" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {roleData.map((r) => (
                                                    <SelectItem key={r.id} value={r.id}>
                                                        {r.name}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="application"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Application</FormLabel>
                                    <FormControl>
                                        <Select
                                            onValueChange={field.onChange}
                                            value={field.value}
                                            disabled={loading}
                                            multiple
                                        >
                                            <SelectTrigger>
                                                <SelectValue placeholder="Select Applications" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {applicationsData.map((app) => (
                                                    <SelectItem key={app.id} value={app.id}>
                                                        {app.name}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                    </div>
                    <div className="space-x-4">
                        <Button disabled={loading} className="ml-auto" type="submit">
                            {action}
                        </Button>
                        <Button
                            disabled={loading}
                            className="ml-auto"
                            type="button"
                            onClick={() => router.back()}
                        >
                            Cancel
                        </Button>
                    </div>
                </form>
            </Form>
            {initialData && initialData.id && (
                <AlertModal
                    title="Are you sure?"
                    description="This action cannot be undone."
                    name={initialData.name}
                    isOpen={open}
                    onClose={() => setOpen(false)}
                    onConfirm={onDelete}
                    loading={loading}
                />
            )}
        </>
    );
};

"use client";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Pencil, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import toast from "react-hot-toast";
import { deleteDepartmentDetails } from "@/app/api/server/route";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { useSession } from "next-auth/react";

export function DepartmentCellAction({ data }) {  // Use data prop
    const { data: session } = useSession();
    const router = useRouter();
    const [alertModalOpen, setAlertModalOpen] = useState(false);

    const handleEdit = () => {
        router.push(`/dashboard/administrator/org-management/department/${data.id}`);
    };

    const deleteDepartment = async () => {
        try {
            await deleteDepartmentDetails(data.id, session.accessToken);
            toast.success("Department deleted successfully");
            setAlertModalOpen(false);
            router.refresh();  // Refresh the page to reflect changes
        } catch (error) {
            toast.error("Error deleting department");
        }
    };

    return (
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={handleEdit}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update Department</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="hover:bg-secondary"
                            onClick={() => setAlertModalOpen(true)}
                        >
                            <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete Department</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>

            <AlertModal
                title="Are you sure?"
                description="This action cannot be undone."
                isOpen={alertModalOpen}
                onClose={() => setAlertModalOpen(false)}
                onConfirm={deleteDepartment}
                loading={false} // Handle loading state as needed
            />
        </div>
    );
}

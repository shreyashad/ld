"use client";
import {  createNewDepartment, deleteDepartmentDetails, updateDepartmentDetails } from "@/app/api/server/route";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";

import { Button } from "@/components/ui/button";
import { Trash } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { AlertModal } from "@/components/dashboard/alert-modal";
import toast from "react-hot-toast";
import { DepartmentFormSchema } from "@/schemas";


export const DepartmentForm = ({ initialData }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const title = initialData  && initialData.id ? "Edit department" : "Create department";
    const description = initialData  && initialData.id ? "Edit a Department" : "Create a new department Type";
    const toastMessage = initialData  && initialData.id ? "Department updated successfully" : "Department created successfully";
    const action = initialData  && initialData.id ? "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(DepartmentFormSchema),
        defaultValues: initialData || {
            name: "",
        },

    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const onSubmit = async (values) => {
        setLoading(true);
        try {
            if (initialData && initialData.id) {
                await updateDepartmentDetails(session.accessToken,  initialData.id, values);
            } else {
                await createNewDepartment(session.accessToken, values);
            }
            toast.success(toastMessage);
            router.push(`/dashboard/administrator/org-management/department`);
            router.refresh();
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };

    const onDelete = async () => {
        setLoading(true);
        try {
            await deleteDepartmentDetails(initialData.id, session.accessToken);
            toast.success("Department deleted successfully");
            router.push(`/dashboard/administrator/org-management/department`);
            
        } catch (err) {
            toast.error(err.message);
        }
        setLoading(false);
    };

    return(
        <>
            <div className="flex items-center justify-between">
                <DashHeading title={title} description={description} />
                {initialData && initialData.id && (
                    <Button
                        disabled={loading}
                        variant="destructive"
                        size="icon"
                        onClick={() => setOpen(true)}
                    >
                        <Trash className="h-4 w-4" />
                    </Button>
                )}
            </div>
            <Separator />
            <Form {...form}>
                <form
                    onSubmit={form.handleSubmit(onSubmit)}
                    className="w-full space-y-8"
                >
                    <div className="grid-cols-2 gap-8 md:grid">
                        <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Name</FormLabel>
                                    <FormControl>
                                        <Input
                                            {...field}
                                            placeholder="Name"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        
                    </div>
                    <div className="space-x-4">
                        <Button disabled={loading} className="ml-auto" type="submit">
                            {action}
                        </Button>
                        <Button
                            disabled={loading}
                            className="ml-auto"
                            type="button"
                            onClick={() => {
                                router.back();
                            }}
                        >
                            Cancel
                        </Button>
                    </div>
                </form>
            </Form>
            {initialData && initialData.id && (
                <AlertModal
                    title="Are you Sure"
                    description="This action cannot be undone."
                    name={initialData?.name}
                    isOpen={open}
                    onClose={() => setOpen(false)}
                    onConfirm={onDelete}
                    loading={loading}
                />
            )}
        </>
    );

};
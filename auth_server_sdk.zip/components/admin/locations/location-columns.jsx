"use client";
import { DataTableColumnHeader } from "@/components/ui/data-table/data-table-column-header";
import { Checkbox } from "@/components/ui/checkbox";
import { LocationCellAction } from "./cell-action";


export const LocationColumns = [
    {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={
              table.getIsAllPageRowsSelected() ||
              (table.getIsSomePageRowsSelected() && "indeterminate")
            }
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
            aria-label="Select all"
            className="translate-y-[2px]"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Select row"
            className="translate-y-[2px]"
          />
        ),
        enableSorting: false,
        enableHiding: false,
    },
    {
      accessorKey: "org_typr",
      header: ({ column }) => <DataTableColumnHeader column={column} title={"Organization Type"} />,
      cell: ({ row }) => {
          return <div className="flex items-center">{row.original.org_type}</div>;
      }
    },
    {
      accessorKey: "org_name",
      header: ({ column }) => <DataTableColumnHeader column={column} title={"Organization Name"} />,
      cell: ({ row }) => {
          return <div className="flex items-center">{row.original.org_name}</div>;
      }
    },
    {
      accessorKey: "location_type",
      header: ({ column }) => <DataTableColumnHeader column={column} title={"Location Type"} />,
      cell: ({ row }) => {
          return <div className="flex items-center">{row.original.location_type}</div>;
      }
    },
    {
        accessorKey: "location_name",
        header: ({ column }) => <DataTableColumnHeader column={column} title={"Location Name"} />,
        cell: ({ row }) => {
            return <div className="flex items-center">{row.original.location_name}</div>;
        }
    },
    {
        id: "actions",
        enableSorting: false,
        cell: ({ row }) => <LocationCellAction data={row.original} />, // Ensure data is passed correctly
    }
];
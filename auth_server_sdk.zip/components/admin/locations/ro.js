"use client";

import { useState } from 'react';
import axios from 'axios';
import { DashHeading } from "@/components/dashboard/dash-heading";
import { Button } from "@/components/ui/button";
import { Plus, Upload } from "lucide-react";
import { useRouter } from "next/navigation";
import { Input } from '@/components/ui/input';

const LocationClient = () => {
    const router = useRouter();
    const [file, setFile] = useState(null);
    const [uploadStatus, setUploadStatus] = useState('');

    const handleFileChange = (event) => {
        setFile(event.target.files[0]);
    };

    const handleUpload = async () => {
        if (!file) {
            alert('Please select a file to upload.');
            return;
        }

        const formData = new FormData();
        formData.append('file', file);

        try {
            setUploadStatus('Uploading...');
            const response = await axios.post('/api/import-excel/', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            setUploadStatus('File uploaded successfully');
            console.log('Response:', response.data);
        } catch (error) {
            setUploadStatus('Error uploading file');
            console.error('Error:', error);
        }
    };

    return (
        <>
            <div className="flex items-center justify-between mb-4">
                <DashHeading title="Location List" />
                <Button
                    onClick={() => {
                        router.push("/dashboard/administrator/org-management/location/new");
                    }}
                >
                    <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
            </div>

            {/* File upload section */}
            <div className="mb-4">
                <Input
                    type="file"
                    accept=".xlsx"
                    onChange={handleFileChange}
                    // className="mr-2"
                />
                <Button onClick={handleUpload} disabled={!file}>
                    <Upload className="mr-2 h-4 w-4" /> Upload
                </Button>
                <p>Status: {uploadStatus}</p>
            </div>
        </>
    );
}

export default LocationClient;

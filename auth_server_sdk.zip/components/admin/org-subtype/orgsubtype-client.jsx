"use client";
import { DashHeading } from "@/components/dashboard/dash-heading";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useRouter } from "next/navigation";



const OrgSubTypeClient = () => {
    const router = useRouter();
    return(
        <>
             <div className="flex items-center justify-between">
                <DashHeading
                    title="Organization SubType List "
                />
                <Button
                    onClick={() => {
                        router.push("/dashboard/administrator/org-management/org-subtype/new");
                    }}
                >
                    <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
            </div>
        </>
    );
}
export default OrgSubTypeClient;
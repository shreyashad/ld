"use client";

import { DashHeading } from "@/components/dashboard/dash-heading";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useRouter } from "next/navigation";



const PermissionClient = () => {
    const router = useRouter();
    return(
        <>
         <div className="flex items-center justify-between">
                <DashHeading 
                    title="Permission List"
                />
                <Button
                    onClick={() => {
                        router.push("/dashboard/administrator/roles-permission/permissions/new");
                    }}
                >
                    <Plus className="mr-2 h-4 w-4" /> Add New
                </Button>
            </div>
        
        </>
    );
};

export default PermissionClient;
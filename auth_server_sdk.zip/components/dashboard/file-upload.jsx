"use client";

import axios from "axios";
import { useSession } from "next-auth/react";
import { useState } from "react";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";


export const FileUpload = ({uploadUrl, onSuccess, onError, accept = "*/*", buttonText = "Upload" }) => {
    const [file, setFile] = useState(null);
    const [isUploading, setIsUploading] = useState(false);
    const [message, setMessage] = useState(null);
    const {data: session} = useSession();

    const handleFileChange = (event) => {
        setFile(event.target.files[0]);
    };

    const handleUpload = async (event) => {
        event.preventDefault();

        if(!file) {
            setMessage('Please select a file to upload.');
            return;
        }

        const formData = new FormData();
        formData.append('file', file);

        setIsUploading(true);
        setMessage(null);
        
        try {
            const response = await axios.post(`${API_BASE_URL}${uploadUrl}`, formData,{
                headers: {
                    Authorization: `Bearer ${session.accessToken}`,
                },
            });
            if (response.status == 200) {
                const result = await response.json();
                setMessage('Uploaded successful!');
                if (onSuccess) onSuccess(result);
            } else {
                const result = await response.json();
                setMessage(`Upload failed: ${result.detail}`);
                if (onError) onError(result);
            }
        } catch (error) {
            setMessage(`Error: ${error.message}`);
            if (onError) onError(error);
        } finally {
            setIsUploading(false);
        }
    };

    return (
        <div>
            <form onSubmit={handleUpload}>
                <input
                    type="file"
                    accept={accept}
                    onChange={handleFileChange}
                    />
                <button type="submit" disabled={isUploading}>
                {isUploading ? 'Uploading...' : buttonText}
                </button>
            </form>
            {message && <p style={{ color: isUploading ? 'blue' : message.startsWith('Upload failed') ? 'red' : 'green' }}>{message}</p>}
        </div>
    );
};

import { fetchUserDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";


export default async function AccountDetails({ accountsData }) {
    
    return (
      <Card>
        <CardHeader>
          <CardTitle>Account Information</CardTitle>
          <CardDescription>Your account and professional details</CardDescription>
        </CardHeader>
        <CardContent>
        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="fullName">First Name</Label>
                            <Input disabled id="fullName" value={accountsData.first_name} className="text-bold"/>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="last_name">Last Name</Label>
                            <Input disabled id="last_name" placeholder={accountsData.last_name} />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="location_type">Location Type</Label>
                            <Input disabled id="location_type" placeholder={accountsData.location_type} />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="location_name">Location Name</Label>
                            <Input disabled id="location_name" placeholder={accountsData.location_name} />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="emp_code">Employee Code</Label>
                            <Input disabled id="emp_code" placeholder={accountsData.emp_code} />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="designation">Designation</Label>
                            <Input disabled id="designation" placeholder={accountsData.designation} />
                          </div>
                        </div>
                        
          
        </CardContent>
        
      </Card>


    );
  }
  
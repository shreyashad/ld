
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import AccountDetails from "./accounts-details";
import ProfileDetails from "./profile-details";
import NotificationsDetails from "./notification";
import { auth } from "@/auth"
import { fetchNotification, fetchUserAccountDetails, fetchUserProfileDetails } from "@/app/api/server/route"
import { MapPin } from "lucide-react";
import UserNotificationsDetails from "./notification";
import { ChangePasswordForm } from "./change-password";
import AvatarUpload from "./profile-image";

export default async function UserProfilePage() {
  
  const session = await auth();
  const applicationName = process.env.APP_NAME

  if (!session || !session.accessToken) {
    console.error("No session or access token found.");
    return <div>Unauthorized</div>;
  }

  let accountsData, profileData, notifiData;
  try {
      accountsData = await fetchUserAccountDetails(session.accessToken);
      profileData = await fetchUserProfileDetails(session.accessToken);
      notifiData = await fetchNotification(session.accessToken, applicationName);

  } catch (error) {
      console.error("Error fetching user account data:", error);
      return <div>Failed to load user account data</div>;
  }
  return (
    <div>
      
      <div className="container mx-auto p-4">
        <Card>
          <CardContent className="p-0">
            <div className="h-48 bg-gradient-to-r from-blue-400 to-purple-600"></div>
            
            <AvatarUpload initialImage={profileData.profile_picture} accountsData={accountsData}/>
            
            {/* <div className="px-6 pb-6">
              <div className="flex justify-between items-end -mt-16">
                <Avatar className="h-32 w-32 border-4 border-white">
                  <AvatarImage src="/placeholder.svg?height=128&width=128" alt="User" />
                  <AvatarFallback>{accountsData.first_name}</AvatarFallback>
                </Avatar>
                <div className="space-x-2">
                  <Button variant="outline">Edit Profile</Button>
                  <Button>Follow</Button>
                </div>
              </div>
              <div className="mt-4">
                <h1 className="text-2xl font-bold">{accountsData.first_name} {accountsData.last_name}</h1>
                <p className="text-gray-600">{accountsData.designation}</p>
                <p className="text-gray-600 flex items-center mt-1">
                  <MapPin className="h-4 w-4 mr-1" /> {accountsData.location_name}
                </p>
                
              </div>
            </div> */}
          </CardContent>
        </Card>
        <Tabs defaultValue="account" className="mt-4">
          <TabsList className="bg-white p-2 rounded-lg shadow">
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="teams">Teams</TabsTrigger>
          </TabsList>
          <TabsContent value="account">
            <AccountDetails  accountsData={accountsData}/>
          </TabsContent>
          
          <TabsContent value="profile">
            <ProfileDetails accountsData={accountsData} />
          </TabsContent>
          <TabsContent value="security">
              <ChangePasswordForm />
          </TabsContent>
          <TabsContent value="notifications">
            <UserNotificationsDetails notificationsData={notifiData} />
          </TabsContent>
          <TabsContent value="teams">
            <h1>Teams</h1>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
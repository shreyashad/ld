"use client";
import { fetchUserProfileDetails, updateUserProfileData } from "@/app/api/server/route";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useSession } from "next-auth/react";
import { useEffect, useState } from "react";

export default function ProfileDetails({ accountsData }) {
    const [formData, setFormData] = useState({
      address:"",
      city:"",
      state:"",
      country:"",
      postal_code:"",
      phone_number:"",
      date_of_birth:"",
      bio:"",
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const { data: session} = useSession();

    useEffect(() => {
      const fetchData = async () => {
        if (session) {
          try {
              const data = await fetchUserProfileDetails(session.accessToken);
              setFormData(data); // Assuming the API returns a correct structure
          } catch (error) {
              setError("Failed to fetch profile data.");
          }
      }
      };
  
      fetchData();
    }, [session]);

    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData({ ...formData, [name]: value});
    };

    const handleSubmit = async (e) => {
      e.preventDefault();
      setLoading(true);
      try{
        await updateUserProfileData(session.accessToken, formData);
        alert("Profile updated successfully!");
      } catch(error) {
        setError("Failed to update profile.");
      } finally {
        setLoading(false);
      }
    };

    return(
      <Card>
      <CardHeader>
          <CardTitle>Profile Information</CardTitle>
          <CardDescription>Your personal details</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
          <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                      <Label htmlFor="fullName">First Name</Label>
                      <Input disabled id="fullName" value={accountsData.first_name} />
                  </div>
                  <div className="space-y-2">
                      <Label htmlFor="headline">Last Name</Label>
                      <Input disabled id="headline" value={accountsData.last_name} />
                  </div>
                  <div className="space-y-2">
                      <Label htmlFor="phone_number">Phone</Label>
                      <Input
                          id="phone_number"
                          name="phone_number"
                          type="tel"
                          value={formData.phone_number}
                          onChange={handleChange}
                          placeholder="Phone Number"
                      />
                  </div>
                  <div className="space-y-2">
                      <Label htmlFor="date_of_birth">Date of Birth</Label>
                      <Input
                          id="date_of_birth"
                          name="date_of_birth"
                          type="date"
                          value={formData.date_of_birth}
                          onChange={handleChange}
                      />
                  </div>
              </div>
              <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Textarea
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleChange}
                      placeholder="Address"
                  />
              </div>
              <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                      <Label htmlFor="city">City</Label>
                      <Input
                          id="city"
                          name="city"
                          value={formData.city}
                          onChange={handleChange}
                          placeholder="City"
                      />
                  </div>
                  <div className="space-y-2">
                      <Label htmlFor="state">State</Label>
                      <Input
                          id="state"
                          name="state"
                          value={formData.state}
                          onChange={handleChange}
                          placeholder="State"
                      />
                  </div>
                  <div className="space-y-2">
                      <Label htmlFor="country">Country</Label>
                      <Input
                          id="country"
                          name="country"
                          value={formData.country}
                          onChange={handleChange}
                          placeholder="Country"
                      />
                  </div>
                  <div className="space-y-2">
                      <Label htmlFor="postal_code">Postal Code</Label>
                      <Input
                          id="postal_code"
                          name="postal_code"
                          value={formData.postal_code}
                          onChange={handleChange}
                          placeholder="Postal Code"
                      />
                  </div>
              </div>
              <div className="space-y-2">
                  <Label htmlFor="bio">About</Label>
                  <Textarea
                      id="bio"
                      name="bio"
                      value={formData.bio}
                      onChange={handleChange}
                      placeholder="Tell us about yourself"
                  />
              </div>
              {error && <p className="text-red-500">{error}</p>}
              <CardFooter>
                  <Button type="submit" disabled={loading}>
                      {loading ? "Saving..." : "Save Profile"}
                  </Button>
              </CardFooter>
          </form>
      </CardContent>
  </Card>

    );
};

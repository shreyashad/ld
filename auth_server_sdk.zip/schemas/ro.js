



export const RegisterSchema = z.object({
    email: z.string().email({
      message: "Email is required",
    }),
    password: z.string().min(6, {
      message: "Minimum of 6 characters is required",
    }),
    name: z.string().min(1, {
      message: "Name is required",
    }),
  })


  id = models.UUIDField(
    default=uuid.uuid4, unique=True, editable=False, db_index=True, primary_key=True
)
org_type = models.CharField(max_length=150)
org_name = models.CharField(max_length=250)
org_sub_type = models.CharField(max_length=150)
location_type = models.CharField(max_length=150)
location_name = models.CharField(max_length=250)
location_code = models.CharField(max_length=150)
department = models.CharField(max_length=250)
mobile = PhoneNumberField(null=False, blank=False, unique=True)
username = models.CharField(max_length=150, unique=True)
password = models.CharField(max_length=128)
assigned_details = models.CharField(max_length=1000, blank=True, null=True)
is_online = models.BooleanField(default=False)
is_staff = models.BooleanField(default=False)
is_verified = models.BooleanField(default=False)
last_password_change = models.DateTimeField(null=True, blank=True)
password_change_required = models.BooleanField(default=False)
password_history_json = models.TextField(default='[]')
password_reset_token = models.CharField(max_length=255, blank=True, null=True)
token_expiration = models.DateTimeField(blank=True, null=True)


  export const ResetSchema = z.object({
    email: z.string().email({
      message: " Email is required",
    }),
  })
  
export const NewPasswordSchema = z.object({
      password: z
        .string()
        .min(6, {
          message: "Minimum of 6 characters is required",
        })
        .max(50, {
          message: "Maximum of 50 characters is allowed",
        })
        .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/, {
          message: "Password must contain at least one uppercase letter, one lowercase letter, and one number",
        }),
      confirmPassword: z.string(),
    })
    .refine((data) => data.password === data.confirmPassword, {
      message: "Passwords don't match",
      path: ["confirmPassword"], // path of error
    })
  








export const ProfileFormSchema = z.object({
    address: z.string().optional(),
    city: z.string().optional(),
    state: z.string().optional(),
    country: z.string().optional(),
    postal_code: z.string().optional(),
    phone_number: z.string().optional(),
    date_of_birth: z.string().optional(),
    bio: z.string().optional(),
})


// export const organizationFormSchema = z.object({
//       name: z.string().min(1, "Name is required").max(250, "must be 250 characters or less"),
//       org_type: orgTypeEnum
//     });






const profileSchema = z.object({
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  country: z.string().optional(),
  postal_code: z.string().optional(),
  phone_number: z.string().optional(),
  date_of_birth: z.string().optional(),
  bio: z.string().optional(),
});


    
    
    
  
    
  
    
    
    
    
  
    export const profileFormSchema = z.object({
      bio: z.string().max(160).min(4),
    })
  
  
  
    export const UserrolesFormSchema = z.object({
      user: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      role: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      application: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      can_create: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      can_read: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      can_update: z.string().min(1, "department is required").max(250, "must be 250 characters or less"),
      can_delete: z.string().min(1, "department is required").max(250, "must be 250 characters or less")
    })
  
    
  
    import { useState, useEffect } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Input, Button, Select, Label, SelectTrigger, SelectContent, SelectItem, SelectValue } from "your-ui-library"; // Assuming ShadCN or similar

// Zod Schema Definitions for validation
const personalInfoSchema = z.object({
  first_name: z.string().nonempty("First Name is required"),
  last_name: z.string().nonempty("Last Name is required"),
  emp_code: z.string().nonempty("Employee Code is required"),
  designation: z.string().nonempty("Designation is required"),
});

const orgInfoSchema = z.object({
  org_type: z.string().nonempty("Organization Type is required"),
  org_name: z.string().nonempty("Organization Name is required"),
  org_sub_type: z.string().nonempty("Organization Subtype is required"),
  location_type: z.string().nonempty("Location Type is required"),
  location_name: z.string().nonempty("Location Name is required"),
});

const accountInfoSchema = z.object({
  username: z.string().nonempty("Username is required"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  confirm_password: z.string().min(8, "Password confirmation must be at least 8 characters"),
  mobile: z.string().nonempty("Mobile number is required"),
}).refine((data) => data.password === data.confirm_password, {
  message: "Passwords must match",
  path: ["confirm_password"],
});

export default function UserRegistrationForm() {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    emp_code: "",
    designation: "",
    org_type: "",
    org_name: "",
    org_sub_type: "",
    location_type: "",
    location_name: "",
    username: "",
    password: "",
    confirm_password: "",
    mobile: "",
  });

  // Dynamic Data Options
  const orgTypes = ["Corporate", "Non-Profit", "Government"];
  const orgNames = {
    Corporate: ["Corp1", "Corp2"],
    "Non-Profit": ["NP1", "NP2"],
    Government: ["Gov1", "Gov2"],
  };
  const orgSubTypes = {
    Corp1: ["Type1", "Type2"],
    Corp2: ["Type3", "Type4"],
    NP1: ["Subtype1", "Subtype2"],
    Gov1: ["GovSubtype1"],
  };
  const locationTypes = {
    Corp1: ["HQ", "Branch"],
    NP1: ["Field Office"],
  };
  const locationNames = {
    HQ: ["Location1", "Location2"],
    Branch: ["Location3"],
    "Field Office": ["Location5"],
  };

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(
      currentStep === 0
        ? personalInfoSchema
        : currentStep === 1
        ? orgInfoSchema
        : accountInfoSchema
    ),
  });

  // Step Handlers
  const handleNext = () => setCurrentStep((prev) => prev + 1);
  const handlePrevious = () => setCurrentStep((prev) => prev - 1);

  // Handle Input Change
  const handleSelectChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value });
    // Handle dependent field updates
    if (field === "org_type") {
      setFormData({ ...formData, org_name: "", org_sub_type: "" });
    } else if (field === "org_name") {
      setFormData({ ...formData, location_type: "", location_name: "" });
    }
  };

  const onSubmit = (data: any) => {
    console.log("Form Submitted", data);
  };

  return (
    <>
      <h1 className="text-center space-x-4 mt-20 text-2xl font-bold">User Registration</h1>
      <div className="container mx-auto max-w-6xl py-12 md:py-16 lg:py-20 flex gap-8">
        {/* Step Indicator */}
        <div className="w-1/3 bg-muted rounded-lg p-6 shadow-md">
          {/* Personal Info, Org Info, Account Info Steps */}
          {/* Dynamically rendered steps */}
        </div>

        {/* Form Area */}
        <div className="w-2/3 bg-background border rounded-lg p-6 shadow-lg">
          <form onSubmit={handleSubmit(onSubmit)}>
            {currentStep === 0 && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  {/* Personal Info Fields */}
                  <div className="space-y-2">
                    <Label>First Name</Label>
                    <Input {...register("first_name")} />
                    {errors.first_name && <p>{errors.first_name.message}</p>}
                  </div>
                  {/* More personal info fields... */}
                </div>
                <Button variant="outline" onClick={handleNext}>
                  Next
                </Button>
              </div>
            )}

            {currentStep === 1 && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Organization Type</Label>
                    <Select
                      onValueChange={(value) => handleSelectChange("org_type", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select Organization Type" />
                      </SelectTrigger>
                      <SelectContent>
                        {orgTypes.map((org_type) => (
                          <SelectItem key={org_type} value={org_type}>
                            {org_type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Organization Name</Label>
                    <Select
                      onValueChange={(value) => handleSelectChange("org_name", value)}
                      disabled={!formData.org_type}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select Organization Name" />
                      </SelectTrigger>
                      <SelectContent>
                        {(orgNames[formData.org_type] || []).map((org_name) => (
                          <SelectItem key={org_name} value={org_name}>
                            {org_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {/* More organization fields */}
                </div>
                <div className="flex justify-between">
                  <Button variant="outline" onClick={handlePrevious}>
                    Previous
                  </Button>
                  <Button variant="outline" onClick={handleNext}>
                    Next
                  </Button>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                {/* Account Info Fields */}
                <Button variant="outline" onClick={handlePrevious}>
                  Previous
                </Button>
                <Button type="submit">Create Account</Button>
              </div>
            )}
          </form>
        </div>
      </div>
    </>
  );
}
-----------------
"use client";
import { useEffect, useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { fetchDesignations, fetchLocationTypes, fetchOrgNames, fetchOrgSubTypes, fetchOrgTypes } from "@/app/api/server/route";

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    emp_code: "",
    designation: "",
    org_type: "",
    org_name: "",
    org_sub_type: "",
    location_type: "",
    location_name: "",
    location_code: "",
    assigned_details: "",
    departments: "",
    username: "",
    password: "",
    confirm_password: "",
    mobile: "",
  });

  const [desigData, setDesigData] = useState([]);
  const [orgTypeData, setOrgTypeData] = useState([]);
  const [orgNamesData, setOrgNamesData] = useState([]);
  const [orgSubTypeData, setOrgSubTypeData] = useState([]);
  const [locationTypeData, setLocationTypeData] = useState([]);
  const [locationNamesData, setLocationNamesData] = useState([]);
  const [locationCodeData, setLocationCodeData] = useState([]);
  const [currentStep, setCurrentStep] = useState(0);

  const handleNext = () => {
    setCurrentStep(currentStep + 1);
  };

  const handlePrevious = () => {
    setCurrentStep(currentStep - 1);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const desig = await fetchDesignations();
        setDesigData(desig);
        const orgtype = await fetchOrgTypes();
        setOrgTypeData(orgtype);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSelectChange = async (name, value) => {
    setFormData({ ...formData, [name]: value });

    if (name === "org_type") {
      try {
        const orgNames = await fetchOrgNames(value);
        const orgSubtypes = await fetchOrgSubTypes(value);
        setOrgNamesData(orgNames);
        setOrgSubTypeData(orgSubtypes);

        setLocationTypeData([]);
        setLocationNamesData([]);
        setLocationCodeData([]);
      } catch (error) {
        console.error("Error fetching organization data:", error);
      }
    } else if (name === "org_name") {
      try {
        const locationTypes = await fetchLocationTypes(value);
        setLocationTypeData(locationTypes);
      } catch (error) {
        console.error("Error fetching location types:", error);
      }
    }
  };

  return (
    <>
      <h1 className="text-center space-x-4 mt-20 text-2xl text-bold">User Registration</h1>
      <div className="container mx-auto max-w-6xl py-12 md:py-16 lg:py-20 flex gap-8">
        {/* Stepper */}
        <div className="w-1/3 bg-muted rounded-lg p-6 shadow-md">
          <div className="space-y-4">
            {["Personal Info", "Company Info", "Account Info"].map((label, index) => (
              <div key={index} className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div
                    className={`rounded-full w-8 h-8 flex items-center justify-center font-semibold ${
                      currentStep === index ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {index + 1}
                  </div>
                  <h3 className={`text-lg font-semibold ${currentStep === index ? "text-primary" : ""}`}>
                    {label}
                  </h3>
                </div>
                <p className={`text-muted-foreground ${currentStep === index ? "text-primary" : ""}`}>
                  {index === 0
                    ? "Enter your personal information."
                    : index === 1
                    ? "Enter your company information."
                    : "Set up your account credentials."}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Form */}
        <div className="w-2/3 bg-background border rounded-lg p-6 shadow-lg">
          {currentStep === 0 && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>First Name</Label>
                  <Input
                    type="text"
                    name="first_name"
                    value={formData.first_name}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Last Name</Label>
                  <Input
                    type="text"
                    name="last_name"
                    value={formData.last_name}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Employee Code</Label>
                  <Input
                    type="text"
                    name="emp_code"
                    value={formData.emp_code}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Designation</Label>
                  <Select onValueChange={(value) => handleSelectChange("designation", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Designation" />
                    </SelectTrigger>
                    <SelectContent>
                      {desigData.map((designation) => (
                        <SelectItem key={designation.id} value={designation.name}>
                          {designation.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-between">
                <Button variant="outline" type="button" onClick={handleNext}>
                  Next
                </Button>
              </div>
            </div>
          )}

          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Organization Type</Label>
                  <Select onValueChange={(value) => handleSelectChange("org_type", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Org Type" />
                    </SelectTrigger>
                    <SelectContent>
                      {orgTypeData.map((orgtype, index) => (
                        <SelectItem key={index} value={orgtype}>
                          {orgtype}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Organization Name</Label>
                  <Select onValueChange={(value) => handleSelectChange("org_name", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Org Name" />
                    </SelectTrigger>
                    <SelectContent>
                      {orgNamesData.map((orgName) => (
                        <SelectItem key={orgName.id} value={orgName.name}>
                          {orgName.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Organization Subtype</Label>
                  <Select onValueChange={(value) => handleSelectChange("org_sub_type", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Org Subtype" />
                    </SelectTrigger>
                    <SelectContent>
                      {orgSubTypeData.map((orgSubtype) => (
                        <SelectItem key={orgSubtype.id} value={orgSubtype.subtype}>
                          {orgSubtype.subtype}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Location Type</Label>
                  <Select onValueChange={(value) => handleSelectChange("location_type", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Location Type" />
                    </SelectTrigger>
                    <SelectContent>
                      {locationTypeData.map((locationType, index) => (
                        <SelectItem key={index} value={locationType}>
                          {locationType}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-between">
                <Button variant="outline" type="button" onClick={handlePrevious}>
                  Previous
                </Button>
                <Button variant="outline" type="button" onClick={handleNext}>
                  Next
                </Button>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Username</Label>
                  <Input
                    type="text"
                    name="username"
                    value={formData.username}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Password</Label>
                  <Input
                    type="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Confirm Password</Label>
                  <Input
                    type="password"
                    name="confirm_password"
                    value={formData.confirm_password}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Mobile Number</Label>
                  <Input
                    type="text"
                    name="mobile"
                    value={formData.mobile}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              <div className="flex justify-between">
                <Button variant="outline" type="button" onClick={handlePrevious}>
                  Previous
                </Button>
                <Button variant="outline" type="submit">
                  Submit
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
    // const fetchOrganizationNames = async (orgType) => {
    //     if (!orgType) return;  // Ensure the orgType exists before fetching
    //     setLoading(true);
    //     try {
    //         const data = await fetchOrgNames(orgType);  // Replace with actual fetching function
    //         setOrgNamesData(data);
    //     } catch (err) {
    //         toast.error("Error fetching organization names");
    //     } finally {
    //         setLoading(false);
    //     }
    // };


     
    // useEffect( async() => {
    //     const orgType = form.watch("org_type");
    //     if (orgType) {
    //         fetchOrganizationNames(orgType);
    //     }
    // }, [form.watch("org_type")]); 
import axios from "axios";



const API_CAS_URL = process.env.NEXT_PUBLIC_AUTH_SERVER_API_BASE_URL || "";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "";





export async function getpasswordResetRequest(userDetails) {
    try {
        const response = await axios.post(`${API_CAS_URL}api/password-reset-request/`, userDetails);
        return response.data
    } catch(error) {
        console.error("Error while password rest :", error);
        throw error;
    }
};

export async function getResetPassword(userDetails) {
    try {
        const response = await axios.post(`${API_CAS_URL}api/reset-password/`, userDetails);
        return response.data
    } catch(error) {
        console.error("Error while password rest :", error);
        throw error;
    }
};


export async function fetchNotification(accessToken) {
    try{
        const response = await axios.get(`${API_CAS_URL}api/notifications/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data
    } catch(error) {
        console.error("Error while fetching notifications` :", error);
        throw error;
    }
};

export async function fetchApplicationdetails() {
    try {
        const response = await axios.post(`${API_CAS_URL}api/application-details/`, {
            name: process.env.APP_NAME
        });
        return response.data;
    } catch (error) {
        throw new Error("Failed to fetch application details");
    }
};

export async function validateTicket(serviceTicket, applicationId) {
    try {
        const response = await axios.post(`${API_CAS_URL}api/validate-ticket/`, {
            service_ticket: serviceTicket,
            application_id: applicationId,
        });
        return response.data; // Ensure this returns the expected user details
    } catch (error) {
        console.error('Error validating ticket:', error);
        throw new Error('Error validating ticket');
    }
};

export async function validateSession(sessionKey) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/validate-session/`, {
            headers: {
                Authorization: `Bearer ${sessionKey}`,
            },
        });
        return response.status === 200;
    } catch (error) {
        console.error("Session validation error:", error);
        return false;
    }
};



// for user registration

export async function fetchDesignations() {
    try{
        const response = await axios.get(`${API_CAS_URL}api/designations/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch designation");
    }
};

export async function fecthDepartments() {
    try{
        const response = await axios.get(`${API_CAS_URL}api/departments/`);
        return response.data
    } catch (error) {
        throw new Error("Failed to fetch departments");
    }
};


export async function fetchOrgTypes() {
    try {
        const response = await axios.get(`${API_CAS_URL}api/org-type-list/`);
        console.log("Org types Data:", response.data)
        return response.data;

    } catch (error) {
        console.error("Error fetching Org types:", error);
        throw error;
    }
};

export async function fetchOrgNames(orgType) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/org-name-list/?orgType=${orgType}`);
        console.log("Org Names Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Org Names:", error );
        throw error;
    }
};

export async function fetchOrgSubTypes(orgType) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/org-subtypes/?orgType=${orgType}`);
        console.log("Org SubTypes Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Org SubTypes:", error);
        throw error;
    }
};

export async function fetchLocationTypes(orgName) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/location-type-list/?orgName=${orgName}`);
        console.log("Location Type Data:", response.data)
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Type:", error );
        throw error;
    }
};



export async function fetchLocationName(orgName, location_type) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/location-name-list/`, {
            params: {
                orgName: orgName,
                location_type: location_type,
            }
        });
        console.log("Location Name Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Name:", error);
        throw error;
    }
};

export async function fetchLocationCode(orgName, location_type, location_name) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/location-code-list/`, {
            params: {
                orgName: orgName,
                location_type: location_type,
                location_name: location_name
            }
        });
        console.log("Location Code Data:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error fetching Location Code:", error);
        throw error;
    }
};


export async function register(formData) {
    try {
        const response = await axios.post(`${API_CAS_URL}api/register/`, formData);
        console.log("userdetails:", response.data);
        return response.data;
    } catch (error) {
        console.error("Error while registration:", error);
        throw error;
    }
};

// common functions required from auth_server projec 



export async function fetchUserByAppRole(accessToken,application_name,role) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/users/${application_name}/${role}/by-apps/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        console.log("users list:", response.data);
        return response.data;
    }  catch (error) {
        console.error('Error fetching users:', error.response ? error.response.data : error.message);
        return null;
    }
}


export async function fetchAdminTrainersUsername(accessToken) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/online-users-by-application/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            params: {
                application_name: applicationName, // Pass the application name as a query parameter
            },
        });
        console.log("onlineusers:", response.data.active_user);
        return response.data.online_count;
        
    } catch (error) {
        console.error('Error fetching total user count:', error.response ? error.response.data : error.message);
        return null;
    }
}


// for common views related functions

export async function fetchUserAccountDetails(accessToken) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/user-account/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching user account data:", error);
        throw error;
    }
};



export async function fetchUserProfileDetails(accessToken) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/user-profile/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }, 
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching profile data:", error);
        throw error;
    }
};



export async function updateUserProfileData (accessToken, profileData) {
  try {
    const response = await axios.put(`${API_CAS_URL}api/user-profile/`, profileData, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error updating profile data:", error);
    throw error;
  }
};
// for teams related 

export async function fetchUsersTeamlist(accessToken) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/users-teams-list/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching users team list:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function fetchCreatedbyTeamlist(accessToken) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/createdby-teams-list/`,{
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching self team list:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function createNewTeam(accessToken, TeamData) {
    try {
        const response = await axios.post(`${API_CAS_URL}api/create-teams/`, TeamData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
        });
        console.log("teams details:", response.data);
        return response.data;
    } catch(error) {
        console.error('Error creating new team:', error.response ? error.response.data : error.message);
        throw error;
    }
}




// Trainers Admin Dashboard related
export async function fetchTotalOnlineUserCount(accessToken, applicationName) {
    try {
        const response = await axios.get(`${API_CAS_URL}api/online-users-by-application/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
            params: {
                application_name: applicationName, // Pass the application name as a query parameter
            },
        });
        console.log("onlineusers:", response.data.active_user);
        return response.data.online_count;
        
    } catch (error) {
        console.error('Error fetching total user count:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function fetchTotalTrainersCount(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/trainer-count/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        console.log("onlineusers:", response.data.active_user);
        return response.data.trainer_count;
        
    } catch (error) {
        console.error('Error fetching total user count:', error.response ? error.response.data : error.message);
        return null;
    }
};

// Course Category Management Related 

export async function fetchCategoryData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/course-category-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data
    } catch (error) {
        console.error('Error fetching Category request:', error.response ? error.response.data : error.message);
        return null;
    }
}

export async function createNewCategory(categoryData,accessToken,) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/categories/`,categoryData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
        });
        return response.data
    } catch (error) {
        console.error('Error while creating Category request:', error.response ? error.response.data : error.message);
        return null;
    }
}


export async function deleteCourseCategory(categoryid, accessToken) {
    try {
      const response = await axios.delete(`${API_BASE_URL}api/category/${categoryid}/`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error while deleting category details:", error);
      throw error;
    }
  }
  
export async function updateCourseCategory(categoryid, accessToken, categoryData) {
    try {
      const response = await axios.put(`${API_BASE_URL}api/category/${categoryid}/`, categoryData, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "multipart/form-data",
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error while updating category details:", error);
      throw error;
    }
  }
  
// Course Category Management Related 

export async function fetchCourseListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/course-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching courses:', error.response ? error.response.data : error.message);
        throw error;
    }
}

export async function createNewCourse(accessToken, courseData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/create-course/`, courseData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new course data:", error.response ? error.response.data : error.message);
        throw error.response ? error.response.data : { status: ["An unexpected error occurred."] };
    }
}


export async function fetchCourseDetails(accessToken, courseId) {
    if (!courseId) {
        throw new Error("courseId is required");
    }
    
    try {
        const response = await axios.get(`${API_BASE_URL}api/course/${courseId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching course details:", error.response ? error.response.data : error.message);
        throw error;
    }
}

export async function updateCourseDetails(accessToken, courseId, courseData) {
    if (!courseId) {
        throw new Error("courseId is required");
    }
    
    try {
        const response = await axios.patch(`${API_BASE_URL}api/course/${courseId}/`, courseData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        
        return response.data;
    } catch (error) {
        console.error("Error updating course data:", error.response ? error.response.data : error.message);
        throw error;
    }
}


export async function deleteCourse(accessToken, courseId ) {
    try {
        const response = await axios.delete(`${API_BASE_URL}api/course/${courseId}/details/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error deleting category data:", error);
        throw error;
    }
};








// for Training Management














// for training request
export async function fetchTrainingRequest(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/training-request/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data
    } catch (error) {
        console.error('Error fetching Training request:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function createTrainingRequest(accessToken,trainingRequestData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/create-new-trainings-request/`, trainingRequestData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error creating training request:', error.response ? error.response.data : error.message);
        return null;
    }
};


export async function updateTrainingRequest(trainingRequestId, updatedData, accessToken) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/training-requests/${trainingRequestId}/`, updatedData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error updating training request:', error.response ? error.response.data : error.message);
        return null;
    }
};


export async function deleteTrainingRequest(trainingRequestId, accessToken) {
    try {
        await axios.delete(`${API_BASE_URL}api/training-requests/${trainingRequestId}/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return true;
    } catch (error) {
        console.error('Error deleting training request:', error.response ? error.response.data : error.message);
        return false;
    }
};


export async function fetchComments(trainingRequestId, accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/training-requests/${trainingRequestId}/comments/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching comments:', error.response ? error.response.data : error.message);
        return null;
    }
};


export async function createComment(trainingRequestId, commentData, accessToken) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/training-requests/${trainingRequestId}/comments/`, commentData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error creating comment:', error.response ? error.response.data : error.message);
        return null;
    }
};


export async function updateComment(trainingRequestId, commentId, updatedData, accessToken) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/training-requests/${trainingRequestId}/comments/${commentId}/`, updatedData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error updating comment:', error.response ? error.response.data : error.message);
        return null;
    }
};

export async function deleteComment(trainingRequestId, commentId, accessToken) {
    try {
        await axios.delete(`${API_BASE_URL}api/training-requests/${trainingRequestId}/comments/${commentId}/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            },
        });
        return true;
    } catch (error) {
        console.error('Error deleting comment:', error.response ? error.response.data : error.message);
        return false;
    }
};


// for announcement category management

export async function fetchAnnouncementCategoryListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement-category-list`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching Announcement category list data:", error);
        throw error;
    }
};

export async function createNewAnnouncementCategory(accessToken, announcementData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/create-announcement-category/`, announcementData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new  Announcement category data:", error);
        throw error;
    }
};

export async function fetchAnnouncementCategoryDetails(accessToken, announcementCatId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement-category/${announcementCatId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  Announcement category details:", error);
        throw error;
    }
};

export async function updateAnnouncementCategoryDetails(accessToken, announcementCatId, announcementData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/announcement-category/${announcementCatId}/details/`, announcementData,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  Announcement category  details:", error);
        throw error;
    }
};

export async function deleteAnnouncementCategoryDetails(accessToken, announcementCatId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement-category/${announcementCatId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting  Announcement category details:", error);
        throw error;
    }
};

// for announcement management

export async function fetchAnnouncementListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching Announcement list data:", error);
        throw error;
    }
};

export async function createNewAnnouncement(accessToken, announcementData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/create-announcement/`, announcementData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new  Announcement  data:", error);
        throw error;
    }
};

export async function fetchAnnouncementDetails(accessToken, announcementId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement/${announcementId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  Announcement  details:", error);
        throw error;
    }
};

export async function updateAnnouncementDetails(accessToken, announcementId, announcementData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/announcement/${announcementId}/details/`, announcementData,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  Announcement  details:", error);
        throw error;
    }
};

export async function deleteAnnouncementDetails(accessToken, announcementId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/announcement/${announcementId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting  Announcement  details:", error);
        throw error;
    }
};

// for Todays wisdom

export async function fetchTodaysWisdomListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/todays-wisdom-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching todays wisdom list data:", error);
        throw error;
    }
};

export async function createNewTodaysWisdom(accessToken, todaysWisdomData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/todays-wisdom-create/`, todaysWisdomData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new  todays wisdom  data:", error);
        throw error;
    }
};

export async function fetchTodaysWisdomDetails(accessToken, todaysWisdomId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/todays-wisdom/${todaysWisdomId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  todays wisdom  details:", error);
        throw error;
    }
};

export async function updateTodaysWisdomDetails(accessToken, todaysWisdomId, todaysWisdomData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/todays-wisdom/${todaysWisdomId}/details/`, todaysWisdomData,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  todays wisdom  details:", error);
        throw error;
    }
};

export async function deleteTodaysWisdomDetails(accessToken, todaysWisdomId) {
    try {
        const response = await axios.delete(`${API_BASE_URL}api/todays-wisdom/${todaysWisdomId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting  todays wisdom  details:", error);
        throw error;
    }
};

// for Training Room

export async function fetchTrainingRoomListData(accessToken) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/training-rooms-list/`, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching training room list data:", error);
        throw error;
    }
};

export async function createNewTrainingRoom(accessToken, trainingRoomData) {
    try {
        const response = await axios.post(`${API_BASE_URL}api/training-rooms-create/`, trainingRoomData, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error creating new  training room  data:", error);
        throw error;
    }
};

export async function fetchTrainingRoomDetails(accessToken, trainingRoomId) {
    try {
        const response = await axios.get(`${API_BASE_URL}api/training-rooms/${trainingRoomId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  training-rooms details:", error);
        throw error;
    }
};

export async function updateTrainingRoomDetails(accessToken, trainingRoomId, trainingRoomData) {
    try {
        const response = await axios.patch(`${API_BASE_URL}api/training-rooms/${trainingRoomId}/details/`, trainingRoomData,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error fetching  training-rooms  details:", error);
        throw error;
    }
};

export async function deleteTrainingRoomDetails(accessToken, trainingRoomId) {
    try {
        const response = await axios.delete(`${API_BASE_URL}api/training-rooms/${trainingRoomId}/details/`,  {
            headers: {
                Authorization: `Bearer ${accessToken}`,
               
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error Deleting  training-rooms  details:", error);
        throw error;
    }
};

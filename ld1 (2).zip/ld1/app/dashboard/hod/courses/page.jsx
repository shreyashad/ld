
const fetchCourses = async () => {
    const response = await fetch('/api/courses');
    if (!response.ok) {
        throw new Error('Failed to fetch courses');
    }
    return response.json();
};

const CoursesPage = async () => {
    const courses = await fetchCourses();

    return (
        <div>
            <h1>Courses</h1>
            <div className="course-list">
                
            </div>
        </div>
    );
};

export default CoursesPage;

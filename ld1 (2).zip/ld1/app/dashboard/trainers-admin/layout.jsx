"use client";
import { Footer } from "@/components/layout/footer";
import Header from "@/components/layout/header";
import SidebarComponent from "@/components/layout/sidebar";
import { SidebarProvider } from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

const TrainersAdminLayout = ({ children }) => {
    const { data: session, status } = useSession();
    const router = useRouter();
    const [isSidebarOpen, setIsSidebarOpen] = useState(true); // Default to open

    useEffect(() => {
        if (status === "loading") return;
        if (!session || session.user.roles !== "Trainers Admin") {
            router.push("/login");
        }
    }, [session, status, router]);

    if (status === "loading" || !session) {
        return <div className="flex h-screen bg-gray-100"></div>;
    }

    return (
        <SidebarProvider>
            <div className="flex h-screen w-full overflow-hidden">
                <SidebarComponent
                    dashboardType="TrainersAdmin"
                    isOpen={isSidebarOpen}
                    setIsOpen={setIsSidebarOpen}
                />
                <div className="flex flex-col flex-1 overflow-hidden">
                    <Header onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)} />
                    <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background pt-16 md:pt-0">
                    {/* flex-1 overflow-x-hidden overflow-y-auto bg-background pt-16 md:pt-0 */}
                    {/* flex-grow max-w-7xl mx-auto py-6 sm:px-6 lg:px-8 */}
                        <div >
                        {/* className="container mx-auto px-4 sm:px-6 lg:px-8 py-8" */}
                            {children}
                        </div>
                    </main>
                    
                    <Footer /> {/* Add your Footer if needed */}
                </div>
            </div>
        </SidebarProvider>
    );
};

export default TrainersAdminLayout;


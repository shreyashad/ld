"use client";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Pencil, Trash2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import toast from "react-hot-toast";
import { AlertModal } from "../dashboard/alert-modal";



export function CourseCategoryCellAction({ data }) {
    const router = useRouter();
    const [alertModalOpen, setAlterModalOpen] = useState(false);

    const handleEdit = () => {
        router.push(`/dashboard/trainers-admin/course-management/category/${data.id}`);
    }

    const deleteCategory = async (id) => {
        try {

        } catch (error) {
            toast.error()
        }
    };

    return (
        <div className="flex justify-center space-x-2">
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                             className="hover:bg-secondary"
                             onClick={handleEdit}
                        >
                            <Pencil className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Update Course Category</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="ghost"
                            size="icon"
                             className="hover:bg-secondary"
                             onClick={() => {
                                setAlterModalOpen(true);
                             }}
                        >
                            <Trash2 className="h-4 w-4 text-foreground" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                        <p>Delete Course Category</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
            <AlertModal 
                title="Are you sure?"
                description="This action cannot be undone."
                name={data.name}
                isOpen={alertModalOpen}
                onClose={() => setAlterModalOpen(false)}
                onConfirm={() => deleteCategory(data.id)}
                loading={false}
            />

        </div>
    );
}
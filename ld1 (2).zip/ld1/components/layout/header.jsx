import { Bell, Menu, Search, User } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import Notification from "./notification"
import UserNav from "./user-nav"
import { ThemeToggle } from "./theme-toggle"

export default function Header({ onMenuClick }) {
  return (
    <header className="bg-background border-b fixed top-0 left-0 right-0 z-30 md:relative">
      <div className="flex items-center justify-between px-4 py-4 md:px-6">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" className="md:hidden mr-2" onClick={onMenuClick}>
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex flex-col">
              <span className="font-bold text-indigo">MDIndia Health Insurance TPA Pvt. Ltd.</span>
              
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <Notification />
          <ThemeToggle />
          <UserNav />
        </div>
      </div>
    </header>
  )
}
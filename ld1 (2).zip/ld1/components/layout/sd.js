'use client'

import React from 'react'
import Link from 'next/link'
import { Home, ShoppingCart, Users, BarChart, Settings, LogOut, ChevronRight } from 'lucide-react'
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarTrigger,
} from '@/components/ui/sidebar'
import { Button } from '@/components/ui/button'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible'

interface SidebarProps {
  dashboardType: string
}

const contentItems = [
  { icon: Home, label: 'Home', href: '/dashboard' },
  { icon: ShoppingCart, label: 'Orders', href: '/dashboard/orders' },
  { icon: Users, label: 'Customers', href: '/dashboard/customers' },
  { icon: BarChart, label: 'Analytics', href: '/dashboard/analytics' },
]

const settingsItems = [
  { icon: Settings, label: 'General', href: '/dashboard/settings/general' },
  { icon: Settings, label: 'Security', href: '/dashboard/settings/security' },
  { icon: Settings, label: 'Notifications', href: '/dashboard/settings/notifications' },
]

export default function SidebarComponent({ dashboardType }: SidebarProps) {
  return (
    <Sidebar>
      <SidebarHeader>
        <div className="p-4">
          <h2 className="text-xl font-bold">Dashboard</h2>
        </div>
      </SidebarHeader>
      <SidebarContent className="flex flex-col h-full">
        <Collapsible defaultOpen className="flex-grow">
          <CollapsibleTrigger asChild>
            <SidebarTrigger className="w-full flex justify-between items-center p-4 hover:bg-muted/50">
              <span>Toggle Sidebar</span>
              <ChevronRight className="h-4 w-4" />
            </SidebarTrigger>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <SidebarGroup>
              <SidebarGroupLabel>Content</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {contentItems.map((item) => (
                    <SidebarMenuItem key={item.href}>
                      <SidebarMenuButton
                        asChild
                        isActive={dashboardType === item.label.toLowerCase()}
                      >
                        <Link href={item.href} className="flex items-center space-x-2">
                          <item.icon className="h-5 w-5" />
                          <span>{item.label}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
            <SidebarGroup>
              <SidebarGroupLabel>Settings</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {settingsItems.map((item) => (
                    <SidebarMenuItem key={item.href}>
                      <SidebarMenuButton
                        asChild
                        isActive={dashboardType === item.label.toLowerCase()}
                      >
                        <Link href={item.href} className="flex items-center space-x-2">
                          <item.icon className="h-5 w-5" />
                          <span>{item.label}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </CollapsibleContent>
        </Collapsible>
        <div className="mt-auto p-4">
          <Button variant="outline" className="w-full flex items-center justify-center space-x-2">
            <LogOut className="h-5 w-5" />
            <span>Logout</span>
          </Button>
        </div>
      </SidebarContent>
    </Sidebar>
  )
}
------------------------------------
"use client";
import { useIsMobile } from "@/hooks/use-mobile";
import { Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarHeader, SidebarMenu, SidebarProvider, SidebarMenuItem, SidebarMenuButton } from "../ui/sidebar";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuLabel, DropdownMenuGroup, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuContent, DropdownMenuShortcut } from "../ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { useSession } from "next-auth/react";
import { AudioWaveform, BadgeCheck, Bell, ChevronsUpDown, Command, CreditCard, GalleryVerticalEnd, LogOut, Plus } from "lucide-react";
import { useState } from "react";

const data ={
    teams: [
        {
          name: "Acme Inc",
          logo: GalleryVerticalEnd,
          plan: "Enterprise",
        },
        {
          name: "Acme Corp.",
          logo: AudioWaveform,
          plan: "Startup",
        },
        {
          name: "Evil Corp.",
          logo: Command,
          plan: "Free",
        },
      ],
}

export default function SidebarComponent({ dashboardType }) {
    const isMobile = useIsMobile();
    const [activeTeam, setActiveTeam] = useState(data.teams[0]);
    const { data: session } = useSession();
    return(
        <Sidebar collapsible="icon">
            <SidebarHeader>
                <SidebarMenu>
            <SidebarMenuItem>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <SidebarMenuButton
                    size="lg"
                    className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                  >
                    <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
                      <activeTeam.logo className="size-4" />
                    </div>
                    <div className="grid flex-1 text-left text-sm leading-tight">
                      <span className="truncate font-semibold">
                        {activeTeam.name}
                      </span>
                      <span className="truncate text-xs">
                        {activeTeam.plan}
                      </span>
                    </div>
                    <ChevronsUpDown className="ml-auto" />
                  </SidebarMenuButton>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  className="w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg"
                  align="start"
                  side={isMobile ? "bottom" : "right"}
                  sideOffset={4}
                >
                  <DropdownMenuLabel className="text-xs text-muted-foreground">
                    Teams
                  </DropdownMenuLabel>
                  {data.teams.map((team, index) => (
                    <DropdownMenuItem
                      key={team.name}
                      onClick={() => setActiveTeam(team)}
                      className="gap-2 p-2"
                    >
                      <div className="flex size-6 items-center justify-center rounded-sm border">
                        <team.logo className="size-4 shrink-0" />
                      </div>
                      {team.name}
                      <DropdownMenuShortcut>⌘{index + 1}</DropdownMenuShortcut>
                    </DropdownMenuItem>
                  ))}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="gap-2 p-2">
                    <div className="flex size-6 items-center justify-center rounded-md border bg-background">
                      <Plus className="size-4" />
                    </div>
                    <div className="font-medium text-muted-foreground">
                      Add team
                    </div>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </SidebarMenuItem>
          </SidebarMenu>
            </SidebarHeader>
                <SidebarContent>
                    <SidebarGroup>
                    </SidebarGroup>
                    <SidebarGroup>
                    </SidebarGroup>
                </SidebarContent>
                <SidebarFooter>
                    <SidebarMenu>
                    <SidebarMenuItem>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <SidebarMenuButton
                    size="lg"
                    className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
                  >
                    <Avatar className="h-8 w-8 rounded-lg">
                        <AvatarImage src={session.user.profile_picture} alt={session.user.first_name} /> 
                        <AvatarFallback className="bg-blue">{session.user.first_name.split(' ').map(n => n[0].toUpperCase()).join('')}{session.user.last_name.split(' ').map(n => n[0].toUpperCase()).join('')}</AvatarFallback>
                    </Avatar>
                    <div className="grid flex-1 text-left text-sm leading-tight">
                      <span className="truncate font-semibold">
                        {session.user.name}
                      </span>
                      <span className="truncate text-xs">
                        {session.user.email}
                      </span>
                    </div>
                    <ChevronsUpDown className="ml-auto size-4" />
                  </SidebarMenuButton>
                </DropdownMenuTrigger>
                
                <DropdownMenuContent
                  className="w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg"
                  side={isMobile ? "bottom" : "right"}
                  align="end"
                  sideOffset={4}
                >
                  <DropdownMenuLabel className="p-0 font-normal">
                    <div className="flex items-center gap-2 px-1 py-1.5 text-left text-sm">
                      <Avatar className="h-8 w-8 rounded-lg">
                        <AvatarImage src={session.user.profile_picture} alt={session.user.first_name} /> 
                        <AvatarFallback className="bg-blue">{session.user.first_name.split(' ').map(n => n[0].toUpperCase()).join('')}{session.user.last_name.split(' ').map(n => n[0].toUpperCase()).join('')}</AvatarFallback>
                      </Avatar>
                      <div className="grid flex-1 text-left text-sm leading-tight">
                        <span className="truncate font-semibold">
                          {session.user.first_name}
                        </span>
                        <span className="truncate text-xs">
                          {session.user.email}
                        </span>
                      </div>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuGroup>
                    <DropdownMenuItem>
                      <BadgeCheck />
                      Account
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <CreditCard />
                      Billing
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Bell />
                      Notifications
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <LogOut />
                    Log out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </SidebarMenuItem>
                    </SidebarMenu>
                </SidebarFooter>
        </Sidebar>
       
    )
}
-----------------------------------
"use client";
import { useIsMobile } from "@/hooks/use-mobile";
import { Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarHeader, SidebarMenu, SidebarProvider, SidebarMenuItem, SidebarMenuButton, SidebarTrigger, SidebarGroupLabel, SidebarGroupContent } from "../ui/sidebar";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuLabel, DropdownMenuGroup, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuContent, DropdownMenuShortcut } from "../ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { useSession } from "next-auth/react";
import { AudioWaveform, BadgeCheck, BarChart, Bell, ChevronLeft, ChevronRight, ChevronsUpDown, Command, CreditCard, GalleryVerticalEnd, Home, LogOut, Plus, Settings, ShoppingCart, Users } from "lucide-react";
import { useState } from "react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "../ui/collapsible";
import Link from "next/link";
import { Button } from "../ui/button";
import { cn } from "@/lib/utils";

const data ={
    teams: [
        {
          name: "Acme Inc",
          logo: GalleryVerticalEnd,
          plan: "Enterprise",
        },
        {
          name: "Acme Corp.",
          logo: AudioWaveform,
          plan: "Startup",
        },
        {
          name: "Evil Corp.",
          logo: Command,
          plan: "Free",
        },
      ],
}

const contentItems = [
    { icon: Home, label: 'Home', href: '/dashboard' },
    { icon: ShoppingCart, label: 'Orders', href: '/dashboard/orders' },
    { icon: Users, label: 'Customers', href: '/dashboard/customers' },
    { icon: BarChart, label: 'Analytics', href: '/dashboard/analytics' },
  ]
  
  const settingsItems = [
    { icon: Settings, label: 'General', href: '/dashboard/settings/general' },
    { icon: Settings, label: 'Security', href: '/dashboard/settings/security' },
    { icon: Settings, label: 'Notifications', href: '/dashboard/settings/notifications' },
  ]
  
export default function SidebarComponent({ dashboardType }) {
    const isMobile = useIsMobile();
    const [activeTeam, setActiveTeam] = useState(data.teams[0]);
    const { data: session } = useSession();
    const [isCollapsed, setIsCollapsed] = useState(false)
    return(
        <Sidebar className={cn("transition-all duration-300", isCollapsed ? "w-16" : "w-64")}>
      <SidebarHeader>
        <div className={cn("p-4 flex items-center", isCollapsed ? "justify-center" : "justify-between")}>
          {!isCollapsed && <h2 className="text-xl font-bold">Dashboard</h2>}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsCollapsed(!isCollapsed)}
            aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>
      </SidebarHeader>
      <SidebarContent className="flex flex-col h-full">
        <SidebarGroup>
          {!isCollapsed && <SidebarGroupLabel>Content</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              {contentItems.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    asChild
                    isActive={dashboardType === item.label.toLowerCase()}
                    className={cn(isCollapsed && "justify-center")}
                  >
                    <Link href={item.href} className="flex items-center space-x-2">
                      <item.icon className="h-5 w-5" />
                      {!isCollapsed && <span>{item.label}</span>}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <SidebarGroup>
          {!isCollapsed && <SidebarGroupLabel>Settings</SidebarGroupLabel>}
          <SidebarGroupContent>
            <SidebarMenu>
              {settingsItems.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    asChild
                    isActive={dashboardType === item.label.toLowerCase()}
                    className={cn(isCollapsed && "justify-center")}
                  >
                    <Link href={item.href} className="flex items-center space-x-2">
                      <item.icon className="h-5 w-5" />
                      {!isCollapsed && <span>{item.label}</span>}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <div className={cn("mt-auto p-4", isCollapsed && "flex justify-center")}>
          <Button
            variant="outline"
            className={cn("flex items-center justify-center space-x-2", isCollapsed && "w-10 h-10 p-0")}
          >
            <LogOut className="h-5 w-5" />
            {!isCollapsed && <span>Logout</span>}
          </Button>
        </div>
      </SidebarContent>
    </Sidebar>       
    )
}
------------------
"use client";
import { useIsMobile } from "@/hooks/use-mobile";
import { Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarHeader, SidebarMenu, SidebarProvider, SidebarMenuItem, SidebarMenuButton, SidebarTrigger, SidebarGroupLabel, SidebarGroupContent } from "../ui/sidebar";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuLabel, DropdownMenuGroup, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuContent, DropdownMenuShortcut } from "../ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { useSession } from "next-auth/react";
import { AudioWaveform, BadgeCheck, BarChart, Bell, ChevronLeft, ChevronRight, ChevronsUpDown, Command, CreditCard, GalleryVerticalEnd, Home, LogOut, Plus, Settings, ShoppingCart, Users } from "lucide-react";
import { useEffect, useState } from "react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "../ui/collapsible";
import Link from "next/link";
import { Button } from "../ui/button";
import { cn } from "@/lib/utils";
import { dashboardData } from "./sidebar-menu-list";

const data ={
    teams: [
        {
          name: "Acme Inc",
          logo: GalleryVerticalEnd,
          plan: "Enterprise",
        },
        {
          name: "Acme Corp.",
          logo: AudioWaveform,
          plan: "Startup",
        },
        {
          name: "Evil Corp.",
          logo: Command,
          plan: "Free",
        },
      ],
}

  const contentItems = [
    { icon: Home, label: 'Home', href: '/dashboard' },
    { icon: ShoppingCart, label: 'Orders', href: '/dashboard/orders' },
    { icon: Users, label: 'Customers', href: '/dashboard/customers' },
    { icon: BarChart, label: 'Analytics', href: '/dashboard/analytics' },
  ]
  
  const settingsItems = [
    { icon: Settings, label: 'General', href: '/dashboard/settings/general' },
    { icon: Settings, label: 'Security', href: '/dashboard/settings/security' },
    { icon: Settings, label: 'Notifications', href: '/dashboard/settings/notifications' },
  ]
  
export default function SidebarComponent({ dashboardType }) {
    const [isCollapsed, setIsCollapsed] = useState(false)
    const [isMobile, setIsMobile] = useState(false)

    useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 768)
      setIsCollapsed(window.innerWidth < 1024)
    }

    checkScreenSize()
    window.addEventListener('resize', checkScreenSize)

    return () => window.removeEventListener('resize', checkScreenSize)
    }, [])

    const menuItems = dashboardData[dashboardType] || [];
    return(
        <Sidebar className={cn(
            "transition-all duration-300 fixed left-0 top-0 h-full z-40",
            isCollapsed ? "w-16" : "w-64",
            isMobile && (isCollapsed ? "-translate-x-full" : "translate-x-0")
          )}>
            <SidebarHeader>
              <div className={cn("p-4 flex items-center", isCollapsed ? "justify-center" : "justify-between")}>
                {!isCollapsed && <h2 className="text-xl font-bold">Dashboard</h2>}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsCollapsed(!isCollapsed)}
                  aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
                >
                  {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
                </Button>
              </div>
            </SidebarHeader>
            <SidebarContent className="flex flex-col h-full">
              <SidebarGroup>
                {!isCollapsed && <SidebarGroupLabel>Content</SidebarGroupLabel>}
                <SidebarGroupContent>
                  <SidebarMenu>
                    {contentItems.map((item) => (
                      <SidebarMenuItem key={item.href}>
                        <SidebarMenuButton
                          asChild
                          isActive={dashboardType === item.label.toLowerCase()}
                          className={cn(isCollapsed && "justify-center")}
                        >
                          <Link href={item.href} className="flex items-center space-x-2">
                            <item.icon className="h-5 w-5" />
                            {!isCollapsed && <span>{item.label}</span>}
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
              <SidebarGroup>
                {!isCollapsed && <SidebarGroupLabel>Settings</SidebarGroupLabel>}
                <SidebarGroupContent>
                  <SidebarMenu>
                    {settingsItems.map((item) => (
                      <SidebarMenuItem key={item.href}>
                        <SidebarMenuButton
                          asChild
                          isActive={dashboardType === item.label.toLowerCase()}
                          className={cn(isCollapsed && "justify-center")}
                        >
                          <Link href={item.href} className="flex items-center space-x-2">
                            <item.icon className="h-5 w-5" />
                            {!isCollapsed && <span>{item.label}</span>}
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
              <div className={cn("mt-auto p-4", isCollapsed && "flex justify-center")}>
                <Button
                  variant="outline"
                  className={cn("flex items-center justify-center space-x-2", isCollapsed && "w-10 h-10 p-0")}
                >
                  <LogOut className="h-5 w-5" />
                  {!isCollapsed && <span>Logout</span>}
                </Button>
              </div>
            </SidebarContent>
          </Sidebar>
        )
}
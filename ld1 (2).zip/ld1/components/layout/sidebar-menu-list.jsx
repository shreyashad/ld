import { Bookmark, LayoutGrid, Settings, SquarePen, Tag, Users } from "lucide-react";
import { GrCatalog } from "react-icons/gr";
import { MdOnDeviceTraining, MdOutgoingMail, MdPermMedia  } from "react-icons/md";
import { GiNotebook, GiWisdom  } from "react-icons/gi";
import { GrAchievement } from "react-icons/gr";

export const dashboardData = {
    TrainersAdmin : [
        {
            groupLabel: "",
            menus: [
              {
                href: "/dashboard/trainers-admin",
                label: "Dashboard",
                icon: LayoutGrid,
                submenus: []
              }
            ]
        },
        {
            groupLabel: "Contents",
            menus:[
                {
                    href: "/dashboard/trainers-admin/course-management",
                    label: "Course Management",
                    icon: MdPermMedia ,
                    submenus: [
                      {
                        href: "/dashboard/trainers-admin/course-management/category",
                        label: "Course Category"
                      },
                      {
                        href: "/dashboard/trainers-admin/course-management/courses",
                        label: "Courses"
                      },
                      {
                        href: "/dashboard/trainers-admin/course-management/modules",
                        label: "Module"
                      },
                      {
                        href: "/dashboard/trainers-admin/course-management/videos",
                        label: "Video"
                      },
                      
                    ]
                },
                {
                    href: "/dashboard/trainers-admin/examination-management",
                    label: "Examination Management",
                    icon: GiNotebook,
                    submenus:[
                      {
                        href: "/dashboard/trainers-admin/examination-management/exam",
                        label: "Exam"
                      },
                      {
                        href: "/dashboard/trainers-admin/examination-management/questions",
                        label: "Questions"
                      },
                      {
                        href: "/dashboard/trainers-admin/examination-management/results",
                        label: "Results"
                      },
                      
                    ]
                },
                {
                  href: "/dashboard/trainers-admin/course-management",
                  label: "Traning Request",
                  icon: MdOutgoingMail,
                },
                {
                  href: "/dashboard/trainers-admin/course-management",
                  label: "Training Management",
                  icon: SquarePen,
                },
                {
                  href: "/dashboard/trainers-admin/course-management",
                  label: "Today Wisdom",
                  icon: GiWisdom ,
                },
                {
                  href: "/dashboard/trainers-admin/course-management",
                  label: "Trainers",
                  icon: SquarePen,
                },
                {
                  href: "/dashboard/trainers-admin/course-management",
                  label: "Course Management",
                  icon: SquarePen,
                },
                {
                  href: "/dashboard/trainers-admin/course-management",
                  label: "Course Management",
                  icon: SquarePen,
                },
            ]
        },
        {
          groupLabel: "Settings",
          menus: [
            {
              href: "/dashboard/trainers-admin/profile",
              label: "Users",
              icon: Users
            },
            {
              href: "/account",
              label: "Account",
              icon: Settings
            }
          ]
      }
    ],
    HOD: [
        {
            groupLabel: "",
            menus: [
              {
                href: "/dashboard/hod",
                label: "Dashboard",
                icon: LayoutGrid,
                submenus: []
              }
            ]
        },
        {
            groupLabel: "Contents",
            menus: [
              {
                href:"/dashboard/hod/courses",
                label: "Courses",
                icon: GrCatalog,
              },
              {
                href:"/dashboard/hod/my-courses",
                label: "My Courses",
                icon: GrCatalog,
              },
              {
                href:"/dashboard/hod/training-request",
                label: "Trainings Request",
                icon: MdOutgoingMail, 
              },
              {
                href:"/dashboard/hod/trainings",
                label: "Trainings",
                icon: MdOnDeviceTraining, 
              },
              {
                href:"/dashboard/hod/exams",
                label: "Exams",
                icon: GiNotebook, 
              },
              {
                href:"/dashboard/hod/my-progress",
                label: "My Progress",
                icon: GrAchievement , 
              },
              {
                href: "/dashboard/hod/teams",
                label: "Teams",
                icon: SquarePen,
                submenus: [
                  {
                    href: "/dashboard/hod/posts/new",
                    label: "Team Performance"
                  },
                  {
                    href: "/dashboard/hod/",
                    label: "Team Member"
                  },
                  
                ]
              },
              
              
            ]
        },
        {
            groupLabel: "Settings",
            menus: [
              {
                href: "/dashboard/hod/profile",
                label: "Users",
                icon: Users
              },
              {
                href: "/account",
                label: "Account",
                icon: Settings
              }
            ]
        }
    ],
    Trainer: [],
    Employee:[],
}
"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroupLabel,
  SidebarGroupContent,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
} from "../ui/sidebar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "../ui/collapsible";
import { Button } from "../ui/button";
import { ChevronLeft, ChevronRight, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { dashboardData } from "./sidebar-menu-list";
import Image from "next/image";

export default function SidebarComponent({ dashboardType, isOpen, setIsOpen }) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 768);
      setIsCollapsed(window.innerWidth < 1024);
    };

    checkScreenSize();
    window.addEventListener('resize', checkScreenSize);

    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  const menuItems = dashboardData[dashboardType] || [];

  return (
    <Sidebar
      className={cn(
        "transition-all duration-300 fixed left-0 top-0 h-full z-40",
        isCollapsed ? "w-16" : "w-64",
        isMobile && (isCollapsed ? "-translate-x-full" : "translate-x-0"),
        !isOpen && "hidden" // Hide if not open
      )}
    >
      <SidebarHeader>
        <div className={cn("p-4 flex items-center", isCollapsed ? "justify-center" : "justify-between")}>
          {!isCollapsed && <Image src="/mdi_logo1.png" width={50} height={50}/>}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsCollapsed(!isCollapsed)}
            aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>
      </SidebarHeader>
      <SidebarContent className="flex flex-col h-full">
        {menuItems.map((group) => (
          <SidebarGroup key={group.groupLabel}>
            {!isCollapsed && <SidebarGroupLabel>{group.groupLabel}</SidebarGroupLabel>}
            <SidebarGroupContent>
              <SidebarMenu>
                {group.menus.map((menu) => (
                  <SidebarMenuItem key={menu.href}>
                    <SidebarMenuButton asChild isActive={dashboardType === menu.label.toLowerCase()} className={cn(isCollapsed && "justify-center")}>
                      <Link href={menu.href} className="flex items-center space-x-2">
                        <menu.icon className="h-5 w-5" />
                        {!isCollapsed && <span>{menu.label}</span>}
                        {Array.isArray(menu.submenus) && menu.submenus.length > 0 && (
                          <Collapsible>
                          <ChevronRight className={`ml-auto transition-transform duration-200`} />
                          </Collapsible>
                        )}
                      </Link>
                    </SidebarMenuButton>

                    {/* Only show submenus if they exist */}
                    {Array.isArray(menu.submenus) && menu.submenus.length > 0 && (
                      <Collapsible>
                        <CollapsibleTrigger className="flex items-center justify-between w-full">
                          <menu.icon className="h-5 w-5" />
                          <span>{!isCollapsed ? menu.label : ""}</span> {/* Show the menu label when expanded */}
                          <ChevronRight className={`ml-auto transition-transform duration-200`} />
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <SidebarMenuSub>
                            {menu.submenus.map((submenu) => (
                              <SidebarMenuSubItem key={submenu.href}>
                                <SidebarMenuSubButton asChild>
                                  <Link href={submenu.href} className="flex items-center space-x-2 pl-8"> {/* Indent for submenus */}
                                    <span>{submenu.label}</span>
                                  </Link>
                                </SidebarMenuSubButton>
                              </SidebarMenuSubItem>
                            ))}
                          </SidebarMenuSub>
                        </CollapsibleContent>
                      </Collapsible>
                    )}
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
        <div className={cn("mt-auto p-4", isCollapsed && "flex justify-center")}>
          <Button
            variant="outline"
            className={cn("flex items-center justify-center space-x-2", isCollapsed && "w-10 h-10 p-0")}
          >
            <LogOut className="h-5 w-5" />
            {!isCollapsed && <span>Logout</span>}
          </Button>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}

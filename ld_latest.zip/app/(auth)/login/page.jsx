"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { signIn, useSession } from "next-auth/react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { z } from "zod";


const loginSchema = z.object({
    username: z.string().min(1, "Username is required"),
    password: z.string().min(6, "Password must be at least 6 characters long"),
});

export default function LoginPage() {
    const [formData, setFormData] = useState({
        username: '',
        password: '',
    });

    const [formErrors, setFormErrors] = useState({});
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { data: session, status } = useSession();
    const router = useRouter();

    useEffect(() => {
        if (status === 'loading') return;

        if (session?.user) {
            const userRole = session.user.roles;
            if (!userRole) {
                setErrorMessage("User role not found. Please contact support.");
                return;
            }
            
            switch (userRole) {
                case "Trainers Admin":
                    router.push("/dashboard/trainers-admin");
                    break;
                case "Trainer":
                    router.push("/dashboard/trainer");
                    break;
                case "HOD's":
                    router.push("/dashboard/hod");
                    break;
                case "Employee":
                    router.push("/dashboard/employee");
                    break;
                default:
                    router.push("/");
            }
        }
    }, [session, status, router]);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setIsLoading(true);
        setErrorMessage('');
        setSuccessMessage('');
        setFormErrors({});

        try {
            // Validate form data with Zod
            loginSchema.parse(formData);
            const result = await signIn('credentials', { ...formData, redirect: false });

            if (result?.error) {
                const errorMessage = result.error.includes('User does not have access to this application')
                    ? 'You do not have access to this application. Please contact support.'
                    : result.error;

                setErrorMessage(errorMessage);
            } else {
                setSuccessMessage("Login successful. Redirecting...");
            }
        } catch (err) {
            if (err instanceof z.ZodError) {
                const fieldErrors = {};
                err.errors.forEach((issue) => {
                    fieldErrors[issue.path[0]] = issue.message;
                });
                setFormErrors(fieldErrors);
            } else {
                console.error('Login error:', err);
                setErrorMessage('An error occurred. Please try again');
            }
        } finally {
            setIsLoading(false);
        }
    };

    const handleChange = (event) => {
        setFormData({ ...formData, [event.target.name]: event.target.value });
    };

    return (
        <div className="w-full lg:grid lg:min-h-[500px] lg:grid-cols-2 xl:min-h-[600px]">
            <div className="flex items-center justify-center py-10">
                <Card className="mx-auto max-w-sm">
                    <CardHeader>
                        <CardTitle className="text-2xl text-center">Login</CardTitle>
                        <CardDescription>
                            Enter your credentials below to login to your account
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid gap-4">
                            {(errorMessage || successMessage) && (
                                <div
                                    className={`${
                                        errorMessage ? 'bg-red-100 border border-red-400 text-red-700' : 'bg-green-100 border border-green-400 text-green-700'
                                    } px-4 py-3 rounded relative`}
                                    role="alert"
                                >
                                    <strong className="font-bold">{errorMessage ? 'Error:' : 'Success:'} </strong>
                                    <span className="block sm:inline">{errorMessage || successMessage}</span>
                                </div>
                            )}
                            <form onSubmit={handleSubmit}>
                                <div className="grid gap-2">
                                    <Label>Username</Label>
                                    <Input 
                                        type="text"
                                        id="username"
                                        name="username"
                                        value={formData.username}
                                        onChange={handleChange}
                                        required
                                        className={formErrors.username ? 'border-red-500' : ''}
                                    />
                                    {formErrors.username && <p className="text-red-500">{formErrors.username}</p>}
                                </div>
                                <div className="grid gap-2">
                                    <div className="flex items-center">
                                        <Label>Password</Label>
                                        <Link href="/auth/forget-password" className="ml-auto inline-block text-sm underline">
                                            Forgot password?
                                        </Link>
                                    </div>
                                    <Input
                                        type="password"
                                        id="password"
                                        name="password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        required
                                        className={formErrors.password ? 'border-red-500' : ''}
                                    />
                                    {formErrors.password && <p className="text-red-500">{formErrors.password}</p>}
                                </div>
                                <Button type="submit" className="w-full mt-4" disabled={isLoading}>
                                    {isLoading ? 'Logging in...' : 'Login'}
                                </Button>
                            </form>
                        </div>
                        <div className="mt-4 text-center text-sm">
                            Don't have an account?{" "}
                            <Link href="/register" className="underline">Sign Up</Link>
                        </div>
                    </CardContent>
                </Card>
            </div>
            <div className="hidden bg-muted lg:block">
                <Image
                    src="/boy-with-rocket-light.png"
                    alt="Image"
                    width="1920"
                    height="1080"
                    className="h-full w-full object-cover dark:brightness-[0.2] dark:grayscale"
                />
            </div>
        </div>
    );
}

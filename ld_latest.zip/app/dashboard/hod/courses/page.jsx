import { fetchCourseListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import CourseListCard from "@/components/course/course-list-card";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export default async function HodCoursePage() {
    const session = await auth();
    const courseData = await fetchCourseListData(session.accessToken);
    console.log("course data:", courseData);
    return(
        <div className="flex flex-col gap-4 p-4  md:gap-8 md:p-8">
            <DashboardBreadCrumb 
                homelink="/dashboard/hod/" 
                hometitle="Home" 
                mdipagelink="/dashboard/hod/courses/" 
                mdipagetitle="Course Management" 
                pagetitle="Course "
            />
            <Card className="shadow-2xl mt-10 relative">
                <CardHeader className="pb-3">
                    <CardTitle>Course </CardTitle>
                    <CardDescription className="max-w-lg text-balance leading-relaxed">
                        Manage your courses module and videos all in one place.
                        
                    </CardDescription>
                </CardHeader>
                <Separator />
                <CardContent>
                    <div class="min-h-screen bg-gradient-to-tr from-red-300 to-yellow-200 flex justify-center items-center py-20">
                        <div class="md:px-4 md:grid md:grid-cols-2 lg:grid-cols-3 gap-5 space-y-4 md:space-y-0">
                            {courseData.map((course) => (
                                <CourseListCard key={course.id} course={course} />
                            ))}
                        </div>
                    </div>
                </CardContent>
           </Card>
        </div>
    );
}
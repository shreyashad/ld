import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Progress } from "@/components/ui/progress"
import { BarChart, Users, Calendar as CalendarIcon, Award, Search, Bell, DollarSign, Clock, Star } from "lucide-react"

export default function EnhancedTrainersDashboard() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  // Dummy data for the chart
  const chartData = [
    { month: 'Jan', completed: 65 },
    { month: 'Feb', completed: 75 },
    { month: 'Mar', completed: 85 },
    { month: 'Apr', completed: 70 },
    { month: 'May', completed: 90 },
    { month: 'Jun', completed: 80 },
  ]

  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">Enhanced Trainers Admin Dashboard</h1>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Input type="search" placeholder="Search trainers or courses..." className="pl-10 pr-4" />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            </div>
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Admin" />
              <AvatarFallback>AD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <main className="flex-grow max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Trainers</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">128</div>
                <p className="text-xs text-muted-foreground">+4% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Courses</CardTitle>
                <BarChart className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">45</div>
                <p className="text-xs text-muted-foreground">+12% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Upcoming Sessions</CardTitle>
                <CalendarIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">23</div>
                <p className="text-xs text-muted-foreground">For next 7 days</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
                <Award className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">87%</div>
                <p className="text-xs text-muted-foreground">+5% from last month</p>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8">
            <Tabs defaultValue="overview">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="calendar">Calendar</TabsTrigger>
                <TabsTrigger value="feedback">Feedback</TabsTrigger>
                <TabsTrigger value="finance">Finance</TabsTrigger>
              </TabsList>
              <TabsContent value="overview">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Training Completion Rates</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-[200px] w-full">
                        {/* Simple bar chart implementation */}
                        <div className="flex h-full items-end space-x-2">
                          {chartData.map((data, index) => (
                            <div key={index} className="flex-1 bg-blue-500" style={{ height: `${data.completed}%` }}>
                              <div className="text-xs text-center">{data.month}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Course Progress Tracker</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Advanced React Patterns</span>
                            <span>75%</span>
                          </div>
                          <Progress value={75} />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Data Science Fundamentals</span>
                            <span>60%</span>
                          </div>
                          <Progress value={60} />
                        </div>
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>UI/UX Design Principles</span>
                            <span>90%</span>
                          </div>
                          <Progress value={90} />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="calendar">
                <Card>
                  <CardHeader>
                    <CardTitle>Training Calendar</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      className="rounded-md border"
                    />
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="feedback">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Feedback</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        { name: "John Doe", course: "Advanced React Patterns", rating: 4.8 },
                        { name: "Jane Smith", course: "Data Science Fundamentals", rating: 4.5 },
                        { name: "Alice Johnson", course: "UI/UX Design Principles", rating: 4.9 },
                      ].map((feedback, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{feedback.name}</p>
                            <p className="text-sm text-muted-foreground">{feedback.course}</p>
                          </div>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-400 mr-1" />
                            <span>{feedback.rating}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="finance">
                <Card>
                  <CardHeader>
                    <CardTitle>Financial Overview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span>Total Revenue</span>
                        <span className="font-bold">$125,000</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Expenses</span>
                        <span className="font-bold">$45,000</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Net Profit</span>
                        <span className="font-bold text-green-600">$80,000</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Recent Training Sessions</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Course Name</TableHead>
                      <TableHead>Trainer</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Attendees</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>Advanced React Patterns</TableCell>
                      <TableCell>John Doe</TableCell>
                      <TableCell>2023-06-15</TableCell>
                      <TableCell>24</TableCell>
                      <TableCell>Completed</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>Data Science Fundamentals</TableCell>
                      <TableCell>Jane Smith</TableCell>
                      <TableCell>2023-06-14</TableCell>
                      <TableCell>18</TableCell>
                      <TableCell>In Progress</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>UI/UX Design Principles</TableCell>
                      <TableCell>Alice Johnson</TableCell>
                      <TableCell>2023-06-13</TableCell>
                      <TableCell>20</TableCell>
                      <TableCell>Completed</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Top Performing Trainers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "John Doe", rating: 4.9, courses: 12 },
                    { name: "Jane Smith", rating: 4.8, courses: 10 },
                    { name: "Alice Johnson", rating: 4.7, courses: 8 },
                  ].map((trainer, index) => (
                    <div key={index} className="flex items-center space-x-4">
                      <Avatar>
                        <AvatarImage src={`/placeholder.svg?height=40&width=40`} />
                        <AvatarFallback>{trainer.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{trainer.name}</p>
                        <p className="text-xs text-muted-foreground">Rating: {trainer.rating} | Courses: {trainer.courses}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Trainer Availability</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "John Doe", availability: "Mon, Wed, Fri" },
                    { name: "Jane Smith", availability: "Tue, Thu, Sat" },
                    { name: "Alice Johnson", availability: "Mon, Tue, Wed" },
                  ].map((trainer, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span>{trainer.name}</span>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span className="text-sm">{trainer.availability}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
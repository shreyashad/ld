import { fetchSimilarDeptUsersList, fetchTeamDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { TeamForm } from "@/components/teams/team-form";


function getTeamId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode org ID');
        return data;
    }
}

export default async function EditTeam({params}) {
    const { id } = params;
    const session = await auth();
    
    if (!session){
        return new Response("Unauthorized", { status: 401 });
    }

    let usersWithSameDept = [];
    let teamData = null;
    let isLoadingUsers = true;
    let isLoadingTeam = true;

    try {
        // Fetch the list of users in the same department
        usersWithSameDept = await fetchSimilarDeptUsersList(session.accessToken);
        console.log("similar users list:", usersWithSameDept);
        isLoadingUsers = false;
    } catch (error) {
        console.error('Error fetching users with same department:', error);
        isLoadingUsers = false;
        // Handle the case when fetching users fails (could be by showing a fallback or error message)
    }




    try {
        if (id !== "new") {
            // Handle the case for editing an existing team
            const TeamId = getTeamId(id);
            teamData = await fetchTeamDetails(session.accessToken, TeamId);
            isLoadingTeam = false; // Finished loading team details
        } else {
            // Handle the case for creating a new team
            teamData = {}; // Empty object for a new team
            isLoadingTeam = false; // No need to load team data for new team
        }
    } catch (error) {
        console.error("Error fetching team details:", error);
        isLoadingTeam = false;
        // Optionally handle this error (maybe show a fallback message)
    }

    return (
        <div className="flex flex-col">
            {/* Show loading states while data is being fetched */}
            {isLoadingUsers || isLoadingTeam ? (
                <div>Loading...</div> // You can replace this with a spinner or other loading indicator
            ) : (
                <TeamForm 
                    initialData={teamData || {}} 
                    usersList={usersWithSameDept || []}
                />
            )}
        </div>
   );
};
import { fetchCourseListData, fetchHODTrainingRequest, fetchSimilarDeptUsersList, fetchUserByAppRole } from "@/app/api/server/route";
import { auth } from "@/auth";
import HODTrainingRequestDashboard from "@/components/hod/training-request/hod-training-request-dashboard";


export default async function HODTrainingRequestPage() {
    const session = await auth();

    const reqData = await fetchHODTrainingRequest(session.accessToken);
    console.log("hod request data:", reqData);
    
    const courseListData = await fetchCourseListData(session.accessToken);
    
    const application_name = process.env.APP_NAME;
    const role = "Trainers Admin";

    const trainerAdminList = await fetchUserByAppRole(session.accessToken, application_name, role);

    const teamEmployeeList = await fetchSimilarDeptUsersList(session.accessToken);
    console.log("team emp list:", teamEmployeeList);

    return(
       
            <HODTrainingRequestDashboard initialRequestData={reqData} courseListData={courseListData} receiverListData={trainerAdminList} employeeListData={teamEmployeeList} />
       
    );
};
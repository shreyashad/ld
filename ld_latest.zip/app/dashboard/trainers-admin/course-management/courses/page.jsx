import { fetchCourseListData } from '@/app/api/server/route'
import { auth } from '@/auth'
import { DashboardBreadCrumb } from '@/components/dashboard/dashboard-breadcrumb'
import ErrorMessage from '@/components/dashboard/error-message'
import LoadingSpinner from '@/components/dashboard/loadining-spinner'
import CourseList from '@/components/trainers-admin/course-management/course-list'
import { Suspense } from 'react'


// // Mock function to fetch courses (replace with actual API call in a real app)
// async function fetchCourses() {
//   // Simulate API delay and potential error
//   await new Promise(resolve => setTimeout(resolve, 1000))
  
//   // Simulate a 10% chance of an error
//   if (Math.random() < 0.1) {
//     throw new Error('Failed to fetch courses')
//   }

//   return [
//     { id: 1, title: 'Introduction to React', category: 'Web Development', difficulty_level: 'Beginner', duration: 120 },
//     { id: 2, title: 'Advanced JavaScript', category: 'Web Development', difficulty_level: 'Advanced', duration: 180 },
//     { id: 3, title: 'Python for Data Science', category: 'Data Science', difficulty_level: 'Intermediate', duration: 150 },
//     { id: 4, title: 'Machine Learning Basics', category: 'Data Science', difficulty_level: 'Beginner', duration: 200 },
//     { id: 5, title: 'Mobile App Development with React Native', category: 'Mobile Development', difficulty_level: 'Intermediate', duration: 160 },
//   ]
// }

async function CourseListWrapper() {
  const session = auth();
  try {
    const courses = await fetchCourseListData(session.accessToken);
    const categories = [...new Set(courses?.map(course => course.category))]
    return <CourseList initialCourses={courses} initialCategories={categories} />
  } catch (error) {
    return <ErrorMessage message={error.message} />
  }
}

export default async function CoursePage() {
  

  return (
    <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
    {/* Fixed breadcrumb */}
    <div className="fixed w-full shadow-2xl p-4 z-10 ">
        <DashboardBreadCrumb 
            homelink="/dashboard/trainers-admin/" 
            hometitle="Home" 
            mdipagelink="/dashboard/trainers-admin/course-management/Course" 
            mdipagetitle="Course Management" 
            pagetitle="Course "
        />
    </div>

    {/* Spacer to prevent content from being hidden behind the fixed breadcrumb */}
    <div className="mt-16" /> 

      <h1 className="text-3xl font-bold mb-8">Courses</h1>
      <Suspense fallback={<LoadingSpinner />}>
        <CourseListWrapper />
      </Suspense>
    </div>
  )
}


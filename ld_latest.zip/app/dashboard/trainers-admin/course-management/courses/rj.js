import { Suspense } from 'react'
import CourseList from '@/components/CourseList'
import ErrorMessage from '@/components/ErrorMessage'
import LoadingSpinner from '@/components/LoadingSpinner'

// Mock function to fetch courses (replace with actual API call in a real app)
async function fetchCourses() {
  // Simulate API delay and potential error
  await new Promise(resolve => setTimeout(resolve, 1000))
  
  // Simulate a 10% chance of an error
  if (Math.random() < 0.1) {
    throw new Error('Failed to fetch courses')
  }

  return [
    { id: 1, title: 'Introduction to React', category: 'Web Development', difficulty_level: 'Beginner', duration: 120 },
    { id: 2, title: 'Advanced JavaScript', category: 'Web Development', difficulty_level: 'Advanced', duration: 180 },
    { id: 3, title: 'Python for Data Science', category: 'Data Science', difficulty_level: 'Intermediate', duration: 150 },
    { id: 4, title: 'Machine Learning Basics', category: 'Data Science', difficulty_level: 'Beginner', duration: 200 },
    { id: 5, title: 'Mobile App Development with React Native', category: 'Mobile Development', difficulty_level: 'Intermediate', duration: 160 },
  ]
}

async function CourseListWrapper() {
  try {
    const courses = await fetchCourses()
    const categories = [...new Set(courses.map(course => course.category))]
    return <CourseList initialCourses={courses} initialCategories={categories} />
  } catch (error) {
    return <ErrorMessage message={error.message} />
  }
}

export default function CoursePage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Courses</h1>
      <Suspense fallback={<LoadingSpinner />}>
        <CourseListWrapper />
      </Suspense>
    </div>
  )
}


"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Separator } from "../ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CourseSchema } from "@/schema";
import { Input } from "../ui/input";
import Image from "next/image";
import { Textarea } from "../ui/textarea";
import { Button } from "../ui/button";
import toast from "react-hot-toast";
import { useEffect, useState } from "react";
import { Trash } from "lucide-react";

export const CourseForm = ({ initialData }) => {
    const router = useRouter();
    const { data: session } = useSession();

    const title = initialData && initialData.id ? "Edit Course" : "Create Course";
    const description = initialData && initialData.id ? "Edit the course details" : "Create a new course";
    const action = initialData && initialData.id ? "Save Changes" : "Create";
    const toastMessage = initialData && initialData.id ? "Course updated successfully" : "Course created successfully";

    const [loading, setLoading] = useState(false);

    // course models
    // title = models.CharField(max_length=200, unique=True)
    // slug = AutoSlugField(populate_from='title', unique=True)
    // description = models.TextField()
    // category = models.ForeignKey(CourseCategory, on_delete=models.DO_NOTHING)
    // cover_image = models.ImageField(upload_to='course_images/', null=True, blank=True)
    // duration = models.DurationField()
    // difficulty_level = models.CharField(max_length=50)
    // prerequisites = models.ManyToManyField('self', symmetrical=False, blank=True, related_name='prerequisite_courses')
    // certification = models.CharField(max_length=255, null=True, blank=True)
    // learning_objectives = models.TextField(blank=True, null=True)
    // status = models.CharField(max_length=50, choices=StatusChoice)

    
// class Module(BaseModel):
// title = models.CharField(max_length=250)
// description = models.TextField()
// cover_image = models.ImageField(upload_to='module_images/', blank=True, null=True)
// order = models.PositiveIntegerField(default=0)
// course = models.ForeignKey(Course, on_delete=models.CASCADE)
// status = models.CharField(max_length=50, choices=StatusChoice)

// class Meta:
//     verbose_name = "Module"
//     verbose_name_plural = "Modules"
//     ordering = ['title']
//     unique_together = ('course', 'title')

// def __str__(self):
//     return f"{self.title}"


// class VideoLesson(BaseModel):
// module = models.ForeignKey(Module, on_delete=models.CASCADE, related_name='video_lessons')
// title = models.CharField(max_length=200)
// video_url = models.FileField(upload_to='video_lessons/', validators= [FileExtensionValidator(allowed_extensions=['mp4', 'avi', 'mov', 'mkv'])])
// cover_image = models.ImageField(upload_to='video_images/', blank=True, null=True)
// description = models.TextField(blank=True, null=True)
// duration = models.DurationField(help_text="Duration of the video lesson")
// order = models.PositiveIntegerField(default=0)
// status = models.CharField(max_length=50, choices=StatusChoice)

// class Meta:
//     verbose_name = "Video Lesson"
//     verbose_name_plural = "Video Lessons"
//     ordering = ['title']
//     unique_together = ('module', 'title')


// def __str__(self):
//     return self.title


// class Material(BaseModel):
// module = models.ForeignKey(Module, on_delete=models.CASCADE, related_name='materials')
// title = models.CharField(max_length=200, db_index=True)
// file = models.FileField(upload_to='materials/', validators=[
//     FileExtensionValidator(allowed_extensions=['pdf', 'docx', 'pptx', 'xlsx', 'txt'])])
// description = models.TextField(blank=True, null=True)
// status = models.CharField(max_length=50, choices=StatusChoice)

// class Meta:
//     verbose_name = "Material"
//     verbose_name_plural = "Materials"
//     ordering = ['title']
//     unique_together = ('module', 'title')


// def __str__(self):
//     return self.title

// class CourseReview(models.Model):
// user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
// course = models.ForeignKey(Course, on_delete=models.CASCADE)
// rating = models.PositiveIntegerField()
// comment = models.TextField(blank=True, null=True)
// created_at = models.DateTimeField(auto_now_add=True)

// class Meta:
//     unique_together = ('user', 'course')



    
    const form = useForm({
        resolver: zodResolver(CourseSchema),
        defaultValues: initialData || {
            title: "",
            description: "",
            coverImage: "",
            modules: [{ title: "", videos: [{ title: "", duration: "" }] }],
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const { fields: moduleFields, append: appendModule, remove: removeModule } = useFieldArray({
        control: form.control,
        name: "modules",
    });

    const onSubmit = async (values) => {
        try {
            // Handle create or update logic
            if (initialData && initialData.id) {
                // Update logic
                await updateCourse(session.accessToken, initialData.id, values);
            } else {
                // Create logic
                await createCourse(session.accessToken, values);
            }
            toast.success(toastMessage);
            router.refresh();
        } catch (error) {
            toast.error(error.message);
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <Separator />
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="grid grid-cols-2 gap-8">
                            <FormField
                                control={form.control}
                                name="title"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Course Title</FormLabel>
                                        <FormControl>
                                            <Input
                                                placeholder="Enter course title"
                                                {...field}
                                                disabled={loading}
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="coverImage"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Cover Image URL</FormLabel>
                                        <FormControl>
                                            <Input
                                                placeholder="Enter image URL"
                                                {...field}
                                                disabled={loading}
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="description"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Description</FormLabel>
                                        <FormControl>
                                            <Textarea
                                                {...field}
                                                placeholder="Course Description"
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>

                        <div>
                            <h3>Modules</h3>
                            {moduleFields.map((module, index) => (
                                <div key={module.id} className="border p-4 rounded mb-4">
                                    <FormField
                                        control={form.control}
                                        name={`modules.${index}.title`}
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Module Title</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...field}
                                                        placeholder="Enter module title"
                                                        disabled={loading}
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <h4>Videos</h4>
                                    {form.watch(`modules.${index}.videos`).map((video, videoIndex) => (
                                        <div key={videoIndex} className="border p-2 rounded mb-2">
                                            <FormField
                                                control={form.control}
                                                name={`modules.${index}.videos.${videoIndex}.title`}
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Video Title</FormLabel>
                                                        <FormControl>
                                                            <Input
                                                                {...field}
                                                                placeholder="Enter video title"
                                                                disabled={loading}
                                                            />
                                                        </FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                            <FormField
                                                control={form.control}
                                                name={`modules.${index}.videos.${videoIndex}.duration`}
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Duration</FormLabel>
                                                        <FormControl>
                                                            <Input
                                                                {...field}
                                                                placeholder="Enter duration"
                                                                disabled={loading}
                                                            />
                                                        </FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                            <Button type="button" onClick={() => remove(videoIndex)}>
                                                Remove Video
                                            </Button>
                                        </div>
                                    ))}
                                    <Button type="button" onClick={() => appendVideo({ title: "", duration: "" })}>
                                        Add Video
                                    </Button>
                                    <Button type="button" onClick={() => removeModule(index)}>
                                        Remove Module
                                    </Button>
                                </div>
                            ))}
                            <Button type="button" onClick={() => appendModule({ title: "", videos: [] })}>
                                Add Module
                            </Button>
                        </div>

                        <Button disabled={loading} type="submit" className="ml-auto">
                            {action}
                        </Button>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};

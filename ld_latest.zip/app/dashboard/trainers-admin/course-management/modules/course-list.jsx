import { useState } from "react"
import { Star, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

// Mock data for demonstration
const courses = [
  {
    id: 1,
    title: "Introduction to React",
    description: "Learn the basics of React and build your first app",
    coverImage: "/placeholder.svg",
    rating: 4.5,
    enrolledCount: 1234,
    price: 49.99,
    modules: [
      {
        title: "Getting Started",
        videos: [
          { title: "What is React?", duration: "10:00" },
          { title: "Setting up your development environment", duration: "15:00" },
        ],
      },
      {
        title: "React Fundamentals",
        videos: [
          { title: "Components and Props", duration: "20:00" },
          { title: "State and Lifecycle", duration: "25:00" },
        ],
      },
    ],
  },
  // Add more courses here...
]

export default function CourseList() {
  const [selectedCourse, setSelectedCourse] = useState(null)

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">Available Courses</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course) => (
          <Card key={course.id} className="flex flex-col">
            <CardHeader>
              <img src={course.coverImage} alt={course.title} className="w-full h-48 object-cover rounded-t-lg" />
            </CardHeader>
            <CardContent className="flex-grow">
              <CardTitle className="mb-2">{course.title}</CardTitle>
              <p className="text-sm text-gray-600 mb-2">{course.description}</p>
              <div className="flex items-center mb-2">
                <Star className="w-4 h-4 text-yellow-400 mr-1" />
                <span className="text-sm font-medium">{course.rating}</span>
                <span className="text-sm text-gray-600 ml-2">({course.enrolledCount} enrolled)</span>
              </div>
              <p className="text-lg font-bold">${course.price.toFixed(2)}</p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" onClick={() => setSelectedCourse(course)}>View Details</Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>{course.title}</DialogTitle>
                  </DialogHeader>
                  <ScrollArea className="max-h-[60vh]">
                    <div className="space-y-4">
                      <img src={course.coverImage} alt={course.title} className="w-full h-64 object-cover rounded-lg" />
                      <p>{course.description}</p>
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-400 mr-1" />
                        <span className="font-medium">{course.rating}</span>
                        <span className="text-gray-600 ml-2">({course.enrolledCount} enrolled)</span>
                      </div>
                      <p className="text-xl font-bold">${course.price.toFixed(2)}</p>
                      <Accordion type="single" collapsible className="w-full">
                        {course.modules.map((module, index) => (
                          <AccordionItem value={`module-${index}`} key={index}>
                            <AccordionTrigger>{module.title}</AccordionTrigger>
                            <AccordionContent>
                              <ul className="space-y-2">
                                {module.videos.map((video, vIndex) => (
                                  <li key={vIndex} className="flex justify-between items-center">
                                    <span>{video.title}</span>
                                    <span className="text-sm text-gray-600">{video.duration}</span>
                                  </li>
                                ))}
                              </ul>
                            </AccordionContent>
                          </AccordionItem>
                        ))}
                      </Accordion>
                    </div>
                  </ScrollArea>
                </DialogContent>
              </Dialog>
              <Button>Enroll Now</Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}
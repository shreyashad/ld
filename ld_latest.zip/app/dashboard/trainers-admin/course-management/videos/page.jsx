import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import VideoEditor from "@/components/trainers-admin/course-management/video-editor";

export default async function VideoEditerPage() {
    return(
        <div className="flex flex-col gap-4 p-4  md:gap-8 md:p-8">
            <DashboardBreadCrumb 
                homelink="/dashboard/trainers-admin/" 
                hometitle="Home" 
                mdipagelink="/dashboard/trainers-admin/course-management/video" 
                mdipagetitle="Course Management" 
                pagetitle="Video Editor "
            />

           <VideoEditor className="mt-10 pt-15" />
        </div>
    );
};
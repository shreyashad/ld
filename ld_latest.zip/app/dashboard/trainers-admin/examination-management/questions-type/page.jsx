import { fetchQuestionTypeListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import QuestionTypeClient from "@/components/trainers-admin/examination/category/que-cat-client";
import { QuestionTypeColumns } from "@/components/trainers-admin/examination/category/que-cat-columns";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";


export default async function QuestionTypePage() {
    const session = await auth();
    const queTypeData = await fetchQuestionTypeListData(session.accessToken);

    return(
        <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <DashboardBreadCrumb
                homelink="/dashboard/trainers-admin/"
                hometitle="Dashboard"
                mdipagelink="/dashboard/trainers-admin/examination-management/questions-type/"
                mdipagetitle="Examination Management"
                pagetitle="Question Type"
            />
            <Separator className="mt-8" />
            <Card>
                <CardHeader>
                    <CardTitle>Question Type Management</CardTitle>
                    <div className="grid grid-cols-2 gap-8">
                        <CardDescription>
                            Manage your all types of topics in one place.
                        </CardDescription>
                        <QuestionTypeClient />
                    </div>
                    
                </CardHeader>
                <CardContent>
                    <DataTable columns={QuestionTypeColumns} data={queTypeData}/>
                </CardContent>
            </Card>
        </div>
    );
};
"use client";
import { Footer } from "@/components/layout/footer";
import Header from "@/components/layout/header";
import SidebarComponent from "@/components/layout/sidebar";
import { Separator } from "@/components/ui/separator";
import { SidebarInset, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

const TrainersAdminLayout = ({ children }) => {
    const { data: session, status } = useSession();
    const router = useRouter();
    const [isSidebarOpen, setIsSidebarOpen] = useState(true); // Default to open

    useEffect(() => {
        if (status === "loading") return;
        if (!session || session.user.roles !== "Trainers Admin") {
            router.push("/login");
        }
    }, [session, status, router]);

    if (status === "loading" || !session) {
        return <div className="flex h-screen bg-gray-100"></div>;
    }

    return (
        <SidebarProvider>
            <SidebarComponent dashboardType="TrainersAdmin"/>
        <SidebarInset>
        <Header />
        
            <main>
            {children}
            </main>
           
       



             {/* <main className="flex w-full flex-col overflow-hidden bg-slate-100"></main> */}
        
      </SidebarInset>
        </SidebarProvider>
    );
};

export default TrainersAdminLayout;

{/* <SidebarProvider>
        <div className="flex min-h-screen flex-col">
            <Header />
            <div className="flex-1 items-start md:grid md:grid-cols-[220px_minmax(0,1fr)] md:gap-6 lg:grid-cols-[240px_minmax(0,1fr)] lg:gap-10">
            <aside className="fixed top-14 z-30 -ml-2 hidden h-[calc(100vh-3.5rem)] w-full shrink-0 overflow-y-auto border-r md:sticky md:block">
                <SidebarComponent dashboardType="TrainersAdmin" />
            </aside>
            <main className="flex w-full flex-col overflow-hidden">{children}</main>
            </div>
        </div>
        </SidebarProvider> */}
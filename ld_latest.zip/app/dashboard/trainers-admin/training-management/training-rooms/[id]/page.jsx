import { fetchTrainingRoomDetails } from "@/app/api/server/route";
import { auth } from "@/auth";
import { TrainingRoomForm } from "@/components/trainers-admin/training-room/training-room-form";

function getRoomId(data) {
    try {
        return decodeURIComponent(data);
    } catch (error) {
        console.error('Failed to decode org ID');
        return data;
    }
}


export default async function EditTrainingRoom({params}) {
    const { id } = params;
    const session = await auth();

    if (!session){
        return new Response("Unauthorized", { status: 401 });
    }
    let roomData = null;

    if (id === "new") {
        // Handle the case for creating a new organization
        roomData = {}; // Pass an empty object for a new organization
    } else {
        // Handle the case for editing an existing organization
        const RoomId = getRoomId(id);
        roomData = await fetchTrainingRoomDetails(session.accessToken,RoomId);
    }
    return (
        <div className="flex flex-col">
            <TrainingRoomForm initialData={ roomData || {}}/>
        </div>
   );
};
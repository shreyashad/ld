import { fetchTrainingRoomListData } from "@/app/api/server/route";
import { auth } from "@/auth";
import { DashboardBreadCrumb } from "@/components/dashboard/dashboard-breadcrumb";
import TrainingRoomClient from "@/components/trainers-admin/training-room/training-room-client";
import { TrainingRoomColumns } from "@/components/trainers-admin/training-room/training-room-columns";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DataTable } from "@/components/ui/data-table/data-table";
import { Separator } from "@/components/ui/separator";


export default async function TrainingRoomPage() {
    const session = await auth();
    const roomsData = await fetchTrainingRoomListData(session.accessToken);

    return (
        <div className="flex flex-col gap-4 p-4 md:gap-8 md:p-8">
            {/* Fixed breadcrumb */}
            <div className="fixed w-full shadow-2xl p-4 z-10 ">
                <DashboardBreadCrumb 
                    homelink="/dashboard/trainers-admin/" 
                    hometitle="Home" 
                    mdipagelink="/dashboard/trainers-admin/training-management/training-rooms" 
                    mdipagetitle="Training Management" 
                    pagetitle="Training Rooms"
                />
            </div>

            {/* Spacer to prevent content from being hidden behind the fixed breadcrumb */}
            <div className="mt-16" /> {/* Adjust height as needed to match the breadcrumb's height */}
            
            <Card className="shadow-2xl">
                <CardHeader className="pb-3">
                    <CardTitle>Training Rooms</CardTitle>
                    <CardDescription className="max-w-lg text-balance leading-relaxed">
                        Manage your training rooms in one place.
                        <TrainingRoomClient />
                    </CardDescription>
                </CardHeader>
                <Separator />
                <CardContent>
                    <DataTable columns={TrainingRoomColumns} data={roomsData} />
                </CardContent>
            </Card>
        </div>
    );
}
import NextAuth from "next-auth";
import CredentialProvider from "next-auth/providers/credentials";
import { fetchApplicationdetails, validateTicket } from "./app/api/server/route";
import axios from "axios";


const API_CAS_URL = process.env.NEXT_PUBLIC_AUTH_SERVER_API_BASE_URL || "";

export const { handlers, signIn, signOut, auth } = NextAuth({
    providers: [
        CredentialProvider({
            name: "Credentials",
            credentials: {
                username: { label: "Username", type: "text" },
                password: { label: "Password", type: "password" }
            },
            async authorize(credentials) {
                try{
                    const application = await fetchApplicationdetails();
                    const applicationId = application.app.id;

                    const response = await axios.post(`${API_CAS_URL}api/login/`,{
                        username: credentials.username,
                        password: credentials.password,
                        application_id: applicationId,
                    });

                    if (response.status !== 200) {
                        throw new Error("Invalid credentials or application issue");
                    }

                    const user = response.data;
                    const userDetails = await validateTicket(user.service_ticket, applicationId);

                    if (userDetails) {
                        return {
                            id: userDetails.id || user.id,
                            roles: userDetails.roles,
                            permissions: userDetails.permissions,
                            profile_pic: userDetails.profile_picture,
                            first_name: userDetails.first_name,
                            last_name: userDetails.last_name,
                            org_type: userDetails.org_type,
                            org_name: userDetails.org_name,
                            org_sub_type: userDetails.org_sub_type,
                            location_type: userDetails.location_type,
                            location_name: userDetails.location_name,
                            location_code: userDetails.location_code,
                            emp_code: userDetails.emp_code,
                            department: userDetails.department,
                            designation: userDetails.designation,
                            accessToken: user.access, // Ensure token is passed
                            refreshToken: user.refresh,
                            sessionKey: user.session_key,
                            service_ticket: user.service_ticket, 
                            sessionExp: new Date(user.session_expires_at).getTime(),

                        };
                    } else {
                        throw new Error("Invalid service ticket");
                    }
                } catch (error) {
                    console.error('Authentication failed:', error.response?.data?.error || error.message);
                    throw new Error(error.response?.data?.error || "Authentication failed");
                }
            },
        }),
    ],
    pages: {
        signIn: "/login"
    },
    callbacks: {
        async jwt({ token, user }) {
            if (user) {
                token.accessToken = user.accessToken;
                token.refreshToken = user.refreshToken;
                token.sessionKey = user.sessionKey;
                token.sessionExp = user.sessionExp;
                token.user = user;
            }
            if (Date.now() > token.sessionExp) {
                try{
                    const response = await axios.post(`${API_CAS_URL}api/token/refresh/`,{
                        refresh: token.refreshToken,
                    });
                    
                    if (response.status === 200) {
                        token.accessToken = response.data.access;
                        token.refreshToken = response.data.refresh;
                        token.sessionExp = Date.now() + (60 * 60 * 1000);
                    } else {
                        throw new Error("Token refresh failed");
                    }
                } catch (error) {
                    console.error("Error refreshing token:", error);
                    throw new Error("Session expired, please log in again.");
                }
            }
            return token;
        },
        async session({ session, token }) {
            if (!token || !token.accessToken) {
                // If there's no valid token, handle it as expired
                session.error = "Session expired, please log in again.";
                return session;
            }

            session.accessToken = token.accessToken;
            session.refreshToken = token.refreshToken;
            session.sessionKey = token.sessionKey;
            session.sessionExp = token.sessionExp;
            session.user = token.user
            console.log("users session details:", session);
            return session;
        }
    },
    session: {
        strategy: "jwt",
    },
    server: {
        trustedHosts: ["localhost:3005"]
    },
});
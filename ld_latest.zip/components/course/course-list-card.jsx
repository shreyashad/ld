"use client";
import Image from "next/image";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../ui/card";
import { Star } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../ui/dialog";
import { useState } from "react";
import { Button } from "../ui/button";
import { ScrollArea } from "../ui/scroll-area";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";


export default function CourseListCard({ course }) {
    const [selectedCourse, setSelectedCourse] = useState(null)
    return(
        <Card key={course.id} className="flex flex-col">
            <CardHeader>
              <Image src={course.coverImage} alt={course.title} className="w-full h-48 object-cover rounded-t-lg" />
            </CardHeader>
            <CardContent className="flex-grow">
              <CardTitle className="mb-2">{course.title}</CardTitle>
              <p className="text-sm text-gray-600 mb-2">{course.description}</p>
              <div className="flex items-center mb-2">
                <Star className="w-4 h-4 text-yellow-400 mr-1" />
                <span className="text-sm font-medium">{course.rating}</span>
                <span className="text-sm text-gray-600 ml-2">({course.enrolledCount} enrolled)</span>
              </div>
              
            </CardContent>
            <CardFooter className="flex justify-between">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" onClick={() => setSelectedCourse(course)}>View Details</Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>{course.title}</DialogTitle>
                  </DialogHeader>
                  <ScrollArea className="max-h-[60vh]">
                    <div className="space-y-4">
                      <img src={course.coverImage} alt={course.title} className="w-full h-64 object-cover rounded-lg" />
                      <p>{course.description}</p>
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-400 mr-1" />
                        <span className="font-medium">{course.rating}</span>
                        <span className="text-gray-600 ml-2">({course.enrolledCount} enrolled)</span>
                      </div>
                      
                      <Accordion type="single" collapsible className="w-full">
                        {course.modules.map((module, index) => (
                          <AccordionItem  value={`module-${index}`} key={index}>
                            <AccordionTrigger>{module.title}</AccordionTrigger>
                            <AccordionContent>
                              <ul className="space-y-2">
                                {module.videos.map((video, vIndex) => (
                                  <li key={vIndex} className="flex justify-between items-center">
                                    <span>{video.title}</span>
                                    <span className="text-sm text-gray-600">{video.duration}</span>
                                  </li>
                                ))}
                              </ul>
                            </AccordionContent>
                          </AccordionItem>
                        ))}
                      </Accordion>
                    </div>
                  </ScrollArea>
                </DialogContent>
              </Dialog>
              <Button>Enroll Now</Button>
            </CardFooter>
          </Card>
    );
}
import Link from "next/link";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "../ui/breadcrumb";
import { HomeIcon } from "lucide-react";
import { MdHome } from "react-icons/md";


export const DashboardBreadCrumb = ({ homelink, hometitle, mdipagelink, mdipagetitle, pagetitle }) => {
    return(
        <div className="fixed flex-col-9 w-full bg-white shadow-2xl p-4 z-10  ">
        <Breadcrumb>
            <BreadcrumbList>
                <BreadcrumbItem>
                    <BreadcrumbLink asChild>
                        <Link href={homelink} className="inline-flex items-center"> <MdHome className="w-4 h-4"/>  {hometitle}</Link>
                    </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                    <BreadcrumbLink asChild>
                        <Link href={mdipagelink}>{mdipagetitle}</Link>
                    </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                    <BreadcrumbPage>{pagetitle}</BreadcrumbPage>
                </BreadcrumbItem>

            </BreadcrumbList>
        </Breadcrumb>
        </div>
    );
}
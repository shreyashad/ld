import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { CalendarIcon, Clock, Inbox, PlusCircle, Send, Users } from "lucide-react";


const NavItem = ({ icon: Icon, label, view, activeView, onClick1 }) => (
    <Button
      className={cn(
        "flex items-center gap-2 px-4 py-2 w-full text-left hover:bg-primary rounded-md",
        activeView === view && "bg-accent"
      )}
      onClick={() => onClick1(view)}
    >
      <Icon className="h-5 w-5" />
      <span>{label}</span>
    </Button>
  )

export default function HODTraininRequestNavBar ({ activeView, setActiveView }) {
    
    return (
        <div className="w-64 border-r p-4 flex flex-col ">
            <h1 className="text-2xl font-bold mb-6">Training Requests</h1>
            <nav className="space-y-2">
                <NavItem icon={Inbox} label="Inbox" view="inbox" />
                <NavItem icon={Send} label="Sent" view="sent" />
                <NavItem icon={CalendarIcon} label="Scheduled" view="scheduled" />
                <NavItem icon={Clock} label="Pending" view="pending" />
            </nav>
            <Button className="mt-auto" onClick={() => setActiveView("new")}>
                <PlusCircle className="mr-2 h-4 w-4" /> New Request
            </Button>
        </div>
    );
}; 
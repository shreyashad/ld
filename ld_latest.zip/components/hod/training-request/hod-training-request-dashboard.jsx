"use client";
import { createTrainingRequest } from "@/app/api/server/route";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Label } from "@/components/ui/label";
import MultiSelect from "@/components/ui/multi-select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { TrainingRequestSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { CalendarIcon, Check, ChevronsUpDown, Clock, Inbox, PlusCircle, Send } from "lucide-react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";


export default function HODTrainingRequestDashboard({ initialRequestData, courseListData, receiverListData, employeeListData }) {
    const { data: session } = useSession();
    const router = useRouter();

    const [activeView, setActiveView] = useState("inbox");
    const [requests, setRequests] = useState(initialRequestData);
    const [selectedItem, setSelectedItem] = useState(null);
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const [selectedReceiver, setSelectedReceiver] = useState("");

    const form = useForm({
        resolver: zodResolver(TrainingRequestSchema),
        defaultValues: {
            course: "",
            receiver: "",
            preferred_mode: "",
            employees:[],
            additional_notes:"",
            status:"pending",
        },
    });

    const employeeOptions = employeeListData.map((employee) => ({
        label: employee.username,
        value: employee.id,
    }));

    console.log("Active View:", activeView); 
    const handleRequestSubmit = async (values) => {
        console.log("Form Submit Triggered!");  // Check if this is logged when the button is clicked
        console.log("Form Values:", values); 
        const formattedValues = {
            course: values.course,  // Just the course ID (e.g., 1, 2, 3)
            employees: values.employees,  // Array of employee IDs
            receiver: values.receiver,
            preferred_mode: values.preferred_mode,
            additional_notes: values.additional_notes,
            status: "Pending",  // default status
        };

        setLoading(true);
        try {
            const response = await createTrainingRequest(session.accessToken, formattedValues);
            console.log("API Response:", response);
            
            if (response && !response.error) {
                toast.success("Training request created successfully!");
                setRequests((prevRequests) => [...prevRequests, formattedValues]);  // Add to requests
            } else {
                toast.error(response?.error || "Failed to create training request. Please try again.");
            }
        } catch (error) {
            console.error("Error submitting training request:", error);
            toast.error(error.message || "An error occurred. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    const NavItem = ({ icon: Icon, label, view }) => (
        <Button
            className={cn(
                "flex items-center gap-2 px-4 py-2 w-full text-left hover:bg-primary rounded-md",
                activeView === view && "bg-primary"
            )}
            onClick={() => setActiveView(view)}
        >
            <Icon className="h-5 w-5" />
            <span>{label}</span>
        </Button>
    );

    const RequestList = ({ items }) => {
        if (items.length === 0) {
            return <div>No training requests available.</div>;
        }
    
        return (
            <div className="space-y-2">
                {items.map((item) => (
                    <Card key={item.id} className="cursor-pointer" onClick={() => setSelectedItem(item)}>
                        <CardHeader>
                            <CardTitle>{item.course_info.title}</CardTitle>
                            <CardDescription><Badge variant={item.status === "Pending" ? "secondary" : "success"}>{item.status}</Badge></CardDescription>
                        </CardHeader>
                        <CardFooter>
                        {item.created_at}
                        </CardFooter>
                    </Card>
                    // <div key={item.id} className="cursor-pointer" onClick={() => setSelectedItem(item)}>
                    //     <div className="font-semibold">{item.course_info.title}</div>
                    //     <div className="text-sm text-muted-foreground">{item.created_at}</div>
                    //     <Badge variant={item.status === "Pending" ? "secondary" : "success"}>{item.status}</Badge>
                    // </div>
                ))}
            </div>
        );
    };

    // Filtering logic based on active view
    const filteredRequestData = initialRequestData.filter((r) => {
        switch (activeView) {
            case "sent":
                return true;
            case "inbox":
                return r.status !== "Pending";
            case "pending":
                return r.status === "Pending";
            case "scheduled":
                return r.status === "Scheduled";
            default:
                return false;
        }
    });

    return(
        <div className="flex h-screen bg-background">
            <div className="w-64 border-r p-4 flex flex-col ">
                <div>
                    <h1 className="text-2xl font-bold mb-6">Training Request Management</h1>
                    <nav className="space-y-2">
                        <NavItem icon={Inbox} label={"Inbox"} view={"inbox"} />
                        <NavItem icon={Send} label={"Sent Requests"} view={"sent"} />
                        <NavItem icon={Clock} label={"Pending"} view={"pending"} />
                        <NavItem icon={CalendarIcon} label={"Scheduled"} view={"scheduled"} />
                    </nav>
                </div>
                <Button className="mt-auto" onClick={() => setActiveView("new")}>
                    <PlusCircle className="mr-2 h-4 w-4" /> New Request
                </Button>
            </div>
            <div className="flex-1 flex">
                <div className="w-1/3 border-r p-4 overflow-auto">
                    <h2 className="text-xl font-semibold mb-4">
                        {
                            activeView === "inbox" ? "All Requests" :
                            activeView === "sent" ? "Sent Requests" :
                            activeView === "scheduled" ? "Scheduled Trainings" :
                            activeView === "pending" ? "Pending Trainings": ""
                        }
                    </h2>
                    {activeView !== "new" && <RequestList items={filteredRequestData} />}
                </div>
                <div className="flex-1 p-4 overflow-auto">
                    {
                        activeView === "new" ? (
                            <Card>
                                <CardHeader>
                                    <CardTitle>New Training Request</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <Form {...form}>
                                        <form 
                                            onSubmit={(e) => {
                                                e.preventDefault(); // Prevent default form submission behavior
                                                console.log("Form Submit Triggered!");
                                                handleRequestSubmit(form.getValues()); // Pass form data explicitly
                                            }}
                                        >
                                            <div className="space-y-6">
                                                <FormField 
                                                    control={form.control}
                                                    name="receiver"
                                                    render={({ field }) => (
                                                        <FormItem>
                                                            <FormLabel>To</FormLabel>
                                                            <FormControl>
                                                                <Popover open={open} onOpenChange={setOpen}>
                                                                    <PopoverTrigger asChild>
                                                                        <Button>
                                                                            {selectedReceiver || "Select Trainer's Admin "}
                                                                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                                                        </Button>
                                                                    </PopoverTrigger>
                                                                    <PopoverContent className="w-[200px] p-0">
                                                                        <Command>
                                                                            <CommandInput placeholder="Search receiver..." />
                                                                            <CommandList>
                                                                                <CommandEmpty> No receiver found. </CommandEmpty>
                                                                                <CommandGroup>
                                                                                    {receiverListData?.map((receiver) => (
                                                                                        <CommandItem
                                                                                            key={receiver.id}
                                                                                            onSelect={() => {
                                                                                                setSelectedReceiver(receiver.username);
                                                                                                form.setValue('receiver', receiver.id);
                                                                                                setOpen(false);
                                                                                            }}
                                                                                        >
                                                                                            <Check
                                                                                                className={`mr-2 h-4 w-4 ${selectedReceiver === receiver.id ? "opacity-100" : "opacity-0"}`}
                                                                                            />
                                                                                            {receiver.username}
                                                                                        </CommandItem>
                                                                                    ))}
                                                                                </CommandGroup>
                                                                            </CommandList>
                                                                        </Command>
                                                                    </PopoverContent>
                                                                </Popover>
                                                            </FormControl>
                                                        </FormItem>
                                                    )}
                                                />
                                            </div>
                                            <div className="grid grid-cols-2 gap-4">
                                                <div className="space-y-2">
                                                <FormField
                                                    control={form.control}
                                                    name="course"
                                                    render={({ field }) => (
                                                        <FormItem>
                                                            <FormLabel>Course Topic</FormLabel>
                                                            <Select
                                                                disabled={loading || !courseListData?.length}
                                                                onValueChange={(value) => {
                                                                    // Find the selected course from the courseListData
                                                                    const selectedCourse = courseListData.find(course => course.id === value);
                                                                    if (selectedCourse) {
                                                                        form.setValue('course', selectedCourse.id);  // Only set the course ID
                                                                    }
                                                                }}
                                                                value={field.value || ''}  // Set the selected course ID as the value
                                                            >
                                                                <FormControl>
                                                                    <SelectTrigger>
                                                                        <SelectValue placeholder={courseListData?.length > 0 ? "Course Topic" : "No Courses available"} />
                                                                    </SelectTrigger>
                                                                </FormControl>
                                                                <SelectContent>
                                                                    {courseListData?.length > 0 ? (
                                                                        courseListData.map((course) => (
                                                                            <SelectItem key={course.id} value={course.id}>
                                                                                {course.title}
                                                                            </SelectItem>
                                                                        ))
                                                                    ) : (
                                                                        <SelectItem disabled>No Course found</SelectItem>
                                                                    )}
                                                                </SelectContent>
                                                            </Select>
                                                            <FormMessage />
                                                        </FormItem>
                                                    )}
                                                />


                                                </div>
                                                <div className="space-y-2">
                                                    <FormField
                                                        control={form.control}
                                                        name="preferred_mode"
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Training Mode</FormLabel>
                                                                <Select
                                                                    disabled={loading}
                                                                    onValueChange={field.onChange}
                                                                    value={field.value}
                                                                >
                                                                    <FormControl>
                                                                        <SelectTrigger>
                                                                            <SelectValue placeholder="Training Mode" />
                                                                        </SelectTrigger>
                                                                    </FormControl>
                                                                    <SelectContent>
                                                                        <SelectItem value="online">Online</SelectItem>
                                                                        <SelectItem value="offline">Offline</SelectItem>
                                                                        <SelectItem value="self-learning">Self-learning</SelectItem>
                                                                    </SelectContent>
                                                                </Select>
                                                                <FormMessage />
                                                            </FormItem>
                                                        )}
                                                    />
                                                </div>
                                            </div>
                                            <FormField
                                                control={form.control}
                                                name="employee"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Employees</FormLabel>
                                                        <FormControl>
                                                            <MultiSelect
                                                                options={employeeOptions}
                                                                onValueChange={(value) => form.setValue('employees', value)}
                                                                defaultValue={field.value}
                                                                placeholder="Select employees"
                                                                variant="inverted"
                                                                animation={2}
                                                            
                                                            />
                                                        </FormControl>
                                                        <FormDescription>
                                                            Choose the Employees you are want training for.
                                                        </FormDescription>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                            <FormField 
                                                control={form.control}
                                                name="additional_notes"
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Additional Notes</FormLabel>
                                                        <FormControl>
                                                            <Textarea
                                                                {...field}
                                                                placeholder="Additional Notes"
                                                                disabled={loading}
                                                            />
                                                        </FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                            <div className="mt-4 space-x-4">
                                                <Button disabled={loading} className="ml-auto" type="submit">
                                                    {loading ? 'Submitting...' : 'Submit Request'}
                                                </Button>
                                                <Button
                                                    disabled={loading}
                                                    className="ml-auto"
                                                    type="button"
                                                    onClick={() => router.back()}
                                                >
                                                    Cancel
                                                </Button>
                                            </div>
                                        </form>

                                    </Form>
                                </CardContent>
                            </Card>
                        ) : selectedItem ? (
                            <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
                                <h2 className="text-3xl font-semibold mb-6">{selectedItem.course_info.title}</h2>

                                {/* Status Badge */}
                                <div className="mb-4">
                                    <Badge variant={selectedItem.status === "pending" ? "bg-amber-200" : "success"}>
                                        {selectedItem.status}
                                    </Badge>
                                </div>

                                {/* Date Requested */}
                                <div className="mb-4">
                                    <span className="font-semibold text-lg">Date Requested:</span> 
                                    <span>{new Date(selectedItem.created_at).toLocaleString()}</span>
                                </div>

                                {/* Employee Information */}
                                <div className="mb-4">
                                    <span className="font-semibold">To Assign Training for:</span>
                                    <ul className="list-disc pl-5">
                                        {selectedItem.employee_info && selectedItem.employee_info.length > 0 ? (
                                            selectedItem.employee_info.map((employee, index) => (
                                                <li key={index} className="text-gray-700">{employee.username}</li>
                                            ))
                                        ) : (
                                            <li className="text-gray-500">No employees assigned yet.</li>
                                        )}
                                    </ul>
                                </div>

                                {/* Additional Notes */}
                                <div className="mb-4">
                                    <p className="text-gray-600 mt-2">
                                        <span className="font-semibold">Additional Notes:</span> {selectedItem.additional_notes || "No additional notes provided."}
                                    </p>
                                </div>

                                {/* Conditional Rendering for Scheduled Training */}
                                {selectedItem.status === "Scheduled" && (
                                    <Card className="mt-6">
                                        <CardHeader>
                                            <CardTitle className="text-xl font-semibold">Training Details</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="space-y-4">
                                                <div><span className="font-semibold">Date:</span> {new Date(selectedItem.scheduledDate).toLocaleDateString()}</div>
                                                <div><span className="font-semibold">Time:</span> {new Date(selectedItem.scheduledTime).toLocaleTimeString()}</div>
                                                <div><span className="font-semibold">Trainer:</span> {selectedItem.trainer}</div>
                                                <div><span className="font-semibold">Room:</span> {selectedItem.room || "TBD"}</div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                )}

                                {/* If status is not Scheduled, show a generic message */}
                                {selectedItem.status !== "Scheduled" && (
                                    <div className="mt-6 text-center text-gray-500">
                                        <p>The training is not scheduled yet.</p>
                                    </div>
                                )}
                            </div>

                        ) : (
                            <div className="text-center text-muted-foreground">
                                {activeView === "new" ? "Fill out the form to create a new request" : "Select an item to view details"}
                            </div>
                        )
                    }
                </div>
            </div>
        </div>





        
    );
};
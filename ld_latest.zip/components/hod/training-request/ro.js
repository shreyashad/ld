"use client";

import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Clock, Inbox, PlusCircle, Send } from "lucide-react";
import HODTrainingRequestForm from "./hod-training-request-form";

export default function HODTrainingRequestDashboard({ initialRequestData, courseListData, receiverListData, employeeListData }) {
    const [activeView, setActiveView] = useState("inbox");  // default view is "inbox"
    const [selectedItem, setSelectedItem] = useState(null);
    const [requests, setRequests] = useState(initialRequestData);
    
    
    

    // Navigation item component for different views (Inbox, Sent, Pending, etc.)
    const NavItem = ({ icon: Icon, label, view }) => (
        <Button
            className={cn(
                "flex items-center gap-2 px-4 py-2 w-full text-left hover:bg-primary rounded-md",
                activeView === view && "bg-primary"
            )}
            onClick={() => setActiveView(view)}
        >
            <Icon className="h-5 w-5" />
            <span>{label}</span>
        </Button>
    );

    // Request list component that handles filtering and displays requests
    const RequestList = ({ items }) => {
        if (items.length === 0) {
            return <div>No training requests available.</div>;
        }
    
        return (
            <div className="space-y-2">
                {items.map((item) => (
                    <div key={item.id} className="cursor-pointer" onClick={() => setSelectedItem(item)}>
                        <div className="font-semibold">{item.course.title}</div>
                        <div className="text-sm text-muted-foreground">{item.created_at}</div>
                        <Badge variant={item.status === "Pending" ? "secondary" : "success"}>{item.status}</Badge>
                    </div>
                ))}
            </div>
        );
    };

    // Filtering logic based on active view
    const filteredRequestData = initialRequestData.filter((r) => {
        switch (activeView) {
            case "sent":
                return true;
            case "inbox":
                return r.status !== "Pending";
            case "pending":
                return r.status === "Pending";
            case "scheduled":
                return r.status === "Scheduled";
            default:
                return false;
        }
    });

    return (
        <>
            <div className="w-64 border-r p-4 flex flex-col">
                <h1 className="text-2xl font-bold mb-6">Request Management</h1>
                <nav className="space-y-2">
                    <NavItem icon={Inbox} label={"Inbox"} view={"inbox"} />
                    <NavItem icon={Send} label={"Sent Requests"} view={"sent"} />
                    <NavItem icon={Clock} label={"Pending"} view={"pending"} />
                </nav>
                <Button className="mt-auto" onClick={() => setActiveView("new")}>
                    <PlusCircle className="mr-2 h-4 w-4" /> New Request
                </Button>
            </div>

            <div className="flex-1 flex">
                {/* Left column - Request list */}
                <div className="w-1/3 border-r p-4 overflow-auto">
                    <h2 className="text-xl font-semibold mb-4">
                        {
                            activeView === "inbox" ? "All Requests" :
                            activeView === "sent" ? "Sent Requests" :
                            activeView === "scheduled" ? "Scheduled Trainings" : ""
                        }
                    </h2>
                    {activeView !== "new" && <RequestList items={filteredRequestData} />}
                </div>

                {/* Right column - Request details */}
                <div className="flex-1 p-4 overflow-auto">
                    {
                        activeView === "new" ? (
                            <HODTrainingRequestForm 
                                courseList={courseListData} 
                                receiverList={receiverListData} 
                                employeeList={employeeListData} 
                                onAddNewRequest={handleRequestSubmit}
                            />
                        ) : selectedItem ? (
                            <div>
                                <h2 className="text-2xl font-semibold mb-4">{selectedItem.subject}</h2>
                                <div className="mb-2">
                                    <Badge variant={selectedItem.status === "Pending" ? "secondary" : "success"}>
                                        {selectedItem.status}
                                    </Badge>
                                </div>
                                <div className="mb-4">
                                    <span className="font-semibold">Date Requested:</span> {selectedItem.date}
                                </div>
                                <div className="mb-4">{selectedItem.content}</div>

                                {selectedItem.status === "Scheduled" && (
                                    <Card>
                                        <CardHeader>
                                            <CardTitle>Training Details</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="space-y-2">
                                                <div><span className="font-semibold">Date:</span> {selectedItem.scheduledDate}</div>
                                                <div><span className="font-semibold">Time:</span> {selectedItem.scheduledTime}</div>
                                                <div><span className="font-semibold">Trainer:</span> {selectedItem.trainer}</div>
                                                <div><span className="font-semibold">Room:</span> {selectedItem.room}</div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                )}
                            </div>
                        ) : (
                            <div className="text-center text-muted-foreground">
                                {activeView === "new" ? "Fill out the form to create a new request" : "Select an item to view details"}
                            </div>
                        )
                    }
                </div>
            </div>
        </>
    );
}

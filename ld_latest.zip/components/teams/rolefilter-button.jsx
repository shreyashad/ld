"use client";
import { useRouter, useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button"; // Assuming you already have a Button component

const RoleFilterButton = () => {
    const router = useRouter();
    const searchParams = useSearchParams();
    const currentRole = searchParams.get("role") || "Leader"; // Default to "Leader" if no role is provided

    const handleRoleChange = (role) => {
        // Update the query parameter for the role
        router.push(`/dashboard/hod/team-management/teams/?role=${role}`);
    };

    return (
        <div >
            <Button
                onClick={() => handleRoleChange("Leader")}
                className={`mr-2 ${currentRole === "Leader" ? "bg-blue-500 text-white" : "bg-gray-200"}`}
            >
                Leaders
            </Button>
            <Button
                onClick={() => handleRoleChange("Member")}
                className={`${currentRole === "Member" ? "bg-blue-500 text-white" : "bg-gray-200"}`}
            >
                Members
            </Button>
        </div>
    );
};

export default RoleFilterButton;

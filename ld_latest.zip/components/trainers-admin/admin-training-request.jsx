"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PlusCircle, Send, Inbox, Clock, CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export default function HODTrainingRequestSystem() {
  const [activeView, setActiveView] = useState("new");
  const [selectedItem, setSelectedItem] = useState(null);
  const [requests, setRequests] = useState([
    { id: 1, subject: "React Training", status: "Pending", content: "Request for React training session for the frontend team.", date: "2023-06-15" },
    { id: 2, subject: "Python Workshop", status: "Scheduled", content: "Python workshop for the data science team.", date: "2023-06-10", scheduledDate: "2023-07-01", scheduledTime: "10:00 AM", trainer: "Jane Doe", room: "Training Room 1" },
  ]);

  const handleRequestSubmit = (e) => {
    e.preventDefault();
    const newRequest = {
      id: requests.length + 1,
      subject: e.target.subject.value,
      content: e.target.content.value,
      status: "Pending",
      date: new Date().toISOString().split('T')[0],
    };
    setRequests([newRequest, ...requests]);
    setActiveView("sent");
  };

  const NavItem = ({ icon: Icon, label, view }) => (
    <button
      className={cn(
        "flex items-center gap-2 px-4 py-2 w-full text-left hover:bg-accent rounded-md",
        activeView === view && "bg-accent"
      )}
      onClick={() => {
        setActiveView(view);
        setSelectedItem(null);
      }}
    >
      <Icon className="h-5 w-5" />
      <span>{label}</span>
    </button>
  );

  const RequestList = ({ items }) => (
    <div className="space-y-2">
      {items.map(item => (
        <div
          key={item.id}
          className={cn(
            "p-2 border rounded-md cursor-pointer hover:bg-accent",
            selectedItem?.id === item.id && "bg-accent"
          )}
          onClick={() => setSelectedItem(item)}
        >
          <div className="font-semibold">{item.subject}</div>
          <div className="text-sm text-muted-foreground">{item.date}</div>
          <Badge variant={item.status === "Pending" ? "secondary" : "success"}>{item.status}</Badge>
        </div>
      ))}
    </div>
  );

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="w-64 border-r p-4 flex flex-col">
        <h1 className="text-2xl font-bold mb-6">HOD Dashboard</h1>
        <nav className="space-y-2">
          <NavItem icon={PlusCircle} label="New Request" view="new" />
          <NavItem icon={Send} label="Sent Requests" view="sent" />
          <NavItem icon={Inbox} label="Replies" view="replies" />
          <NavItem icon={Clock} label="Pending" view="pending" />
          <NavItem icon={CalendarIcon} label="Scheduled" view="scheduled" />
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Request List */}
        <div className="w-1/3 border-r p-4 overflow-auto">
          <h2 className="text-xl font-semibold mb-4">
            {activeView === "new" ? "New Training Request" : 
             activeView === "sent" ? "Sent Requests" :
             activeView === "replies" ? "Replies" :
             activeView === "pending" ? "Pending Requests" :
             "Scheduled Trainings"}
          </h2>
          {activeView !== "new" && <RequestList items={requests.filter(r => 
            (activeView === "sent") ||
            (activeView === "replies" && r.status !== "Pending") ||
            (activeView === "pending" && r.status === "Pending") ||
            (activeView === "scheduled" && r.status === "Scheduled")
          )} />}
        </div>

        {/* Request Details / New Request Form */}
        <div className="flex-1 p-4 overflow-auto">
          {activeView === "new" ? (
            <Card>
              <CardHeader>
                <CardTitle>New Training Request</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleRequestSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="subject">Subject</Label>
                    <Input id="subject" name="subject" required />
                  </div>
                  <div>
                    <Label htmlFor="content">Description</Label>
                    <Textarea id="content" name="content" required rows={5} />
                  </div>
                  <Button type="submit">Send Request</Button>
                </form>
              </CardContent>
            </Card>
          ) : selectedItem ? (
            <div>
              <h2 className="text-2xl font-semibold mb-4">{selectedItem.subject}</h2>
              <div className="mb-2">
                <Badge variant={selectedItem.status === "Pending" ? "secondary" : "success"}>
                  {selectedItem.status}
                </Badge>
              </div>
              <div className="mb-4">
                <span className="font-semibold">Date Requested:</span> {selectedItem.date}
              </div>
              <div className="mb-4">{selectedItem.content}</div>
              {selectedItem.status === "Scheduled" && (
                <Card>
                  <CardHeader>
                    <CardTitle>Training Details</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div><span className="font-semibold">Date:</span> {selectedItem.scheduledDate}</div>
                      <div><span className="font-semibold">Time:</span> {selectedItem.scheduledTime}</div>
                      <div><span className="font-semibold">Trainer:</span> {selectedItem.trainer}</div>
                      <div><span className="font-semibold">Room:</span> {selectedItem.room}</div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <div className="text-center text-muted-foreground">
              {activeView === "new" ? "Fill out the form to create a new request" : "Select an item to view details"}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

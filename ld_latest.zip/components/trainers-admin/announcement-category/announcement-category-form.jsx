"use client";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { AnnouncementCategorySchema } from "@/schema";
import { createNewAnnouncementCategory, deleteAnnouncementCategoryDetails, updateAnnouncementCategoryDetails } from "@/app/api/server/route";
import { AlertModal } from "@/components/dashboard/alert-modal";
import { Card, CardDescription, CardHeader, CardTitle,CardContent  } from "@/components/ui/card";
import { Trash2 } from "lucide-react";



export const AnnouncementCategoryForm = ({ initialData }) => {
  const { data: session } = useSession();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  

  const title = initialData && initialData.id ? "Edit Category" : "Create Category";
  const description = initialData && initialData.id ? "Edit the category details" : "Create a new category";
  const action = initialData && initialData.id ? "Save Changes" : "Create";
  const toastMessage = initialData && initialData.id ? "Category updated successfully": "Category created successfully";

  const form = useForm({
    resolver: zodResolver(AnnouncementCategorySchema),
    defaultValues: initialData || {
      name: "",
      description: "",
     
    },
  });

  useEffect(() => {
      form.reset(initialData);
  }, [initialData, form]);


  const onSubmit = async (values) => {
    setLoading(true);
    try {
        if (initialData && initialData.id) {
            await updateAnnouncementCategoryDetails(session.accessToken,initialData.id, values);
            router.refresh();
          } else {
            await createNewAnnouncementCategory(session.accessToken, values);
            router.refresh();
          }
          toast.success(toastMessage);
          router.push("/dashboard/trainers-admin/announcement-management/category");
          router.refresh();
    } catch (error) {
        toast.error(error.message);
    }
    setLoading(false);
  };

  const onDelete = async () => {
    setLoading(true);
    try {
      await deleteAnnouncementCategoryDetails(session.accessToken,initialData.id,);
      toast.success("Category deleted successfully");
      router.push("/dashboard/trainers-admin/training-management/announcement-category");
    } catch (error) {
      toast.error(error.message);
    }
    setLoading(false);
  };

  return (
    <>
    <Card className="w-full max-w-2xl">
        <CardHeader>
            <CardTitle> {title}</CardTitle>
            <CardDescription>{description}</CardDescription>
            <div className="flex items-center justify-between">
              {initialData && initialData.id &&(
                <Button 
                  variant="destructive" 
                  onClick={onDelete} 
                  disabled={loading}
                >
                  <Trash2 className="h-4 w-4" /> Delete
                </Button>
              )}
            </div>
           
        </CardHeader>
        <CardContent className="space-y-6">
            <Separator />
          <Form {...form}>
            <form 
              onSubmit={form.handleSubmit(onSubmit)} className="w-full space-y-8"
            >
              <div className="grid grid-cols-2 gap-8">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category Name</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Category Name"
                          disabled={loading}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
              </div>
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Category Description"
                        disabled={loading}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
             <div className="space-x-4">
                        <Button disabled={loading} className="ml-auto" type="submit">
                            {action}
                        </Button>
                        <Button
                            disabled={loading}
                            className="ml-auto"
                            type="button"
                            onClick={() => {
                                router.back();
                            }}
                        >
                            Cancel
                        </Button>
                    </div>
            </form>
          </Form>
        </CardContent>
    </Card>
    {initialData && initialData.id && (
                <AlertModal
                    title="Are you Sure"
                    description="This action cannot be undone."
                    name={initialData?.name}
                    isOpen={open}
                    onClose={() => setOpen(false)}
                    onConfirm={onDelete}
                    loading={loading}
                />
            )}
      
      
      
    </>
  );
};


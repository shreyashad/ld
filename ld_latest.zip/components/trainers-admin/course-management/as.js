'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import ModuleForm from './ModuleForm'
import RichTextEditor from './RichTextEditor'
import ErrorMessage from './ErrorMessage'
import Image from 'next/image'
import { courseSchema } from '../lib/validationSchemas'

export default function CourseForm({ initialCourse }) {
  const [course, setCourse] = useState(initialCourse || {
    title: '',
    slug: '',
    description: '',
    cover_image: '',
    category: '',
    difficulty_level: 'Beginner',
    prerequisites: '',
    certification_status: false,
    duration: 0,
    modules: []
  })
  const [errors, setErrors] = useState({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setCourse(prev => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name) => (value) => {
    setCourse(prev => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (name) => (checked) => {
    setCourse(prev => ({ ...prev, [name]: checked }))
  }

  const handlePrerequisitesChange = (content) => {
    setCourse(prev => ({ ...prev, prerequisites: content }))
  }

  const handleCoverImageChange = (e) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setCourse(prev => ({ ...prev, cover_image: reader.result }))
      }
      reader.readAsDataURL(file)
    }
  }

  const addModule = () => {
    setCourse(prev => ({
      ...prev,
      modules: [...prev.modules, {
        title: '',
        description: '',
        cover_image: '',
        order: prev.modules.length + 1,
        status: 'Draft',
        video_lessons: []
      }]
    }))
  }

  const updateModule = (index, updatedModule) => {
    setCourse(prev => ({
      ...prev,
      modules: prev.modules.map((module, i) => i === index ? updatedModule : module)
    }))
  }

  const removeModule = (index) => {
    setCourse(prev => ({
      ...prev,
      modules: prev.modules.filter((_, i) => i !== index)
    }))
  }

  useEffect(() => {
    const totalDuration = course.modules.reduce((total, module) => {
      return total + module.video_lessons.reduce((moduleTotal, lesson) => moduleTotal + lesson.duration, 0)
    }, 0)
    setCourse(prev => ({ ...prev, duration: totalDuration }))
  }, [course.modules])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)
    setErrors({})

    try {
      const validatedCourse = courseSchema.parse(course)
      console.log('Submitting course:', validatedCourse)
      // Here you would send the validatedCourse to your API
      alert('Course saved successfully!')
    } catch (error) {
      if (error.errors) {
        const formattedErrors = {}
        error.errors.forEach(err => {
          formattedErrors[err.path.join('.')] = err.message
        })
        setErrors(formattedErrors)
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8 max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-8">
      <div className="space-y-6">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-700">Title</label>
          <Input
            id="title"
            name="title"
            value={course.title}
            onChange={handleInputChange}
            placeholder="Course Title"
            className="mt-1"
          />
          {errors.title && <p className="mt-1 text-sm text-red-600">{errors.title}</p>}
        </div>
        <div>
          <label htmlFor="slug" className="block text-sm font-medium text-gray-700">Slug</label>
          <Input
            id="slug"
            name="slug"
            value={course.slug}
            onChange={handleInputChange}
            placeholder="Course Slug"
            className="mt-1"
          />
          {errors.slug && <p className="mt-1 text-sm text-red-600">{errors.slug}</p>}
        </div>
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
          <Textarea
            id="description"
            name="description"
            value={course.description}
            onChange={handleInputChange}
            placeholder="Course Description"
            className="mt-1"
          />
          {errors.description && <p className="mt-1 text-sm text-red-600">{errors.description}</p>}
        </div>
        <div>
          <label htmlFor="cover_image" className="block text-sm font-medium text-gray-700">Cover Image</label>
          <Input
            id="cover_image"
            name="cover_image"
            type="file"
            onChange={handleCoverImageChange}
            className="mt-1"
          />
          {course.cover_image && (
            <div className="mt-2">
              <Image
                src={course.cover_image}
                alt="Cover Image Preview"
                width={200}
                height={200}
                className="rounded-md"
              />
            </div>
          )}
        </div>
        <div>
          <label htmlFor="category" className="block text-sm font-medium text-gray-700">Category</label>
          <Input
            id="category"
            name="category"
            value={course.category}
            onChange={handleInputChange}
            placeholder="Category"
            className="mt-1"
          />
          {errors.category && <p className="mt-1 text-sm text-red-600">{errors.category}</p>}
        </div>
        <div>
          <label htmlFor="difficulty_level" className="block text-sm font-medium text-gray-700">Difficulty Level</label>
          <Select onValueChange={handleSelectChange('difficulty_level')} value={course.difficulty_level}>
            <SelectTrigger className="mt-1">
              <SelectValue placeholder="Select difficulty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Beginner">Beginner</SelectItem>
              <SelectItem value="Intermediate">Intermediate</SelectItem>
              <SelectItem value="Advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>
          {errors.difficulty_level && <p className="mt-1 text-sm text-red-600">{errors.difficulty_level}</p>}
        </div>
        <div>
          <label htmlFor="prerequisites" className="block text-sm font-medium text-gray-700">Prerequisites</label>
          <RichTextEditor
            content={course.prerequisites}
            onChange={handlePrerequisitesChange}
          />
          {errors.prerequisites && <p className="mt-1 text-sm text-red-600">{errors.prerequisites}</p>}
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="certification_status"
            checked={course.certification_status}
            onCheckedChange={handleSwitchChange('certification_status')}
          />
          <label htmlFor="certification_status" className="text-sm font-medium text-gray-700">Certification Available</label>
        </div>
        <div className="text-sm font-medium text-gray-700">Total Duration: {course.duration} minutes</div>
      </div>

      <div className="space-y-6">
        <h2 className="text-xl font-bold text-gray-900">Modules</h2>
        {course.modules.map((module, index) => (
          <ModuleForm
            key={index}
            module={module}
            onUpdate={(updatedModule) => updateModule(index, updatedModule)}
            onRemove={() => removeModule(index)}
          />
        ))}
        <Button type="button" onClick={addModule} className="w-full">Add Module</Button>
      </div>

      <Button type="submit" className="w-full" disabled={isSubmitting}>
        {isSubmitting ? 'Saving...' : 'Save Course'}
      </Button>
    </form>
  )
}

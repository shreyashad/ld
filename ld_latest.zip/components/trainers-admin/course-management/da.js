import React from 'react';
import { Controller } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, Input, FormMessage } from './FormComponents'; // Import your custom components
import { Button, Card, CardContent, CardFooter, CardHeader } from './CardComponents'; // Import your card components

const VideoForm = ({ index, moduleIndex, video, form, removeVideo, loading }) => {
  return (
    <Card key={video.id} className="mb-4">
      <CardHeader>Video {index + 1}</CardHeader>
      <CardContent>
        <Controller
          control={form.control}
          name={`modules[${moduleIndex}].videos[${index}].title`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Video Title</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Video Title" disabled={loading} />
              </FormControl>
            </FormItem>
          )}
        />
      </CardContent>
      <CardFooter>
        <Button type="button" onClick={() => removeVideo(index)}>Remove Video</Button>
      </CardFooter>
    </Card>
  );
};

export default VideoForm;
import React from 'react';
import { Controller } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, Input, Textarea, FormMessage } from './FormComponents'; // Import your custom components
import { Button, Card, CardContent, CardFooter, CardHeader, CardTitle } from './CardComponents'; // Import your card components

const ModuleForm = ({ index, module, form, removeModule, addVideo, removeVideo, loading, initialData }) => {
  return (
    <Card key={module.id} className="mb-6">
      <CardHeader>
        <CardTitle>Module {index + 1}</CardTitle>
      </CardHeader>
      <CardContent>
        {/* Module Title */}
        <Controller
          control={form.control}
          name={`modules[${index}].title`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Module Title</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Module Title" disabled={loading} />
              </FormControl>
            </FormItem>
          )}
        />

        {/* Module Order */}
        <div className="grid grid-cols-2 gap-8">
          <Controller
            control={form.control}
            name={`modules[${index}].order`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>Module Order</FormLabel>
                <FormControl>
                  <Input {...field} type="number" disabled={loading} />
                </FormControl>
              </FormItem>
            )}
          />

          {/* Module Status */}
          <Controller
            control={form.control}
            name={`modules[${index}].status`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>Module Status</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="Module Status" disabled={loading} />
                </FormControl>
              </FormItem>
            )}
          />
        </div>

        {/* Module Cover Image */}
        <Controller
          control={form.control}
          name={`modules[${index}].cover_image`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Module Cover Image</FormLabel>
              <FormControl>
                <div className="flex items-center space-x-4">
                  <Input
                    type="file"
                    accept="image/*"
                    disabled={loading}
                    onChange={(e) => field.onChange(e.target.files?.[0])}
                  />
                  {field.value ? (
                    <img
                      src={URL.createObjectURL(field.value)}
                      alt="Module cover image"
                      width={50}
                      height={50}
                      className="object-cover rounded"
                    />
                  ) : initialData?.image ? (
                    <img
                      src={initialData.image}
                      alt="Module cover image"
                      width={50}
                      height={50}
                      className="object-cover rounded"
                    />
                  ) : null}
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Module Description */}
        <Controller
          control={form.control}
          name={`modules[${index}].description`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Module Description</FormLabel>
              <FormControl>
                <Textarea {...field} placeholder="Module Description" disabled={loading} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Video Section */}
        <h4 className="text-lg mt-4">Videos</h4>
        <div>
          {module.videos && module.videos.map((video, videoIndex) => (
            <VideoForm
              key={video.id}
              index={videoIndex}
              moduleIndex={index}
              video={video}
              form={form}
              removeVideo={removeVideo}
              loading={loading}
            />
          ))}
          <Button type="button" onClick={() => addVideo({})}>Add Video</Button>
        </div>

        <Button type="button" onClick={() => removeModule(index)} variant="destructive">Remove Module</Button>
      </CardContent>
    </Card>
  );
};

export default ModuleForm;

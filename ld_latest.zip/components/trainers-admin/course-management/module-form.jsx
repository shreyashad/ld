import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { FormControl, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import Image from "next/image";
import { Controller } from "react-hook-form";
import VideoForm from "./video-form";


const ModuleForm = ({ index, module, form, removeModule, addVideo, removeVideo, loading, initialData }) => {
    return(
        <Card key={module.id} className="mb-6">
            <CardHeader>
                <CardTitle>Module {index + 1 } </CardTitle>
            </CardHeader>
            <CardContent>
                <Controller 
                     control={form.control} 
                     name={`modules[${index}].title`}
                     render={({ field }) => (
                       <FormItem>
                         <FormLabel>Module Title</FormLabel>
                         <FormControl>
                           <Input 
                             {...field}
                             placeholder="Module Title"
                             disabled={loading}
                           />
                         </FormControl>
                       </FormItem>
                     )}
                />
                <div className="grid grid-cols-2 gap-8">
                    <Controller
                        control={form.control} 
                        name={`modules[${index}].order`}
                        render={({ field }) => (
                        <FormItem>
                            <FormLabel>Module Order</FormLabel>
                            <FormControl>
                            <Input 
                                {...field}
                                type="number"
                                disabled={loading}
                            />
                            </FormControl>
                        </FormItem>
                        )}
                    />
                    <Controller
                        control={form.control} 
                        name={`modules[${index}].status`}
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>Module Status</FormLabel>
                            <FormControl>
                                <Input 
                                {...field}
                                placeholder="Module Title"
                                disabled={loading}
                                />
                            </FormControl>
                            </FormItem>
                        )}
                    />
                     
                </div>
                <Controller 
                        control={form.control}
                        name={`modules[${index}].cover_image`}
                        render={({ field }) => (
                            
                            <FormItem>
                                <FormLabel>Module Cover Image</FormLabel>
                                <FormControl>
                                    <div className="flex items-center space-x-4">
                                    <Input 
                                        type="file"
                                        accept="image/*"
                                        disabled={loading}
                                        onChange={(e) => field.onChange(e.target.files?.[0])}
                                    />
                                    {field.value ? (
                                        <Image
                                        src={URL.createObjectURL(field.value)}
                                        alt="Module cover image"
                                        width={50}
                                        height={50}
                                        className="object-cover rounded"
                                        />
                                    ) : initialData?.image ? (
                                        <Image
                                        src={initialData.image}
                                        alt="Module cover image"
                                        width={50}
                                        height={50}
                                        className="object-cover rounded"
                                        />
                                    ) : null}
                                    </div>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                     />
                     <Controller 
                        control={form.control}
                        name={`modules[${index}].description`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Module Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                {...field} 
                                placeholder="Module Description" 
                                disabled={loading} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                     />
                     <Separator />
                     <h4 className="text-lg mt-4">Videos</h4>
                    <div>
                        {module.videos && module.videos.map((video, videoIndex) => (
                            <VideoForm
                                key={video.id}
                                index={videoIndex}
                                moduleIndex={index}
                                video={video}
                                form={form}
                                removeVideo={removeVideo}
                                loading={loading}
                            />
                        ))}
                        <Button type="button" onClick={() => addVideo({})}>Add Video</Button>
                    </div>
            </CardContent>
            <CardFooter>
            <Button type="button" onClick={() => removeModule(index)} variant="destructive">Remove Module</Button>
            </CardFooter>
        </Card>
    );
};

export default ModuleForm;
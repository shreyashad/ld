"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../../ui/card";
import { Separator } from "../../ui/separator";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../../ui/form";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CourseSchema } from "@/schema";
import { Input } from "../../ui/input";
import Image from "next/image";
import { Textarea } from "../../ui/textarea";
import { Button } from "../../ui/button";
import toast from "react-hot-toast";
import { useEffect, useState } from "react";
import { Plus, Trash, Trash2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../../ui/accordion";
import { createNewCourse, updateCourseDetails } from "@/app/api/server/route";
import dynamic from "next/dynamic";
import "react-quill/dist/quill.snow.css"; // Import Quill's styles


const ReactQuill = dynamic(() => import("react-quill"), { ssr: false });


export const CourseForm = ({ initialData = {}, categories, difflevel }) => {
    const router = useRouter();
    const { data: session } = useSession();

    const pagetitle = initialData && initialData.id ? "Edit Course" : "Create Course";
    const description = initialData && initialData.id ? "Edit the course details" : "Create a new course";
    const action = initialData && initialData.id ? "Save Changes" : "Create";
    const toastMessage = initialData && initialData.id ? "Course updated successfully" : "Course created successfully";

    const [loading, setLoading] = useState(false);
    
    const form = useForm({
        resolver: zodResolver(CourseSchema),
        defaultValues: initialData || {
            title: "",
            description: "",
            category:"",
            cover_image: "",
            duration:"",
            difficulty_level:"",
            prerequisites:"",
            certification:"",
            learning_objectives:"",
            status:"",
            modules: [
                { 
                    title: "",
                    description:"", 
                    cover_image:"", 
                    order:"",
                    status:"" , 
                    videos: [
                        { 
                            title: "",
                            video_url:"",
                            cover_image:"",
                            description:"", 
                            duration: "",
                            order:"", 
                            status:"" 
                        }
                    ] 
                }
            ],
        },
    });

    useEffect(() => {
        form.reset(initialData);
    }, [initialData, form]);

    const { fields: moduleFields, append: appendModule, remove: removeModule } = useFieldArray({
        control: form.control,
        name: "modules",
    });

    const onSubmit = async (values) => {
        try {
            // Handle create or update logic
            if (initialData && initialData.id) {
                // Update logic
                await updateCourseDetails(session.accessToken, initialData.id, values);
            } else {
                // Create logic
                await createNewCourse(session.accessToken, values);
            }
            toast.success(toastMessage);
            router.refresh();
        } catch (error) {
            toast.error(error.message);
        }
    };

    return (
        <Card className="border shadow-2xl ">
            <CardHeader>
                <CardTitle>Course Management Form</CardTitle>
                
            </CardHeader>
            <Separator />
            <CardContent className="pb-4">
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 max-w-4xl mx-auto p-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>{pagetitle}</CardTitle>
                                <CardDescription>{description}</CardDescription>
                            </CardHeader>
                            <CardContent>
                            <div className="mt-5 grid grid-cols-2 gap-8">
                                <FormField
                                    control={form.control}
                                    name="cover_image"
                                    render={({ field }) => (
                                        <FormItem>
                                        <FormLabel>Cover Image</FormLabel>
                                        <FormControl>
                                            <div className="flex items-center grid grid-cols-2 space-x-4">
                                            <Input
                                                type="file"
                                                accept="image/*"
                                                onChange={(e) => field.onChange(e.target.files?.[0])}
                                            />
                                            {field.value  && field.value instanceof File &&(
                                                <img
                                                src={URL.createObjectURL(field.value)}
                                                alt="Category icon preview"
                                                className="w-50 h-50 object-cover rounded"
                                                />
                                            )}
                                            </div>
                                        </FormControl>
                                        
                                        <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="status"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Status</FormLabel>
                                            <Select
                                                disabled={loading}
                                                onValueChange={field.onChange}
                                                value={field.value}
                                            >
                                                <FormControl>
                                                    <SelectTrigger>
                                                        <SelectValue
                                                            placeholder="Status"
                                                        />
                                                    </SelectTrigger>
                                                </FormControl>
                                                <SelectContent>
                                                    <SelectItem value="Inactive">Inactive</SelectItem>
                                                    <SelectItem value="Published">Published</SelectItem>
                                                    
                                                </SelectContent>
                                            </Select>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                            </div>
                            <div className="mt-5 grid grid-cols-2 gap-8">
                            <FormField
                                control={form.control}
                                name="title"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Course Title</FormLabel>
                                        <FormControl>
                                            <Input
                                                placeholder="Enter course title"
                                                {...field}
                                                disabled={loading}
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="category"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Category</FormLabel>
                                        <FormControl>
                                            <Select 
                                                disabled={loading || !categories.length}
                                                onValueChange={field.onChange}
                                                value={field.value}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue 
                                                        placeholder={
                                                            categories.length > 0
                                                                ? "Course Category "
                                                                : "No Category available"
                                                    }
                                                />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    { categories.length > 0 ? (
                                                        categories.map((cate) => (
                                                            <SelectItem key={cate.id} value={cate.id}>
                                                                {cate.name}
                                                            </SelectItem>
                                                        ))
                                                    ) : (
                                                        <SelectItem disabled>
                                                            No Category found
                                                        </SelectItem>
                                                    )}
                                                </SelectContent>
                                            </Select>
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            
                            <FormField
                                control={form.control}
                                name="duration"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Duration</FormLabel>
                                        <FormControl>
                                            <Input
                                                placeholder="Enter image URL"
                                                {...field}
                                                disabled={loading}
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="difficulty_level"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Difficulty Level</FormLabel>
                                        <FormControl>
                                            <Select 
                                                disabled={loading || !difflevel.length}
                                                onValueChange={field.onChange}
                                                value={field.value}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue 
                                                        placeholder={
                                                            difflevel.length > 0
                                                                ? "Difficulty Level "
                                                                : "No Difficulty Level available"
                                                    }
                                                />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    { difflevel.length > 0 ? (
                                                        difflevel.map((level) => (
                                                            <SelectItem key={level.id} value={level.name}>
                                                                {level.name}
                                                            </SelectItem>
                                                        ))
                                                    ) : (
                                                        <SelectItem disabled>
                                                            No Difficulty Level found
                                                        </SelectItem>
                                                    )}
                                                </SelectContent>
                                            </Select>
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="description"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Description</FormLabel>
                                        <FormControl>
                                            <Textarea
                                                {...field}
                                                placeholder="Course Description"
                                                className="row-4"
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="prerequisites"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>prerequisites</FormLabel>
                                        <FormControl>
                                            <ReactQuill
                                                {...field}
                                                value={field.value}
                                                onChange={field.onChange}
                                                placeholder="Enter today's wisdom..."
                                                modules={{
                                                    toolbar: [
                                                        ["bold", "italic", "underline", "strike"],
                                                        [{ list: "ordered" }, { list: "bullet" }],
                                                        ["link"],
                                                    ],
                                                }}
                                                disabled={loading}
                                            />
                                            <Textarea
                                                {...field}
                                                placeholder="Course Description"
                                                className="row-4"
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            </div>
                            </CardContent>
                        </Card>
                        <Accordion type="single" collapsible className="w-full">
                            {moduleFields.map((module, moduleIndex) => (
                                <AccordionItem value={`module-${moduleIndex}`} key={module.id}>
                                    <AccordionTrigger> Module {moduleIndex + 1}</AccordionTrigger>
                                    <AccordionContent>
                                        <Card>
                                            <CardContent className="space-y-4 pt-4">
                                                <div className="mt-5 grid grid-cols-2 gap-8">
                                                    <FormField
                                                        control={form.control}
                                                        name="cover_image"
                                                        render={({ field }) => (
                                                            <FormItem>
                                                            <FormLabel>Cover Image</FormLabel>
                                                            <FormControl>
                                                                <div className="flex items-center grid grid-cols-2 space-x-4">
                                                                <Input
                                                                    type="file"
                                                                    accept="image/*"
                                                                    onChange={(e) => field.onChange(e.target.files?.[0])}
                                                                />
                                                                {field.value && (
                                                                    <img
                                                                    src={URL.createObjectURL(field.value)}
                                                                    alt="Category icon preview"
                                                                    className="w-50 h-50 object-cover rounded"
                                                                    />
                                                                )}
                                                                </div>
                                                            </FormControl>
                                                            
                                                            <FormMessage />
                                                            </FormItem>
                                                        )}
                                                    />
                                                    <FormField
                                                        control={form.control}
                                                        name="status"
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Status</FormLabel>
                                                                <Select
                                                                    disabled={loading}
                                                                    onValueChange={field.onChange}
                                                                    value={field.value}
                                                                >
                                                                    <FormControl>
                                                                        <SelectTrigger>
                                                                            <SelectValue
                                                                                placeholder="Status"
                                                                            />
                                                                        </SelectTrigger>
                                                                    </FormControl>
                                                                    <SelectContent>
                                                                        <SelectItem value="Inactive">Inactive</SelectItem>
                                                                        <SelectItem value="Published">Published</SelectItem>
                                                                        
                                                                    </SelectContent>
                                                                </Select>
                                                                <FormMessage />
                                                            </FormItem>
                                                        )}
                                                    />

                                                </div>
                                                <div className="mt-5 grid grid-cols-2 gap-8">
                                                    <FormField
                                                        control={form.control}
                                                        name="title"
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Course Module Title</FormLabel>
                                                                <FormControl>
                                                                    <Input
                                                                        placeholder="Enter course title"
                                                                        {...field}
                                                                        disabled={loading}
                                                                    />
                                                                </FormControl>
                                                                <FormMessage />
                                                            </FormItem>
                                                        )}
                                                    />
                                                    <FormField
                                                        control={form.control}
                                                        name="order"
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Module Order</FormLabel>
                                                                <FormControl>
                                                                    <Input
                                                                        type="number"
                                                                        placeholder="Module Order"
                                                                        {...field}
                                                                        disabled={loading}
                                                                    />
                                                                </FormControl>
                                                                <FormMessage />
                                                            </FormItem>
                                                        )}
                                                    />
                                                    </div>
                                                    <FormField
                                                        control={form.control}
                                                        name="description"
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Description</FormLabel>
                                                                <FormControl>
                                                                    <Textarea
                                                                        {...field}
                                                                        placeholder="Course Description"
                                                                        className="row-4"
                                                                    />
                                                                </FormControl>
                                                                <FormMessage />
                                                            </FormItem>
                                                        )}
                                                    />
                                                
                                                {form.watch(`modules.${moduleIndex}.videos`).map((video, videoIndex) => (
                                                    <Card key={videoIndex}>
                                                        <CardContent className="space-y-4 pt-4">
                                                            <div className="mt-5 grid grid-cols-2 gap-8">
                                                                <FormField
                                                                    control={form.control}
                                                                    name={`modules.${moduleIndex}.videos.${videoIndex}.cover_image`}  
                                                                    render={({ field }) => (
                                                                        <FormItem>
                                                                        <FormLabel>Cover Image</FormLabel>
                                                                        <FormControl>
                                                                            <div className="flex items-center grid grid-cols-2 space-x-4">
                                                                            <Input
                                                                                type="file"
                                                                                accept="image/*"
                                                                                onChange={(e) => field.onChange(e.target.files?.[0])}
                                                                            />
                                                                            {field.value && (
                                                                                <img
                                                                                src={URL.createObjectURL(field.value)}
                                                                                alt="Category icon preview"
                                                                                className="w-50 h-50 object-cover rounded"
                                                                                />
                                                                            )}
                                                                            </div>
                                                                        </FormControl>
                                                                        
                                                                        <FormMessage />
                                                                        </FormItem>
                                                                    )}
                                                                />
                                                                <FormField
                                                                    control={form.control}
                                                                    name={`modules.${moduleIndex}.videos.${videoIndex}.status`}  
                                                                    render={({ field }) => (
                                                                        <FormItem>
                                                                            <FormLabel>Status</FormLabel>
                                                                            <Select
                                                                                disabled={loading}
                                                                                onValueChange={field.onChange}
                                                                                value={field.value}
                                                                            >
                                                                                <FormControl>
                                                                                    <SelectTrigger>
                                                                                        <SelectValue
                                                                                            placeholder="Status"
                                                                                        />
                                                                                    </SelectTrigger>
                                                                                </FormControl>
                                                                                <SelectContent>
                                                                                    <SelectItem value="Inactive">Inactive</SelectItem>
                                                                                    <SelectItem value="Published">Published</SelectItem>
                                                                                </SelectContent>
                                                                            </Select>
                                                                            <FormMessage />
                                                                        </FormItem>
                                                                    )}
                                                                />
                                                            </div>
                                                            <div className="mt-5 grid grid-cols-2 gap-8">
                                                                <FormField
                                                                    control={form.control}
                                                                    name={`modules.${moduleIndex}.videos.${videoIndex}.title`}
                                                                    render={({ field }) => (
                                                                        <FormItem>
                                                                            <FormLabel>Video Title</FormLabel>
                                                                            <FormControl>
                                                                                <Input
                                                                                    {...field}
                                                                                    placeholder="Enter video title"
                                                                                    disabled={loading}
                                                                                />
                                                                            </FormControl>
                                                                            <FormMessage />
                                                                        </FormItem>
                                                                    )}
                                                                />
                                                                <FormField
                                                                    control={form.control}
                                                                    name={`modules.${moduleIndex}.videos.${videoIndex}.order`}
                                                                    render={({ field }) => (
                                                                        <FormItem>
                                                                            <FormLabel>Video Order</FormLabel>
                                                                            <FormControl>
                                                                                <Input
                                                                                    type="number"
                                                                                    {...field}
                                                                                    placeholder="Enter video Order"
                                                                                    disabled={loading}
                                                                                />
                                                                            </FormControl>
                                                                            <FormMessage />
                                                                        </FormItem>
                                                                    )}
                                                                />
                                                                <FormField
                                                                    control={form.control}
                                                                    name={`modules.${moduleIndex}.videos.${videoIndex}.video_url`}  
                                                                    render={({ field }) => (
                                                                        <FormItem>
                                                                        <FormLabel>Video</FormLabel>
                                                                        <FormControl>
                                                                            <div className="flex items-center grid grid-cols-2 space-x-4">
                                                                            <Input
                                                                                type="file"
                                                                                accept="image/*"
                                                                                onChange={(e) => field.onChange(e.target.files?.[0])}
                                                                            />
                                                                            {field.value && (
                                                                                <img
                                                                                src={URL.createObjectURL(field.value)}
                                                                                alt="Category icon preview"
                                                                                className="w-50 h-50 object-cover rounded"
                                                                                />
                                                                            )}
                                                                            </div>
                                                                        </FormControl>
                                                                        
                                                                        <FormMessage />
                                                                        </FormItem>
                                                                    )}
                                                                />
                                                                <FormField
                                                                    control={form.control}
                                                                    name={`modules.${moduleIndex}.videos.${videoIndex}.order`}
                                                                    render={({ field }) => (
                                                                        <FormItem>
                                                                            <FormLabel>Video Duration</FormLabel>
                                                                            <FormControl>
                                                                                <Input
                                                                                    type="number"
                                                                                    {...field}
                                                                                    placeholder="Enter video Order"
                                                                                    disabled={loading}
                                                                                />
                                                                            </FormControl>
                                                                            <FormMessage />
                                                                        </FormItem>
                                                                    )}
                                                                />
                                                            </div>
                                                            <FormField
                                                                control={form.control}
                                                                name={`modules.${moduleIndex}.videos.${videoIndex}.description`}
                                                                render={({ field }) => (
                                                                    <FormItem>
                                                                        <FormLabel>Description</FormLabel>
                                                                        <FormControl>
                                                                            <Textarea
                                                                                {...field}
                                                                                placeholder="Video Description"
                                                                                className="row-4"
                                                                            />
                                                                        </FormControl>
                                                                        <FormMessage />
                                                                    </FormItem>
                                                                )}
                                                            />   
                                                        </CardContent>
                                                        <CardFooter>
                                                            <Button 
                                                                type="button"
                                                                variant="destructive"
                                                                size="sm"
                                                                onClick={() => remove(videoIndex)}>
                                                            <Trash2 className="mr-2 h-4 w-4" />
                                                                Remove Video
                                                            </Button>
                                                        </CardFooter>
                                                    </Card>
                                                ))}
                                                <div className="mt-5 grid grid-cols-2 gap-8">
                                                    <Button 
                                                        type="button" 
                                                        variant="outline" 
                                                        size="sm"
                                                        onClick={() => appendVideo({ title: "", duration: "" })}
                                                    >
                                                        <Plus className="mr-2 h-4 w-4" />
                                                        Add Video
                                                    </Button>
                                                    <Button 
                                                        type="button"
                                                        variant="destructive"
                                                        size="sm" 
                                                        onClick={() => removeModule(moduleIndex)}>
                                                        <Trash2 className="mr-2 h-4 w-4" />
                                                        Remove Module
                                                    </Button>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </AccordionContent>
                                </AccordionItem>
                            ))}
                             <Button type="button" onClick={() => appendModule({ title: "", videos: [] })}>
                                <Plus className="mr-2 h-4 w-4" />
                                Add Module
                            </Button>
                        </Accordion>
                        <Button disabled={loading} type="submit" className="ml-auto">
                            {action}
                        </Button>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};
                       

                        

                        
                        
                        

                        {/* <div>
                            <h3>Modules</h3>
                            {moduleFields.map((module, index) => (
                                <div key={module.id} className="border p-4 rounded mb-4">
                                    <FormField
                                        control={form.control}
                                        name={`modules.${index}.title`}
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Module Title</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...field}
                                                        placeholder="Enter module title"
                                                        disabled={loading}
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <h4>Videos</h4>
                                    {form.watch(`modules.${index}.videos`).map((video, videoIndex) => (
                                        <div key={videoIndex} className="border p-2 rounded mb-2">
                                            <FormField
                                                control={form.control}
                                                name={`modules.${index}.videos.${videoIndex}.title`}
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Video Title</FormLabel>
                                                        <FormControl>
                                                            <Input
                                                                {...field}
                                                                placeholder="Enter video title"
                                                                disabled={loading}
                                                            />
                                                        </FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                            <FormField
                                                control={form.control}
                                                name={`modules.${index}.videos.${videoIndex}.duration`}
                                                render={({ field }) => (
                                                    <FormItem>
                                                        <FormLabel>Duration</FormLabel>
                                                        <FormControl>
                                                            <Input
                                                                {...field}
                                                                placeholder="Enter duration"
                                                                disabled={loading}
                                                            />
                                                        </FormControl>
                                                        <FormMessage />
                                                    </FormItem>
                                                )}
                                            />
                                            <Button type="button" onClick={() => remove(videoIndex)}>
                                                Remove Video
                                            </Button>
                                        </div>
                                    ))}
                                    <Button type="button" onClick={() => appendVideo({ title: "", duration: "" })}>
                                        Add Video
                                    </Button>
                                    <Button type="button" onClick={() => removeModule(index)}>
                                        Remove Module
                                    </Button>
                                </div>
                            ))}
                            <Button type="button" onClick={() => appendModule({ title: "", videos: [] })}>
                                Add Module
                            </Button>
                        </div>

                        <Button disabled={loading} type="submit" className="ml-auto">
                            {action}
                        </Button>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
}; */}
'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import ModuleForm from './ModuleForm'
import RichTextEditor from './RichTextEditor'
import ErrorMessage from './ErrorMessage'
import Image from 'next/image'

export default function CourseForm({ initialCourse }) {
  const [course, setCourse] = useState(initialCourse || {
    title: '',
    slug: '',
    description: '',
    cover_image: '',
    category: '',
    difficulty_level: 'Beginner',
    prerequisites: '',
    certification_status: false,
    duration: 0,
    modules: []
  })
  const [error, setError] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setCourse(prev => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name) => (value) => {
    setCourse(prev => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (name) => (checked) => {
    setCourse(prev => ({ ...prev, [name]: checked }))
  }

  const handlePrerequisitesChange = (content) => {
    setCourse(prev => ({ ...prev, prerequisites: content }))
  }

  const handleCoverImageChange = (e) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setCourse(prev => ({ ...prev, cover_image: reader.result }))
      }
      reader.readAsDataURL(file)
    }
  }

  const addModule = () => {
    setCourse(prev => ({
      ...prev,
      modules: [...prev.modules, {
        title: '',
        description: '',
        cover_image: '',
        order: prev.modules.length + 1,
        status: 'Draft',
        video_lessons: []
      }]
    }))
  }

  const updateModule = (index, updatedModule) => {
    setCourse(prev => ({
      ...prev,
      modules: prev.modules.map((module, i) => i === index ? updatedModule : module)
    }))
  }

  const removeModule = (index) => {
    setCourse(prev => ({
      ...prev,
      modules: prev.modules.filter((_, i) => i !== index)
    }))
  }

  useEffect(() => {
    const totalDuration = course.modules.reduce((total, module) => {
      return total + module.video_lessons.reduce((moduleTotal, lesson) => moduleTotal + lesson.duration, 0)
    }, 0)
    setCourse(prev => ({ ...prev, duration: totalDuration }))
  }, [course.modules])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError(null)

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // Simulate a 10% chance of an error
      if (Math.random() < 0.1) {
        throw new Error('Failed to save course')
      }

      console.log('Submitting course:', course)
      alert('Course saved successfully!')
      // In a real app, you'd redirect to the course list or the newly created/edited course
    } catch (error) {
      setError(error.message)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8 max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-8">
      {error && <ErrorMessage message={error} />}
      <div className="space-y-6">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-700">Title</label>
          <Input
            id="title"
            name="title"
            value={course.title}
            onChange={handleInputChange}
            placeholder="Course Title"
            className="mt-1"
          />
        </div>
        <div>
          <label htmlFor="slug" className="block text-sm font-medium text-gray-700">Slug</label>
          <Input
            id="slug"
            name="slug"
            value={course.slug}
            onChange={handleInputChange}
            placeholder="Course Slug"
            className="mt-1"
          />
        </div>
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description</label>
          <Textarea
            id="description"
            name="description"
            value={course.description}
            onChange={handleInputChange}
            placeholder="Course Description"
            className="mt-1"
          />
        </div>
        <div>
          <label htmlFor="cover_image" className="block text-sm font-medium text-gray-700">Cover Image</label>
          <Input
            id="cover_image"
            name="cover_image"
            type="file"
            onChange={handleCoverImageChange}
            className="mt-1"
          />
          {course.cover_image && (
            <div className="mt-2">
              <Image
                src={course.cover_image}
                alt="Cover Image Preview"
                width={200}
                height={200}
                className="rounded-md"
              />
            </div>
          )}
        </div>
        <div>
          <label htmlFor="category" className="block text-sm font-medium text-gray-700">Category</label>
          <Input
            id="category"
            name="category"
            value={course.category}
            onChange={handleInputChange}
            placeholder="Category"
            className="mt-1"
          />
        </div>
        <div>
          <label htmlFor="difficulty_level" className="block text-sm font-medium text-gray-700">Difficulty Level</label>
          <Select onValueChange={handleSelectChange('difficulty_level')} value={course.difficulty_level}>
            <SelectTrigger className="mt-1">
              <SelectValue placeholder="Select difficulty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Beginner">Beginner</SelectItem>
              <SelectItem value="Intermediate">Intermediate</SelectItem>
              <SelectItem value="Advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <label htmlFor="prerequisites" className="block text-sm font-medium text-gray-700">Prerequisites</label>
          <RichTextEditor
            content={course.prerequisites}
            onChange={handlePrerequisitesChange}
          />
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="certification_status"
            checked={course.certification_status}
            onCheckedChange={handleSwitchChange('certification_status')}
          />
          <label htmlFor="certification_status" className="text-sm font-medium text-gray-700">Certification Available</label>
        </div>
        <div className="text-sm font-medium text-gray-700">Total Duration: {course.duration} minutes</div>
      </div>

      <div className="space-y-6">
        <h2 className="text-xl font-bold text-gray-900">Modules</h2>
        {course.modules.map((module, index) => (
          <ModuleForm
            key={index}
            module={module}
            onUpdate={(updatedModule) => updateModule(index, updatedModule)}
            onRemove={() => removeModule(index)}
          />
        ))}
        <Button type="button" onClick={addModule} className="w-full">Add Module</Button>
      </div>

      <Button type="submit" className="w-full" disabled={isSubmitting}>
        {isSubmitting ? 'Saving...' : 'Save Course'}
      </Button>
    </form>
  )
}

----
import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import RichTextEditor from "@/components/dashboard/rich-text-editor";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import Image from "next/image";

export const CourseForm = ({ initialData, categories, difflevel }) => {
  const { data: session } = useSession();

  const [course, setCourse] = useState(initialData || {
    title: '',
    slug: '',
    description: '',
    cover_image: '',
    category: '',
    difficulty_level: 'Beginner',
    prerequisites: '',
    certification_status: false,
    duration: 0,
    modules: [] // Ensure modules is always initialized as an empty array
  });
  
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCourse((prev) => ({ ...prev, [name]: value }));
  };

  const handleSwitchChange = (name) => (checked) => {
    setCourse((prev) => ({ ...prev, [name]: checked }));
  };

  const handleSelectChange = (name) => (value) => {
    setCourse((prev) => ({ ...prev, [name]: value }));
  };

  const handlePrerequisitesChange = (content) => {
    setCourse((prev) => ({ ...prev, prerequisites: content }));
  };

  const handleCoverImageChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCourse((prev) => ({ ...prev, cover_image: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const addModule = () => {
    setCourse((prev) => ({
      ...prev,
      modules: [
        ...prev.modules,
        {
          title: '',
          description: '',
          cover_image: '',
          order: prev.modules.length + 1,
          status: 'Draft',
          video_lessons: [],
        },
      ],
    }));
  };

  const updateModule = (index, updatedModule) => {
    setCourse((prev) => ({
      ...prev,
      modules: prev.modules.map((module, i) => (i === index ? updatedModule : module)),
    }));
  };

  const removeModule = (index) => {
    setCourse((prev) => ({
      ...prev,
      modules: prev.modules.filter((_, i) => i !== index),
    }));
  };

  useEffect(() => {
    const totalDuration = course?.modules?.reduce(
      (total, module) => total + module.video_lessons.reduce((moduleTotal, lesson) => moduleTotal + lesson.duration, 0),
      0
    );
    setCourse((prev) => ({ ...prev, duration: totalDuration }));
  }, [course.modules]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrors({});

    try {
      const validatedCourse = courseSchema.parse(course);
      console.log('Submitting course:', validatedCourse);
      // Here you would send the validatedCourse to your API
      alert('Course saved successfully!');
    } catch (error) {
      if (error.errors) {
        const formattedErrors = {};
        error.errors.forEach((err) => {
          formattedErrors[err.path.join('.')] = err.message;
        });
        setErrors(formattedErrors);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <Card className="space bg-white shadow-lg rounded-lg p-8">
          <CardHeader>
            <CardTitle>Course Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                    Title
                  </label>
                  <Input name="title" value={course.title} onChange={handleInputChange} placeholder="Course Title" />
                </div>

                <div>
                  <label htmlFor="cover_image" className="block text-sm font-medium text-gray-700">
                    Cover Image
                  </label>
                  <Input
                    id="cover_image"
                    name="cover_image"
                    type="file"
                    onChange={handleCoverImageChange}
                    className="mt-1"
                  />
                </div>
                <div>
                  {course.cover_image && (
                    <div className="mt-2">
                      <Image src={course.cover_image} alt="Cover Image Preview" width={200} height={200} className="rounded-md" />
                    </div>
                  )}
                </div>
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-gray-700">
                    Category
                  </label>
                  <Input
                    id="category"
                    name="category"
                    value={course.category}
                    onChange={handleInputChange}
                    placeholder="Category"
                    className="mt-1"
                  />
                  {errors.category && <p className="mt-1 text-sm text-red-600">{errors.category}</p>}
                </div>

                <div>
                  <label htmlFor="difficulty_level" className="block text-sm font-medium text-gray-700">
                    Difficulty Level
                  </label>
                  <Select onValueChange={handleSelectChange('difficulty_level')} value={course.difficulty_level}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select difficulty" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Beginner">Beginner</SelectItem>
                      <SelectItem value="Intermediate">Intermediate</SelectItem>
                      <SelectItem value="Advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.difficulty_level && <p className="mt-1 text-sm text-red-600">{errors.difficulty_level}</p>}
                </div>

                <div>
                  <label htmlFor="prerequisites" className="block text-sm font-medium text-gray-700">
                    Prerequisites
                  </label>
                  <RichTextEditor content={course.prerequisites} onChange={handlePrerequisitesChange} />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch id="certification_status" checked={course.certification_status} onCheckedChange={handleSwitchChange('certification_status')} />
                  <label htmlFor="certification_status" className="text-sm font-medium text-gray-700">
                    Certification Available
                  </label>
                </div>
                <div className="text-sm font-medium text-gray-700">Total Duration: {course.duration} minutes</div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-gray-900">Modules</h2>
              {course.modules.map((module, index) => (
                <ModuleForm
                  key={index}
                  module={module}
                  onUpdate={(updatedModule) => updateModule(index, updatedModule)}
                  onRemove={() => removeModule(index)}
                />
              ))}
              <Button type="button" onClick={addModule} className="w-full">
                Add Module
              </Button>
            </div>
          </CardFooter>
        </Card>
        <Button type="submit" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? 'Saving...' : 'Save Course'}
        </Button>
      </form>
    </div>
  );
};
----
"use client";
import { createNewCourse, updateCourseDetails } from "@/app/api/server/route";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { CourseSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSession } from "next-auth/react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";

export const CourseForm = ({ initialData, categoryList, difficultyList, certificateList }) => {
  const router = useRouter();
  const { data: session } = useSession();
  const [loading, setLoading] = useState(false);
  const form = useForm({
    resolver: zodResolver(CourseSchema),
    defaultValues: initialData || {
      title: "",
      description: "",
      category: "",
      cover_image: "",
      duration: "",
      difficulty_level: "",
      prerequisites: "",
      has_certificate: false,
      certification: "",
      learning_objectives: "",
      status: "",
      modules: [],
    },
  });

  const { fields: modules, append: addModule, remove: removeModule } = useFieldArray({
    control: form.control,
    name: "modules",
  });

  const { fields: videos, append: addVideo, remove: removeVideo } = useFieldArray({
    control: form.control,
    name: "modules[0].videos", // This points to videos inside the first module (you can adjust as needed)
  });

  const hasCertificate = form.watch("has_certificate");

  useEffect(() => {
    form.reset(initialData);
  }, [initialData, form]);

  const handleSubmit = async (values) => {
    try {
      if (initialData && initialData.id) {
        await updateCourseDetails(session.accessToken, initialData.id, values);
      } else {
        await createNewCourse(session.accessToken, values);
      }
      toast.success("Course saved successfully");
      router.refresh();
    } catch (error) {
      toast.error(error.message);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>{initialData && initialData.id ? "Edit Course" : "Create Course"}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-8">
              <FormField control={form.control} name="title" render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter Course title" {...field} disabled={loading} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              {/* Course Status */}
              <FormField control={form.control} name="status" render={({ field }) => (
                <FormItem>
                  <FormLabel>Course Status</FormLabel>
                  <FormControl>
                    <Select {...field} onValueChange={(value) => field.onChange(value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Published">Published</SelectItem>
                        <SelectItem value="Inactive">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              {/* Certificate Switch */}
              <FormField control={form.control} name="has_certificate" render={({ field }) => (
                <FormItem>
                  <FormLabel>Certificate</FormLabel>
                  <FormControl>
                    <Switch
                      {...field}
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              {/* Certificate Dropdown (Conditional) */}
              {hasCertificate && (
                <FormField control={form.control} name="certification" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Certification</FormLabel>
                    <FormControl>
                      <Select {...field} onValueChange={field.onChange}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Certificate" />
                        </SelectTrigger>
                        <SelectContent>
                          {certificateList.map((cert) => (
                            <SelectItem key={cert.id} value={cert.id}>
                              {cert.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                ))} 
              }

              {/* Modules Section */}
              <FormField control={form.control} name="modules" render={({ field }) => (
                <div>
                  <h3 className="text-xl font-bold">Modules</h3>
                  {modules.map((module, index) => (
                    <Card key={module.id} className="mb-6">
                      <CardHeader>
                        <CardTitle>Module {index + 1}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <FormField control={form.control} name={`modules[${index}].title`} render={({ field }) => (
                          <FormItem>
                            <FormLabel>Module Title</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Module Title" disabled={loading} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />

                        {/* Video Fields */}
                        <h4 className="text-lg mt-4">Videos</h4>
                        <div>
                          {module.videos && module.videos.map((video, videoIndex) => (
                            <Card key={videoIndex} className="mb-4">
                              <CardHeader>
                                <CardTitle>Video {videoIndex + 1}</CardTitle>
                              </CardHeader>
                              <CardContent>
                                <FormField control={form.control} name={`modules[${index}].videos[${videoIndex}].title`} render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Video Title</FormLabel>
                                    <FormControl>
                                      <Input {...field} placeholder="Video Title" disabled={loading} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )} />

                                <FormField control={form.control} name={`modules[${index}].videos[${videoIndex}].video_url`} render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Video URL</FormLabel>
                                    <FormControl>
                                      <Input type="file" {...field} disabled={loading} />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )} />

                                <button type="button" onClick={() => removeVideo(videoIndex)}>Remove Video</button>
                              </CardContent>
                            </Card>
                          ))}
                          <button type="button" onClick={() => addVideo({})}>Add Video</button>
                        </div>

                        <button type="button" onClick={() => removeModule(index)}>Remove Module</button>
                      </CardContent>
                    </Card>
                  ))}
                  <button type="button" onClick={() => addModule({})}>Add Module</button>
                </div>
              )} />
            </div>
          </CardContent>
        </Card>
        <button type="submit" disabled={loading}>Submit</button>
      </form>
    </Form>
  );
};
description = models.TextField()
    cover_image = models.ImageField(upload_to='module_images/', blank=True, null=True)
    order = models.PositiveIntegerField(default=0)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    status = models.CharField(max_length=50, choices=StatusChoice)

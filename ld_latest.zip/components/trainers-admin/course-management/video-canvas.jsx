import { useEffect } from 'react';
import { fabric } from 'fabric';

const VideoCanvas = ({ videoSrc, onUpdateCanvas }) => {
  useEffect(() => {
    if (fabric) {
      const canvas = new fabric.Canvas('canvas');
      
      const videoElement = document.createElement('video');
      videoElement.src = videoSrc;
      videoElement.autoplay = true;

      videoElement.onloadeddata = () => {
        canvas.setWidth(videoElement.videoWidth);
        canvas.setHeight(videoElement.videoHeight);
        const video = new fabric.Image(videoElement);
        canvas.setBackgroundImage(video, canvas.renderAll.bind(canvas));
      };
    }
  }, [videoSrc]);

  return <canvas id="canvas"></canvas>;
};

export default VideoCanvas;

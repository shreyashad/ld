const { Button } = require("@/components/ui/button");
const { Card, CardHeader, CardContent, CardFooter } = require("@/components/ui/card");
const { FormItem, FormLabel, FormControl } = require("@/components/ui/form");
const { Input } = require("@/components/ui/input");
const { Controller } = require("react-hook-form");

const VideoForm = ({ index, moduleIndex, video, form, removeVideo, loading }) => {
    return (
        <Card key={video.id} className="mb-4">
            <CardHeader>Video {index + 1}</CardHeader>
            <CardContent>
                <Controller 
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].title`}
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Video Title</FormLabel>
                            <FormControl>
                                <Input 
                                    {...field}
                                    placeholder="Video Title" 
                                    disabled={loading}
                                />
                            </FormControl>
                        </FormItem>
                    )}
                />
                <Controller 
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].title`}
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Video Title</FormLabel>
                            <FormControl>
                                <Input 
                                    {...field}
                                    placeholder="Video Title" 
                                    disabled={loading}
                                />
                            </FormControl>
                        </FormItem>
                    )}
                />
                <Controller 
                    control={form.control}
                    name={`modules[${moduleIndex}].videos[${index}].title`}
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Video Title</FormLabel>
                            <FormControl>
                                <Input 
                                    {...field}
                                    placeholder="Video Title" 
                                    disabled={loading}
                                />
                            </FormControl>
                        </FormItem>
                    )}
                />
                <Controller 
                
                />
                <Controller 
                
                />
                <Controller 
                
                />
            </CardContent>
            <CardFooter>
                <Button type="button" onClick={() => removeVideo(index)}>Remove Video</Button>
            </CardFooter>
                    
        </Card>
    );
};

export default VideoForm;
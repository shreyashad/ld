"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ExaminationSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSession } from "next-auth/react";
import { useEffect, useState } from "react";
import { Controller, useFieldArray, useForm } from "react-hook-form";

export const TAExamForm = ({ initialData, courseList, queTypeList}) => {
    const { data: session } = useSession();
    const [ loading, setLoading ] = useState();

    const title = initialData && initialData.id ? "Edit Examination" : "Create New Examination";
    const description = initialData && initialData.id ? "Edit the Examination details" : "Create a new Examination";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(ExaminationSchema),
        defaultValues: initialData || {
            title: "",
            course: "",
            total_marks: "",
            pass_marks: "",
            duration:"",
            description: "",
            questions: [],
        }
    });

    const { fields, append, remove } = useFieldArray({
        control: form.control,
        name: "questions",
    });

    const updateTotalMarks = () => {
        const questions = form.getValues("questions");
        const totalMarks = questions.reduce((sum, question) => sum + Number(question.marks || 0), 0);
        form.setValue("total_marks", totalMarks);
        calculatePassingMarks(totalMarks);
    };

    const calculatePassingMarks = (totalMarks) => {
        const passingPercentage = 0.5; // Set the passing percentage, e.g., 50%
        const passingMarks = totalMarks * passingPercentage;
        form.setValue("pass_marks", passingMarks);
    };

    useEffect(() => {
        form.watch((value, { name, type }) => {
            if(name.includes("questions")) {
                updateTotalMarks();
            }
        });
        
    }, [form]);

    const addQuestion = () => {
        append({ question_type: "", question: "", marks: 0, options: [] });
    };

    const removeQuestion = (index) => {
        const updatedQuestions = form.getValues("questions").filter((_, i) => i !== index);
        form.setValue("questions", updatedQuestions);
    };


    return(
        <div className="container mx-auto p-4">
            <h1 className="text-2xl font-bold mb-4">{title}</h1>
            <p> {description}</p>
            <Card>
                <CardHeader>
                    <CardTitle>Exam Details</CardTitle>
                </CardHeader>
                <CardContent>
                    <Form {...form}>
                        <form>
                            <div className="grid grid-cols-2 gap-8">
                                <FormField 
                                    control={form.control}
                                    name="title"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel> Quiz Title</FormLabel>
                                            <FormControl>
                                                <Input
                                                    {...field}
                                                    placeholder="Enter Quiz Title"
                                                    disabled={loading}
                                                />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="course"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Course</FormLabel>
                                            <FormControl>
                                                <Select
                                                    disabled={loading || !courseList.length}
                                                    onValueChange={field.onChange}
                                                    value={field.value}
        
                                                >
                                                    <SelectTrigger>
                                                        <SelectValue 
                                                            placeholder={
                                                                courseList.length > 0
                                                                ? "Course  "
                                                                : "No Course available"
                                                            }
            
                                                        />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {courseList.length > 0 ?(
                                                            courseList.map((course) => (
                                                                <SelectItem key={course.id} value={course.id}>
                                                                    {course.title}
                                                                </SelectItem>
                                                            ))
                                                        ): (
                                                            <SelectItem disabled>
                                                                No Course found
                                                            </SelectItem>

                                                        )}
                                                    </SelectContent>
                                                </Select>
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField 
                                    control={form.control}
                                    name="total_marks"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel> Total Marks </FormLabel>
                                            <FormControl>
                                                <Input 
                                                    {...field}
                                                    type="number"
                                                    disabled={loading}
                                                />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                                <FormField 
                                    control={form.control}
                                    name="pass_marks"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel> Passing Marks </FormLabel>
                                            <FormControl>
                                                <Input 
                                                    {...field}
                                                    type="number"
                                                    disabled={loading}
                                                />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                                <FormField 
                                    control={form.control}
                                    name="duration"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel> Duration </FormLabel>
                                            <FormControl>
                                                <Input 
                                                    {...field}
                                                    type="time"
                                                    disabled={loading}
                                                />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                            </div>
                            <FormField 
                                    control={form.control}
                                    name="description"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel> Description </FormLabel>
                                            <FormControl>
                                                <Textarea 
                                                    {...field}
                                                    placeholder="Enter Quiz description"
                                                    disabled={loading}
                                                />
                                            </FormControl>
                                        </FormItem>
                                    )}
                            />
                            <div className="mt-6">
                                <Card className="mb-4">
                                    <CardHeader>
                                        <CardTitle>Add Questions</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="space-y-2 mb-4">
                                            {fields.map((item, index) => (
                                                <div key={item.id} className="border p-4 mb-4 rounded-md">
                                                    <FormField
                                                        control={form.control}
                                                        name={`questions[${index}].question`}
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Question Text</FormLabel>
                                                                <FormControl>
                                                                    <Textarea {...field} placeholder="Enter your Question" disabled={loading} />
                                                                </FormControl>
                                                            </FormItem>
                                                        )}
                                                    />
                                                    <FormField
                                                        control={form.control}
                                                        name={`questions[${index}].question_type`}
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Question Type</FormLabel>
                                                                <FormControl>
                                                                    <Select
                                                                        disabled={loading || !queTypeList.length}
                                                                        onValueChange={field.onChange}
                                                                        value={field.value}
                                                                    >
                                                                        <SelectTrigger>
                                                                            <SelectValue
                                                                                placeholder={queTypeList.length > 0 ? "Select Type" : "No Question Type available"}
                                                                            />
                                                                        </SelectTrigger>
                                                                        <SelectContent>
                                                                            {queTypeList.length > 0 ? (
                                                                                queTypeList.map((quetype) => (
                                                                                    <SelectItem key={quetype.id} value={quetype.name}>
                                                                                        {quetype.name}
                                                                                    </SelectItem>
                                                                                ))
                                                                            ) : (
                                                                                <SelectItem disabled>No Question Type found</SelectItem>
                                                                            )}
                                                                        </SelectContent>
                                                                    </Select>
                                                                </FormControl>
                                                                <FormMessage />
                                                            </FormItem>
                                                        )}
                                                    />
                                                    <FormField
                                                        control={form.control}
                                                        name={`questions[${index}].marks`}
                                                        render={({ field }) => (
                                                            <FormItem>
                                                                <FormLabel>Marks</FormLabel>
                                                                <FormControl>
                                                                    <Input 
                                                                        {...field} 
                                                                        type="number"
                                                                        placeholder="Enter your Question" 
                                                                        disabled={loading} 
                                                                    />
                                                                </FormControl>
                                                            </FormItem>
                                                        )}
                                                    />
                                                    {/* Dynamic handling based on question type */}
                                                    {(() => {
                                                        const questionType = form.getValues(`questions[${index}].question_type`);
                                                        switch (questionType) {
                                                            case "Multiple Choice Question":
                                                                return (
                                                                    <div className="mt-4">
                                                                        <FormLabel>Options</FormLabel>
                                                                        <div className="space-y-2">
                                                                            {item.options.map((option, optionIndex) => (
                                                                                <div key={optionIndex} className="flex items-center gap-2">
                                                                                    <Controller
                                                                                        control={form.control}
                                                                                        name={`questions[${index}].options[${optionIndex}].text`}
                                                                                        render={({ field }) => (
                                                                                            <FormItem>
                                                                                                <FormControl>
                                                                                                    <Input {...field} placeholder="Option Text" disabled={loading} />
                                                                                                </FormControl>
                                                                                            </FormItem>
                                                                                        )}
                                                                                    />
                                                                                    <Controller
                                                                                        control={form.control}
                                                                                        name={`questions[${index}].options[${optionIndex}].is_correct`}
                                                                                        render={({ field }) => (
                                                                                            <FormItem>
                                                                                                <FormControl>
                                                                                                    <input
                                                                                                        type="checkbox"
                                                                                                        {...field}
                                                                                                        disabled={loading}
                                                                                                    />
                                                                                                </FormControl>
                                                                                            </FormItem>
                                                                                        )}
                                                                                    />
                                                                                </div>
                                                                            ))}
                                                                        </div>
                                                                        <Button
                                                                            type="button"
                                                                            onClick={() => {
                                                                                const updatedQuestions = form.getValues("questions");
                                                                                updatedQuestions[index].options.push({ text: "", is_correct: false });
                                                                                form.setValue("questions", updatedQuestions);
                                                                            }}
                                                                            disabled={loading}
                                                                            className="px-4 py-2 bg-blue-500 text-white rounded"
                                                                        >
                                                                            Add Option
                                                                        </Button>
                                                                    </div>
                                                                );
                                                            case "Fill In The Blanks":
                                                                return (
                                                                    <FormField
                                                                        control={form.control}
                                                                        name={`questions[${index}].answer`}
                                                                        render={({ field }) => (
                                                                            <FormItem>
                                                                                <FormLabel>Answer</FormLabel>
                                                                                <FormControl>
                                                                                    <Input {...field} placeholder="Enter Answer" disabled={loading} />
                                                                                </FormControl>
                                                                            </FormItem>
                                                                        )}
                                                                    />
                                                                );
                                                            case "True or False":
                                                                return (
                                                                    <FormField
                                                                        control={form.control}
                                                                        name={`questions[${index}].answer`}
                                                                        render={({ field }) => (
                                                                            <FormItem>
                                                                                <FormLabel>Answer</FormLabel>
                                                                                <FormControl>
                                                                                    <Select
                                                                                        onValueChange={field.onChange}
                                                                                        value={field.value}
                                                                                        disabled={loading}
                                                                                    >
                                                                                        <SelectTrigger>
                                                                                            <SelectValue placeholder="Select Answer" />
                                                                                        </SelectTrigger>
                                                                                        <SelectContent>
                                                                                            <SelectItem value="True">True</SelectItem>
                                                                                            <SelectItem value="False">False</SelectItem>
                                                                                        </SelectContent>
                                                                                    </Select>
                                                                                </FormControl>
                                                                            </FormItem>
                                                                        )}
                                                                    />
                                                                );
                                                            case "Short Answers Question":
                                                                return (
                                                                    <FormField
                                                                        control={form.control}
                                                                        name={`questions[${index}].answer`}
                                                                        render={({ field }) => (
                                                                            <FormItem>
                                                                                <FormLabel>Answer</FormLabel>
                                                                                <FormControl>
                                                                                    <Input {...field} placeholder="Enter Answer" disabled={loading} />
                                                                                </FormControl>
                                                                            </FormItem>
                                                                        )}
                                                                    />
                                                                );
                                                            case "Ordering question types":
                                                                const orderingItems = item.ordering_items || [];
                                                                return(
                                                                    <div className="mt-4">
                                                                        <FormLabel>Order Items</FormLabel>
                                                                        <div className="space-y-2">
                                                                            {orderingItems.map((orderingItem, optionIndex) => (
                                                                                <div key={orderingItem.id || optionIndex} className="flex items-center gap-2">
                                                                                    <Controller
                                                                                        control={form.control}
                                                                                        name={`questions[${index}].ordering_items[${optionIndex}].text`}
                                                                                        render={({ field }) => (
                                                                                            <FormItem>
                                                                                                <FormControl>
                                                                                                    <Input
                                                                                                        {...field}
                                                                                                        placeholder={`Option ${optionIndex + 1}`}
                                                                                                        disabled={loading}
                                                                                                    />
                                                                                                </FormControl>
                                                                                            </FormItem>
                                                                                        )}
                                                                                    />
                                                                                    <Controller
                                                                                        control={form.control}
                                                                                        name={`questions[${index}].ordering_items[${optionIndex}].order`}
                                                                                        render={({ field }) => (
                                                                                            <FormItem>
                                                                                                <FormControl>
                                                                                                    <Input
                                                                                                        {...field}
                                                                                                        type="number"
                                                                                                        placeholder="Order"
                                                                                                        disabled={loading}
                                                                                                    />
                                                                                                </FormControl>
                                                                                            </FormItem>
                                                                                        )}
                                                                                    />
                                                                                </div>
                                                                            ))}
                                                                        </div>
                                                                        <Button
                                                                            type="button"
                                                                            onClick={() => {
                                                                                const updatedQuestions = form.getValues("questions");

                                                                                // Ensure ordering_items array exists
                                                                                if (!updatedQuestions[index].ordering_items) {
                                                                                    updatedQuestions[index].ordering_items = [];
                                                                                }

                                                                                // Add a new ordering item with default values
                                                                                updatedQuestions[index].ordering_items.push({ text: "", order: updatedQuestions[index].ordering_items.length + 1 });
                                                                                form.setValue("questions", updatedQuestions);
                                                                            }}
                                                                            disabled={loading}
                                                                            className="px-4 py-2 bg-blue-500 text-white rounded"
                                                                        >
                                                                            Add Option
                                                                        </Button>
                                                                    </div>
                                                                );
                                                            default:
                                                                return null;
                                                        }
                                                    })()}

                                                    <Button
                                                        type="button"
                                                        onClick={() => remove(index)}
                                                        disabled={loading}
                                                        className="mt-2 px-4 py-2 bg-red-500 text-white rounded"
                                                    >
                                                        Remove Question
                                                    </Button>
                                                </div>
                                            ))}
                                            <Button
                                                type="button"
                                                onClick={() => append({ question_type: "", question: "", marks: 0, options: [] })}
                                                disabled={loading}
                                                className="px-4 py-2 bg-blue-500 text-white rounded"
                                            >
                                                Add Question
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </div>
                            
                            
                            
                            <div className="mt-4 flex justify-end">
                                <Button
                                    type="submit"
                                    disabled={loading}
                                    className="px-6 py-2 text-white bg-blue-600 rounded-md disabled:bg-gray-400"
                                >
                                    {action}
                                </Button>
                            </div>
                        </form>
                    </Form>
                </CardContent>
            </Card>
        </div>
    );
};


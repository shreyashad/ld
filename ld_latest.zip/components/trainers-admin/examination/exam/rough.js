"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function ExamCreator() {
  const [exam, setExam] = useState({
    title: "",
    course: "",
    startTime: "",
    endTime: "",
    duration: 0,
    totalMarks: 0,
    passingMarks: 0,
    description: "",
    questions: [],
  });
  const [currentQuestion, setCurrentQuestion] = useState({
    type: "mcq",
    text: "",
    options: ["", "", "", ""],
    correctAnswer: "",
  });

  const handleExamChange = (field, value) => {
    setExam({ ...exam, [field]: value });
  };

  const handleQuestionChange = (field, value) => {
    setCurrentQuestion({ ...currentQuestion, [field]: value });
  };

  const addQuestion = () => {
    setExam({ ...exam, questions: [...exam.questions, currentQuestion] });
    setCurrentQuestion({
      type: "mcq",
      text: "",
      options: ["", "", "", ""],
      correctAnswer: "",
    });
  };

  const renderQuestionForm = () => {
    switch (currentQuestion.type) {
      case "mcq":
        return (
          <>
            <Textarea
              placeholder="Enter question text"
              value={currentQuestion.text}
              onChange={(e) => handleQuestionChange("text", e.target.value)}
              className="mb-2"
            />
            {currentQuestion.options?.map((option, index) => (
              <Input
                key={index}
                placeholder={`Option ${index + 1}`}
                value={option}
                onChange={(e) => {
                  const newOptions = [...(currentQuestion.options || [])];
                  newOptions[index] = e.target.value;
                  handleQuestionChange("options", newOptions);
                }}
                className="mb-2"
              />
            ))}
            <Select
              value={currentQuestion.correctAnswer}
              onValueChange={(value) => handleQuestionChange("correctAnswer", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select correct answer" />
              </SelectTrigger>
              <SelectContent>
                {currentQuestion.options?.map((option, index) => (
                  <SelectItem key={index} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </>
        );
      case "fillInTheBlank":
        return (
          <>
            <Textarea
              placeholder="Enter question text (use ___ for blank)"
              value={currentQuestion.text}
              onChange={(e) => handleQuestionChange("text", e.target.value)}
              className="mb-2"
            />
            <Input
              placeholder="Correct answer"
              value={currentQuestion.correctAnswer}
              onChange={(e) => handleQuestionChange("correctAnswer", e.target.value)}
            />
          </>
        );
      case "trueOrFalse":
        return (
          <>
            <Textarea
              placeholder="Enter question text"
              value={currentQuestion.text}
              onChange={(e) => handleQuestionChange("text", e.target.value)}
              className="mb-2"
            />
            <Select
              value={currentQuestion.correctAnswer}
              onValueChange={(value) => handleQuestionChange("correctAnswer", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select correct answer" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="true">True</SelectItem>
                <SelectItem value="false">False</SelectItem>
              </SelectContent>
            </Select>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Online Examination Creator</h1>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>Exam Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="examTitle">Exam Title</Label>
              <Input
                id="examTitle"
                value={exam.title}
                onChange={(e) => handleExamChange("title", e.target.value)}
                placeholder="Enter exam title"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="examCourse">Course</Label>
              <Input
                id="examCourse"
                value={exam.course}
                onChange={(e) => handleExamChange("course", e.target.value)}
                placeholder="Enter course name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="examStartTime">Start Time</Label>
              <Input
                id="examStartTime"
                type="datetime-local"
                value={exam.startTime}
                onChange={(e) => handleExamChange("startTime", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="examEndTime">End Time</Label>
              <Input
                id="examEndTime"
                type="datetime-local"
                value={exam.endTime}
                onChange={(e) => handleExamChange("endTime", e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="examDuration">Duration (minutes)</Label>
              <Input
                id="examDuration"
                type="number"
                value={exam.duration}
                onChange={(e) => handleExamChange("duration", parseInt(e.target.value))}
                placeholder="Enter exam duration"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="examTotalMarks">Total Marks</Label>
              <Input
                id="examTotalMarks"
                type="number"
                value={exam.totalMarks}
                onChange={(e) => handleExamChange("totalMarks", parseInt(e.target.value))}
                placeholder="Enter total marks"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="examPassingMarks">Passing Marks</Label>
              <Input
                id="examPassingMarks"
                type="number"
                value={exam.passingMarks}
                onChange={(e) => handleExamChange("passingMarks", parseInt(e.target.value))}
                placeholder="Enter passing marks"
              />
            </div>
          </div>
          <div className="space-y-2 mt-4">
            <Label htmlFor="examDescription">Exam Description</Label>
            <Textarea
              id="examDescription"
              value={exam.description}
              onChange={(e) => handleExamChange("description", e.target.value)}
              placeholder="Enter exam description"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>Add Question</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 mb-4">
            <Label htmlFor="questionType">Question Type</Label>
            <Select
              value={currentQuestion.type}
              onValueChange={(value) => handleQuestionChange("type", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select question type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mcq">Multiple Choice</SelectItem>
                <SelectItem value="fillInTheBlank">Fill in the Blank</SelectItem>
                <SelectItem value="trueOrFalse">True or False</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {renderQuestionForm()}
          <Button onClick={addQuestion} className="mt-4">
            Add Question
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Exam Preview</CardTitle>
        </CardHeader>
        <CardContent>
          <h2 className="text-xl font-semibold">{exam.title}</h2>
          <p className="mb-2">Course: {exam.course}</p>
          <p className="mb-2">Start Time: {exam.startTime}</p>
          <p className="mb-2">End Time: {exam.endTime}</p>
          <p className="mb-2">Duration: {exam.duration} minutes</p>
          <p className="mb-2">Total Marks: {exam.totalMarks}</p>
          <p className="mb-2">Passing Marks: {exam.passingMarks}</p>
          <p className="mb-4">{exam.description}</p>
          <h3 className="text-lg font-semibold mb-2">Questions:</h3>
          {exam.questions.map((question, index) => (
            <div key={index} className="mb-4">
              <p className="font-semibold">
                Question {index + 1}: {question.text}
              </p>
              {question.type === "mcq" && (
                <ul className="list-disc pl-6">
                  {question.options?.map((option, optionIndex) => (
                    <li key={optionIndex}>{option}</li>
                  ))}
                </ul>
              )}
              <p className="text-sm text-gray-500">Correct Answer: {question.correctAnswer}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
----------------
"use client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ExaminationSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";

export const TAExamForm = ({ initialData, courseList }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const title = initialData && initialData.id ? "Edit Examination" : "Create New Examination";
    const description = initialData && initialData.id ? "Edit the Examination details" : "Create a new Examination";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(ExaminationSchema),
        defaultValues: initialData || {
            title: '',
            course: '',
            total_marks: '',
            pass_marks: '',
            duration: '',
            description: '',
            questions: []
        }
    });

    useEffect(() => {
        if (initialData) {
            form.reset(initialData); // If initial data exists, reset the form with initial values
        }
    }, [initialData, form]);

    // Handle form submission
    const handleSubmit = async (data) => {
        setLoading(true);
        try {
            // Handle API call or form submission logic here
            // Example: await submitExamData(data);
            router.push("/exams"); // Redirect after successful submission
        } catch (error) {
            console.error("Error submitting exam data:", error);
        } finally {
            setLoading(false);
        }
    };

    // Handle adding/removing questions dynamically
    const addQuestion = () => {
        form.setValue("questions", [...form.getValues("questions"), { question_type: "", question: "", options: [] }]);
    };

    const removeQuestion = (index) => {
        const updatedQuestions = form.getValues("questions").filter((_, i) => i !== index);
        form.setValue("questions", updatedQuestions);
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleSubmit)}>
                        <div className="grid grid-cols-2 gap-8">
                            {/* General Fields */}
                            <FormField
                                control={form.control}
                                name="title"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Exam Title</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                placeholder="Enter exam title"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />

                            {/* Course Selection */}
                            <FormField
                                control={form.control}
                                name="course"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Course</FormLabel>
                                        <FormControl>
                                            <Select
                                                disabled={loading || !courseList.length}
                                                onValueChange={field.onChange}
                                                value={field.value}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue
                                                        placeholder={
                                                            courseList.length > 0
                                                                ? "Select a Course"
                                                                : "No Course available"
                                                        }
                                                    />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {courseList.length > 0 ? (
                                                        courseList.map((course) => (
                                                            <SelectItem key={course.id} value={course.id}>
                                                                {course.title}
                                                            </SelectItem>
                                                        ))
                                                    ) : (
                                                        <SelectItem disabled>No Courses Found</SelectItem>
                                                    )}
                                                </SelectContent>
                                            </Select>
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />

                            {/* Total Marks */}
                            <FormField
                                control={form.control}
                                name="total_marks"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Total Marks</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                type="number"
                                                placeholder="Enter total marks"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />

                            {/* Passing Marks */}
                            <FormField
                                control={form.control}
                                name="pass_marks"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Passing Marks</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                type="number"
                                                placeholder="Enter passing marks"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />

                            {/* Duration */}
                            <FormField
                                control={form.control}
                                name="duration"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Duration (in minutes)</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                type="number"
                                                placeholder="Enter duration"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                        </div>

                        {/* Description */}
                        <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Description</FormLabel>
                                    <FormControl>
                                        <Textarea
                                            {...field}
                                            placeholder="Enter exam description"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />

                        {/* Questions Section */}
                        <div className="mt-6">
                            <FormLabel>Questions</FormLabel>
                            {form.getValues("questions").map((question, index) => (
                                <div key={index} className="border p-4 mb-4 rounded-md">
                                    {/* Question Text */}
                                    <FormField
                                        control={form.control}
                                        name={`questions[${index}].question`}
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Question Text</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...field}
                                                        placeholder="Enter the question text"
                                                        disabled={loading}
                                                    />
                                                </FormControl>
                                            </FormItem>
                                        )}
                                    />

                                    {/* Question Type */}
                                    <FormField
                                        control={form.control}
                                        name={`questions[${index}].question_type`}
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Question Type</FormLabel>
                                                <FormControl>
                                                    <Select
                                                        {...field}
                                                        disabled={loading}
                                                        onValueChange={field.onChange}
                                                    >
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select question type" />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                                                            <SelectItem value="true_false">True/False</SelectItem>
                                                            <SelectItem value="fill_in_the_blanks">Fill in the Blanks</SelectItem>
                                                            <SelectItem value="short_answer">Short Answer</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </FormControl>
                                            </FormItem>
                                        )}
                                    />

                                    {/* Handle different question types */}
                                    {question.question_type === "multiple_choice" && (
                                        <>
                                            <div className="mt-4">
                                                <FormLabel>Options</FormLabel>
                                                {question.options.map((option, optionIndex) => (
                                                    <div key={optionIndex} className="flex items-center gap-2">
                                                        <Controller
                                                            control={form.control}
                                                            name={`questions[${index}].options[${optionIndex}].text`}
                                                            render={({ field }) => (
                                                                <FormItem>
                                                                    <FormControl>
                                                                        <Input
                                                                            {...field}
                                                                            placeholder="Option Text"
                                                                            disabled={loading}
                                                                        />
                                                                    </FormControl>
                                                                </FormItem>
                                                            )}
                                                        />
                                                        <Controller
                                                            control={form.control}
                                                            name={`questions[${index}].options[${optionIndex}].is_correct`}
                                                            render={({ field }) => (
                                                                <FormItem>
                                                                    <FormControl>
                                                                        <input
                                                                            type="checkbox"
                                                                            {...field}
                                                                            disabled={loading}
                                                                        />
                                                                    </FormControl>
                                                                </FormItem>
                                                            )}
                                                        />
                                                    </div>
                                                ))}
                                            </div>

                                            {/* Add Option Button */}
                                            <div className="mt-2">
                                                <button
                                                    type="button"
                                                    onClick={() => {
                                                        const updatedQuestions = form.getValues("questions");
                                                        updatedQuestions[index].options.push({ text: "", is_correct: false });
                                                        form.setValue("questions", updatedQuestions);
                                                    }}
                                                    disabled={loading}
                                                    className="px-4 py-2 bg-blue-500 text-white rounded"
                                                >
                                                    Add Option
                                                </button>
                                            </div>
                                        </>
                                    )}

                                    {/* Remove Question Button */}
                                    <div className="mt-2">
                                        <button
                                            type="button"
                                            onClick={() => removeQuestion(index)}
                                            disabled={loading}
                                            className="px-4 py-2 bg-red-500 text-white rounded"
                                        >
                                            Remove Question
                                        </button>
                                    </div>
                                </div>
                            ))}

                            {/* Add New Question Button */}
                            <div className="mt-4">
                                <button
                                    type="button"
                                    onClick={addQuestion}
                                    disabled={loading}
                                    className="px-6 py-2 bg-green-600 text-white rounded"
                                >
                                    Add Question
                                </button>
                            </div>
                        </div>

                        {/* Submit Button */}
                        <div className="mt-4 flex justify-end">
                            <button
                                type="submit"
                                disabled={loading}
                                className="px-6 py-2 text-white bg-blue-600 rounded-md disabled:bg-gray-400"
                            >
                                {action}
                            </button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};
---------
"use client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ExaminationSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";

export const TAExamForm = ({ initialData, courseList, queTypeList }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [loading, setLoading] = useState(false);

    const title = initialData && initialData.id ? "Edit Examination" : "Create New Examination";
    const description = initialData && initialData.id ? "Edit the Examination details" : "Create a new Examination";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(ExaminationSchema),
        defaultValues: initialData || {
            title: "",
            course: "",
            total_marks: "",
            pass_marks: "",
            duration: "",
            description: "",
            questions: []
        }
    });

    useEffect(() => {
        if (initialData) {
            form.reset(initialData); // Reset form with initial data if provided
        }
    }, [initialData, form]);

    const handleSubmit = async (data) => {
        setLoading(true);
        try {
            // Handle API call or form submission logic here
            // Example: await submitExamData(data);
            router.push("/exams"); // Redirect after successful submission
        } catch (error) {
            console.error("Error submitting exam data:", error);
        } finally {
            setLoading(false);
        }
    };

    // Handle adding/removing questions dynamically
    const addQuestion = () => {
        form.setValue("questions", [
            ...form.getValues("questions"),
            { question_type: "", question: "", options: [] }
        ]);
    };

    const removeQuestion = (index) => {
        const updatedQuestions = form.getValues("questions").filter((_, i) => i !== index);
        form.setValue("questions", updatedQuestions);
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleSubmit)}>
                        <div className="grid grid-cols-2 gap-8">
                            {/* General Fields */}
                            <FormField
                                control={form.control}
                                name="title"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Exam Title</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                placeholder="Enter exam title"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />

                            {/* Course Selection */}
                            <FormField
                                control={form.control}
                                name="course"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Course</FormLabel>
                                        <FormControl>
                                            <Select
                                                disabled={loading || !courseList.length}
                                                onValueChange={field.onChange}
                                                value={field.value}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue
                                                        placeholder={
                                                            courseList.length > 0
                                                                ? "Select a Course"
                                                                : "No Course available"
                                                        }
                                                    />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {courseList.length > 0 ? (
                                                        courseList.map((course) => (
                                                            <SelectItem key={course.id} value={course.id}>
                                                                {course.title}
                                                            </SelectItem>
                                                        ))
                                                    ) : (
                                                        <SelectItem disabled>No Courses Found</SelectItem>
                                                    )}
                                                </SelectContent>
                                            </Select>
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />

                            {/* Total Marks */}
                            <FormField
                                control={form.control}
                                name="total_marks"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Total Marks</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                type="number"
                                                placeholder="Enter total marks"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />

                            {/* Passing Marks */}
                            <FormField
                                control={form.control}
                                name="pass_marks"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Passing Marks</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                type="number"
                                                placeholder="Enter passing marks"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />

                            {/* Duration */}
                            <FormField
                                control={form.control}
                                name="duration"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Duration (in minutes)</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                type="number"
                                                placeholder="Enter duration"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                        </div>

                        {/* Description */}
                        <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Description</FormLabel>
                                    <FormControl>
                                        <Textarea
                                            {...field}
                                            placeholder="Enter exam description"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />

                        {/* Questions Section */}
                        <div className="mt-6">
                            <FormLabel>Questions</FormLabel>
                            {form.getValues("questions").map((question, index) => (
                                <div key={index} className="border p-4 mb-4 rounded-md">
                                    {/* Question Text */}
                                    <FormField
                                        control={form.control}
                                        name={`questions[${index}].question`}
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Question Text</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...field}
                                                        placeholder="Enter the question text"
                                                        disabled={loading}
                                                    />
                                                </FormControl>
                                            </FormItem>
                                        )}
                                    />

                                    {/* Question Type */}
                                    <FormField
                                        control={form.control}
                                        name={`questions[${index}].question_type`}
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Question Type</FormLabel>
                                                <FormControl>
                                                    <Select
                                                        {...field}
                                                        disabled={loading}
                                                        onValueChange={field.onChange}
                                                    >
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select question type" />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            {queTypeList.map((type) => (
                                                                <SelectItem key={type} value={type}>
                                                                    {type}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                </FormControl>
                                            </FormItem>
                                        )}
                                    />

                                    {/* Handle different question types */}
                                    {question.question_type === "Multiple Choice Question" && (
                                        <>
                                            <div className="mt-4">
                                                <FormLabel>Options</FormLabel>
                                                {question.options.map((option, optionIndex) => (
                                                    <div key={optionIndex} className="flex items-center gap-2">
                                                        <Controller
                                                            control={form.control}
                                                            name={`questions[${index}].options[${optionIndex}].text`}
                                                            render={({ field }) => (
                                                                <FormItem>
                                                                    <FormControl>
                                                                        <Input
                                                                            {...field}
                                                                            placeholder="Option Text"
                                                                            disabled={loading}
                                                                        />
                                                                    </FormControl>
                                                                </FormItem>
                                                            )}
                                                        />
                                                        <Controller
                                                            control={form.control}
                                                            name={`questions[${index}].options[${optionIndex}].is_correct`}
                                                            render={({ field }) => (
                                                                <FormItem>
                                                                    <FormControl>
                                                                        <input
                                                                            type="checkbox"
                                                                            {...field}
                                                                            disabled={loading}
                                                                        />
                                                                    </FormControl>
                                                                </FormItem>
                                                            )}
                                                        />
                                                    </div>
                                                ))}
                                            </div>

                                            {/* Add Option Button */}
                                            <div className="mt-2">
                                                <button
                                                    type="button"
                                                    onClick={() => {
                                                        const updatedQuestions = form.getValues("questions");
                                                        updatedQuestions[index].options.push({ text: "", is_correct: false });
                                                        form.setValue("questions", updatedQuestions);
                                                    }}
                                                    disabled={loading}
                                                    className="px-4 py-2 bg-blue-500 text-white rounded"
                                                >
                                                    Add Option
                                                </button>
                                            </div>
                                        </>
                                    )}

                                    {/* Remove Question Button */}
                                    <div className="mt-2">
                                        <button
                                            type="button"
                                            onClick={() => removeQuestion(index)}
                                            disabled={loading}
                                            className="px-4 py-2 bg-red-500 text-white rounded"
                                        >
                                            Remove Question
                                        </button>
                                    </div>
                                </div>
                            ))}

                            {/* Add New Question Button */}
                            <div className="mt-4">
                                <button
                                    type="button"
                                    onClick={addQuestion}
                                    disabled={loading}
                                    className="px-6 py-2 bg-green-600 text-white rounded"
                                >
                                    Add Question
                                </button>
                            </div>
                        </div>

                        {/* Submit Button */}
                        <div className="mt-4 flex justify-end">
                            <button
                                type="submit"
                                disabled={loading}
                                className="px-6 py-2 text-white bg-blue-600 rounded-md disabled:bg-gray-400"
                            >
                                {action}
                            </button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};
-------
"use client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ExaminationSchema } from "@/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";

export const TAExamForm = ({ initialData, courseList, queTypeList }) => {
    const { data: session } = useSession();
    const router = useRouter();
    const [loading, setLoading] = useState(false);

    const title = initialData && initialData.id ? "Edit Examination" : "Create New Examination";
    const description = initialData && initialData.id ? "Edit the Examination details" : "Create a new Examination";
    const action = initialData && initialData.id ? "Save Changes" : "Create";

    const form = useForm({
        resolver: zodResolver(ExaminationSchema),
        defaultValues: initialData || {
            title: "",
            course: "",
            total_marks: "",
            pass_marks: "",
            duration: "",
            description: "",
            questions: [] // Ensure questions are always initialized as an empty array
        }
    });

    useEffect(() => {
        if (initialData) {
            form.reset(initialData); // Reset form with initial data if provided
        }
    }, [initialData, form]);

    const handleSubmit = async (data) => {
        setLoading(true);
        try {
            // Handle API call or form submission logic here
            // Example: await submitExamData(data);
            router.push("/exams"); // Redirect after successful submission
        } catch (error) {
            console.error("Error submitting exam data:", error);
        } finally {
            setLoading(false);
        }
    };

    // Handle adding/removing questions dynamically
    const addQuestion = () => {
        form.setValue("questions", [
            ...form.getValues("questions"),
            { question_type: "", question: "", options: [] }
        ]);
    };

    const removeQuestion = (index) => {
        const updatedQuestions = form.getValues("questions").filter((_, i) => i !== index);
        form.setValue("questions", updatedQuestions);
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleSubmit)}>
                        <div className="grid grid-cols-2 gap-8">
                            {/* General Fields */}
                            <FormField
                                control={form.control}
                                name="title"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Exam Title</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                placeholder="Enter exam title"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />

                            {/* Course Selection */}
                            <FormField
                                control={form.control}
                                name="course"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Course</FormLabel>
                                        <FormControl>
                                            <Select
                                                disabled={loading || !courseList.length}
                                                onValueChange={field.onChange}
                                                value={field.value}
                                            >
                                                <SelectTrigger>
                                                    <SelectValue
                                                        placeholder={
                                                            courseList.length > 0
                                                                ? "Select a Course"
                                                                : "No Course available"
                                                        }
                                                    />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    {courseList.length > 0 ? (
                                                        courseList.map((course) => (
                                                            <SelectItem key={course.id} value={course.id}>
                                                                {course.title}
                                                            </SelectItem>
                                                        ))
                                                    ) : (
                                                        <SelectItem disabled>No Courses Found</SelectItem>
                                                    )}
                                                </SelectContent>
                                            </Select>
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />

                            {/* Total Marks */}
                            <FormField
                                control={form.control}
                                name="total_marks"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Total Marks</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                type="number"
                                                placeholder="Enter total marks"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />

                            {/* Passing Marks */}
                            <FormField
                                control={form.control}
                                name="pass_marks"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Passing Marks</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                type="number"
                                                placeholder="Enter passing marks"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />

                            {/* Duration */}
                            <FormField
                                control={form.control}
                                name="duration"
                                render={({ field }) => (
                                    <FormItem>
                                        <FormLabel>Duration (in minutes)</FormLabel>
                                        <FormControl>
                                            <Input
                                                {...field}
                                                type="number"
                                                placeholder="Enter duration"
                                                disabled={loading}
                                            />
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                        </div>

                        {/* Description */}
                        <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Description</FormLabel>
                                    <FormControl>
                                        <Textarea
                                            {...field}
                                            placeholder="Enter exam description"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />

                        {/* Questions Section */}
                        <div className="mt-6">
                            <FormLabel> Questions</FormLabel>
                            { (form.getValues("questions") || []).map((question, index) => (
                                <div key={index} className="border p-4 mb-4 rounded-md">
                                    <FormField
                                        control={form.control}
                                        name={`questions[${index}].question`}
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Question Text</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...field}
                                                        placeholder="Enter the question text"
                                                        disabled={loading}
                                                    />
                                                </FormControl>
                                            </FormItem>
                                        )}
                                    />
                                    {/* Add Options (for Multiple Choice) */}
                                    {question.question_type === "Multiple Choice Question" && (
                                        <div>
                                            {/* Render Options */}
                                        </div>
                                    )}

                                    {/* Remove Question */}
                                    <div className="mt-2">
                                        <button
                                            type="button"
                                            onClick={() => removeQuestion(index)}
                                            disabled={loading}
                                            className="px-4 py-2 bg-red-500 text-white rounded"
                                        >
                                            Remove Question
                                        </button>
                                    </div>
                                </div>
                            ))}

                            {/* Add New Question Button */}
                            <div className="mt-4">
                                <button
                                    type="button"
                                    onClick={addQuestion}
                                    disabled={loading}
                                    className="px-6 py-2 bg-green-600 text-white rounded"
                                >
                                    Add Question
                                </button>
                            </div>
                        </div>

                        {/* Submit Button */}
                        <div className="mt-4 flex justify-end">
                            <button
                                type="submit"
                                disabled={loading}
                                className="px-6 py-2 text-white bg-blue-600 rounded-md disabled:bg-gray-400"
                            >
                                {action}
                            </button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};

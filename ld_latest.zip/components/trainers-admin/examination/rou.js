"use client";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button, Input, Textarea, Select, Form, FormField, FormItem, FormLabel, FormControl } from "@/components/ui";
import toast from "react-hot-toast";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { createQuiz, updateQuiz, deleteQuiz, createQuestion, updateQuestion, deleteQuestion } from "@/app/api/quiz";
import { QuestionTypeSchema, QuizSchema } from "@/schema";
import { Trash2 } from "lucide-react";

export const QuizForm = ({ initialData }) => {
  const { data: session } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState(initialData?.questions || []);
  const [questionTypes, setQuestionTypes] = useState([]);
  
  const form = useForm({
    resolver: zodResolver(QuizSchema),
    defaultValues: initialData || { title: "", description: "", duration: "", pass_marks: "", questions: [] },
  });

  useEffect(() => {
    // Fetch available question types from the backend (e.g., multiple choice, true/false, etc.)
    fetchQuestionTypes();
  }, []);

  const fetchQuestionTypes = async () => {
    // Fetch available question types from the API or static list
    setQuestionTypes([{ name: "MultipleChoice" }, { name: "TrueFalse" }, { name: "FillInTheBlanks" }]); // Example question types
  };

  const addQuestion = () => {
    setQuestions([...questions, { type: "MultipleChoice", text: "", options: ["", "", "", ""], correctAnswer: "" }]);
  };

  const removeQuestion = (index) => {
    setQuestions(questions.filter((_, i) => i !== index));
  };

  const handleQuestionChange = (index, key, value) => {
    const updatedQuestions = [...questions];
    updatedQuestions[index][key] = value;
    setQuestions(updatedQuestions);
  };

  const onSubmit = async (values) => {
    setLoading(true);
    try {
      if (initialData?.id) {
        // Update existing quiz
        await updateQuiz(session.accessToken, initialData.id, values, questions);
        toast.success("Quiz updated successfully");
      } else {
        // Create new quiz
        await createQuiz(session.accessToken, values, questions);
        toast.success("Quiz created successfully");
      }
      router.push("/dashboard/quiz");
    } catch (error) {
      toast.error(error.message || "Error creating quiz");
    }
    setLoading(false);
  };

  const onDelete = async () => {
    setLoading(true);
    try {
      await deleteQuiz(session.accessToken, initialData.id);
      toast.success("Quiz deleted successfully");
      router.push("/dashboard/quiz");
    } catch (error) {
      toast.error(error.message || "Error deleting quiz");
    }
    setLoading(false);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <div>
          <FormField control={form.control} name="title" render={({ field }) => (
            <FormItem>
              <FormLabel>Quiz Title</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Enter quiz title" disabled={loading} />
              </FormControl>
            </FormItem>
          )} />
        </div>

        <div>
          <FormField control={form.control} name="description" render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea {...field} placeholder="Enter quiz description" disabled={loading} />
              </FormControl>
            </FormItem>
          )} />
        </div>

        <div>
          <FormField control={form.control} name="duration" render={({ field }) => (
            <FormItem>
              <FormLabel>Duration</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Duration in HH:MM:SS" disabled={loading} />
              </FormControl>
            </FormItem>
          )} />
        </div>

        <div>
          <FormField control={form.control} name="pass_marks" render={({ field }) => (
            <FormItem>
              <FormLabel>Pass Marks</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Enter pass marks" disabled={loading} />
              </FormControl>
            </FormItem>
          )} />
        </div>

        <div>
          <h3 className="text-xl font-bold">Questions</h3>
          <div className="space-y-4">
            {questions.map((question, index) => (
              <div key={index} className="space-y-4 border p-4 rounded-md">
                <FormField control={form.control} name={`questions.${index}.text`} render={({ field }) => (
                  <FormItem>
                    <FormLabel>Question Text</FormLabel>
                    <FormControl>
                      <Input {...field} value={question.text} placeholder="Enter question text" onChange={(e) => handleQuestionChange(index, "text", e.target.value)} disabled={loading} />
                    </FormControl>
                  </FormItem>
                )} />
                <FormField control={form.control} name={`questions.${index}.type`} render={({ field }) => (
                  <FormItem>
                    <FormLabel>Question Type</FormLabel>
                    <FormControl>
                      <Select {...field} value={question.type} onChange={(e) => handleQuestionChange(index, "type", e.target.value)} disabled={loading}>
                        {questionTypes.map((type) => (
                          <option key={type.name} value={type.name}>{type.name}</option>
                        ))}
                      </Select>
                    </FormControl>
                  </FormItem>
                )} />

                {/* Dynamic fields based on question type */}
                {question.type === "MultipleChoice" && (
                  <div>
                    {question.options.map((option, optIndex) => (
                      <FormField key={optIndex} control={form.control} name={`questions.${index}.options.${optIndex}`} render={({ field }) => (
                        <FormItem>
                          <FormLabel>Option {optIndex + 1}</FormLabel>
                          <FormControl>
                            <Input {...field} value={option} onChange={(e) => handleQuestionChange(index, "options", e.target.value)} disabled={loading} />
                          </FormControl>
                        </FormItem>
                      )} />
                    ))}
                  </div>
                )}
                
                {/* Add more conditional fields for other question types */}
                
                <Button type="button" variant="destructive" onClick={() => removeQuestion(index)} disabled={loading}>
                  <Trash2 className="h-4 w-4" /> Remove Question
                </Button>
              </div>
            ))}
          </div>
          <Button type="button" onClick={addQuestion} disabled={loading}>
            Add Question
          </Button>
        </div>

        <div className="space-x-4">
          <Button type="submit" disabled={loading}>{initialData ? "Save Changes" : "Create Quiz"}</Button>
          {initialData && initialData.id && (
            <Button variant="destructive" onClick={onDelete} disabled={loading}>Delete Quiz</Button>
          )}
        </div>
      </form>
    </Form>
  );
};

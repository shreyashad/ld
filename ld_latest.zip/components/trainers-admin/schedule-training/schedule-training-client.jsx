"use client";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";


const ScheduleTrainingClient = () => {
   const router = useRouter();
   return (
        <>
            
                <Button
                    onClick={() => {
                        router.push("/dashboard/trainers-admin/training-management/schedule-training/new")
                    }}
                >Schedule New Training</Button>
             
        </>

    );
};

export default ScheduleTrainingClient;
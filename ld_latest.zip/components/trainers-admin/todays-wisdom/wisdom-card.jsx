import { Card, CardContent, CardHeader } from "@/components/ui/card";

const WisdomCard = ({ quote}) => {
  return (
    <Card className="max-w-md mx-auto ">
      <CardHeader>
        <h2 className="text-xl font-bold">Today's Wisdom</h2>
      </CardHeader>
      <CardContent>
        <p className="text-gray-700">"{quote}"</p>
      </CardContent>
      
    </Card>
  );
};

export default WisdomCard;

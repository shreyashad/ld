"use client";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useSession } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { DatePicker } from "@/components/ui/datepicker";
import { fetchRoomAvailability, fetchTrainerAvailability } from "@/app/api/server/route";
import toast from "react-hot-toast";

export const TrainingBookingForm = ({ initialData }) => {
    const { data: session } = useSession();
    const [loading, setLoading] = useState(false);
    const [currentStep, setCurrentStep] = useState(0); // Start with Step 0 (Request details)
    const [selectedDate, setSelectedDate] = useState(null);
    const [availableRooms, setAvailableRooms] = useState([]);
    const [availableTrainers, setAvailableTrainers] = useState([]);
    const [selectedRoom, setSelectedRoom] = useState(null);
    const [selectedTrainer, setSelectedTrainer] = useState(null);

    const form = useForm({
        defaultValues: {
            course: initialData?.course || "",
            additionalNotes: initialData?.additional_notes || "",
        },
    });

    // Step 1: Fetch available rooms and trainers based on selected date
    useEffect(() => {
        if (selectedDate) {
            const fetchAvailability = async () => {
                setLoading(true);
                try {
                    const roomData = await fetchRoomAvailability(session.accessToken, selectedDate);
                    setAvailableRooms(roomData);
                    const trainerData = await fetchTrainerAvailability(session.accessToken, selectedDate);
                    setAvailableTrainers(trainerData);
                } catch (error) {
                    toast.error("Failed to fetch availability data.");
                } finally {
                    setLoading(false);
                }
            };

            fetchAvailability();
        }
    }, [selectedDate, session?.accessToken]);

    const handleDateChange = (date) => {
        setSelectedDate(date);
        setCurrentStep(1); // Move to Step 2 after date selection
    };

    const handleRoomChange = (e) => {
        setSelectedRoom(e.target.value);
    };

    const handleTrainerChange = (e) => {
        setSelectedTrainer(e.target.value);
    };

    const handleSubmit = async (values) => {
        setLoading(true);
        try {
            // Submit the final booking data here
            const data = {
                ...values,
                selectedDate,
                selectedRoom,
                selectedTrainer,
            };
            console.log("Submitting booking data", data);
            // Call the API to save the training schedule
            // await createTrainingBooking(data);
            toast.success("Training booked successfully");
        } catch (error) {
            toast.error("Error in booking the training.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="w-full max-w-2xl space-y-8">
            {/* Step 1: Show Training Request Details */}
            {currentStep === 0 && (
                <div>
                    <h3>Training Request Details</h3>
                    <div>
                        <p><strong>Course:</strong> {initialData?.course}</p>
                        <p><strong>Requester:</strong> {initialData?.requester_info?.username}</p>
                        <p><strong>Preferred Mode:</strong> {initialData?.preferred_mode}</p>
                        <p><strong>Employees:</strong></p>
                        <ul>
                            {initialData?.employee_info?.map((employee, index) => (
                                <li key={index}>{employee.username}</li>
                            ))}
                        </ul>
                        <p><strong>Additional Notes:</strong> {initialData?.additional_notes}</p>
                    </div>
                    <Button
                        disabled={loading}
                        onClick={() => setCurrentStep(1)} // Move to Step 2 (Date selection)
                    >
                        Next
                    </Button>
                </div>
            )}

            {/* Step 2: Select Date */}
            {currentStep === 1 && (
                <div>
                    <h3>Select Training Date</h3>
                    <DatePicker selectedDate={selectedDate} onChange={handleDateChange} />
                    <Button
                        disabled={loading || !selectedDate}
                        onClick={() => setCurrentStep(2)} // Move to Step 3 (Room selection)
                    >
                        Next
                    </Button>
                </div>
            )}

            {/* Step 3: Room Availability */}
            {currentStep === 2 && (
                <div>
                    <h3>Select Training Room</h3>
                    <Select
                        value={selectedRoom}
                        onChange={handleRoomChange}
                        disabled={loading || availableRooms.length === 0}
                    >
                        {availableRooms.length > 0 ? (
                            availableRooms.map((room) => (
                                <option key={room.id} value={room.id}>
                                    {room.name} - {room.capacity} seats
                                </option>
                            ))
                        ) : (
                            <option value="">No rooms available</option>
                        )}
                    </Select>
                    <Button
                        disabled={loading || !selectedRoom}
                        onClick={() => setCurrentStep(3)} // Move to Step 4 (Trainer selection)
                    >
                        Next
                    </Button>
                </div>
            )}

            {/* Step 4: Trainer Availability */}
            {currentStep === 3 && (
                <div>
                    <h3>Select Trainer</h3>
                    <Select
                        value={selectedTrainer}
                        onChange={handleTrainerChange}
                        disabled={loading || availableTrainers.length === 0}
                    >
                        {availableTrainers.length > 0 ? (
                            availableTrainers.map((trainer) => (
                                <option key={trainer.id} value={trainer.id}>
                                    {trainer.name}
                                </option>
                            ))
                        ) : (
                            <option value="">No trainers available</option>
                        )}
                    </Select>
                    <Button
                        disabled={loading || !selectedTrainer}
                        onClick={() => setCurrentStep(4)} // Move to Step 5 (Other details)
                    >
                        Next
                    </Button>
                </div>
            )}

            {/* Step 5: Other Details (Course, Notes, etc.) */}
            {currentStep === 4 && (
                <div>
                    <h3>Other Details</h3>
                    <form onSubmit={form.handleSubmit(handleSubmit)}>
                        <div>
                            <label>Course</label>
                            <Input
                                {...form.register("course")}
                                placeholder="Course title"
                                disabled={loading}
                            />
                        </div>
                        <div>
                            <label>Additional Notes</label>
                            <textarea
                                {...form.register("additionalNotes")}
                                placeholder="Additional notes (if any)"
                                disabled={loading}
                            />
                        </div>
                        <Button disabled={loading} type="submit">
                            Submit Booking
                        </Button>
                    </form>
                </div>
            )}
        </div>
    );
};

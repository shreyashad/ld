"use client";

import { useState } from "react";
import TraininRequestNavBar from "./training-request-navbar";
import { TrainingRequestList } from "./training-request-list";
import { RequestDetails } from "./training-request-details";

export default function TrainingRequestDashboardTA({ initialRequests }) {
    const [activeView, setActiveView] = useState("inbox")
    const [selectedRequest, setSelectedRequest] = useState(null);
    const [requests, setRequests] = useState(initialRequests)

    const handleRequestSubmit = (newRequest) => {
        setRequests([newRequest, ...requests])
        setActiveView("inbox")
      }
    
    const handleScheduleTraining = (requestId) => {
    setRequests(requests.map(req => 
        req.id === requestId ? { ...req, status: "Scheduled" } : req
    ))
    }
    return(
        <div className="flex h-screen bg-background">
            <TraininRequestNavBar activeView={activeView} setActiveView={setActiveView} />
            <div className="flex-1 flex">
                <div className="w-1/3 border-r p-4 overflow-auto">
                    <h2 className="text-xl font-semibold mb-4">
                    {activeView === "inbox" ? "Incoming Requests" :
                        activeView === "sent" ? "Sent Requests" :
                        activeView === "scheduled" ? "Scheduled Trainings" :
                        activeView === "trainers" ? "Available Trainers" : ""}
                    </h2>
                    {requests.length === 0 ? (
                        <div className="text-center text-muted-foreground">
                        No requests available. You can create a new request or check back later.
                    </div>
                    ): (
                        <TrainingRequestList requests={requests} setSelectedRequest={setSelectedRequest} selectedRequest={selectedRequest} />
                    )}
                </div>

               
                <div className="flex-1 p-4 overflow-auto">
                    {activeView === "compose" ? (
                        <NewRequestForm onSubmit={handleRequestSubmit} />
                    ) : selectedRequest ? (
                        <RequestDetails request={selectedRequest} onScheduleTraining={handleScheduleTraining} />
                    ): (
                        <div className="text-center text-muted-foreground">
                          Select a request to view details
                        </div>
                      )}
                </div>
            </div>
        </div>
    )
};
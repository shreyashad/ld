"use client";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";


const TrainingRoomClient = () => {
   const router = useRouter();
   return (
        <>
            
                <Button
                    onClick={() => {
                        router.push("/dashboard/trainers-admin/training-management/training-rooms/new")
                    }}
                >Create New Training Room</Button>
             
        </>

    );
};

export default TrainingRoomClient;
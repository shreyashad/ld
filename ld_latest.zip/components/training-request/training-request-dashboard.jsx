"use client";

import { useState } from "react";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "../ui/resizable";
import { TooltipProvider } from "../ui/tooltip";
import { cn } from "@/lib/utils";
import { Separator } from "../ui/separator";
import { Inbox, Search } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Input } from "../ui/input";
import { Dialog, DialogTrigger, DialogContent } from "../ui/dialog";
import { TrainingRequestFormHod } from "./training-request-form";
import { Button } from "../ui/button";
import { TrainingRequestList } from "./training-request-list";

export function TrainingRequestDashboard({
    defaultLayout = [20, 32, 48],
    defaultCollapsed = false,
    navCollapsedSize,
    mails,
    courses,
    recivers_name,
    teams,
}) {
    const [isCollapsed, setIsCollapsed] = useState(defaultCollapsed);
    const [isFormVisible, setIsFormVisible] = useState(false);

    // Safeguard: Ensure mails is an empty array if it is null or undefined
    const safeMails = mails || [];

    return (
        <div>
            <div className="container mx-auto p-4">
                <TooltipProvider delayDuration={0}>
                    <ResizablePanelGroup
                        direction="horizontal"
                        onLayout={(sizes) => {
                            document.cookie = `react-resizable-panels:layout:mail=${JSON.stringify(sizes)}`;
                        }}
                        className="h-full max-h-[800px] items-stretch"
                    >
                        <ResizablePanel
                            defaultSize={defaultLayout[0]}
                            collapsedSize={navCollapsedSize}
                            collapsible={true}
                            minSize={35}
                            maxSize={38}
                            onCollapse={() => {
                                setIsCollapsed(true);
                                document.cookie = `react-resizable-panels:collapsed=${JSON.stringify(true)}`;
                            }}
                            onResize={() => {
                                setIsCollapsed(false);
                                document.cookie = `react-resizable-panels:collapsed=${JSON.stringify(false)}`;
                            }}
                            className={cn(
                                isCollapsed && "min-w-[50px] transition-all duration-300 ease-in-out"
                            )}
                        >
                            <div className="flex flex-col h-full">
                                <div className="flex items-center justify-between px-2">
                                    <h1 className="text-xl font-bold">Inbox</h1>
                                    <Dialog>
                                        <DialogTrigger asChild>
                                            <Button variant="outline">Create New</Button>
                                        </DialogTrigger>
                                        <DialogContent className="sm:max-w-[425px]">
                                            <TrainingRequestFormHod courseslist={courses} receiverData={recivers_name} teamsData={teams} />
                                        </DialogContent>
                                    </Dialog>
                                </div>
                                <Separator className="my-2" />
                                <Tabs defaultValue="all">
                                    <TabsList className="flex">
                                        <TabsTrigger value="all" className="text-zinc-600 dark:text-zinc-200">All Requests</TabsTrigger>
                                        <TabsTrigger value="unread" className="text-zinc-600 dark:text-zinc-200">Unread</TabsTrigger>
                                    </TabsList>
                                    <Separator />
                                    <div className="bg-background/95 p-4 backdrop-blur supports-[backdrop-filter]:bg-background/60">
                                        <form>
                                            <div className="relative">
                                                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                                                <Input placeholder="Search" className="pl-8" />
                                            </div>
                                        </form>
                                    </div>
                                    <TabsContent value="all" className="m-0">
                                        <TrainingRequestList items={safeMails} />
                                    </TabsContent>
                                    <TabsContent value="unread" className="m-0">
                                        <TrainingRequestList items={safeMails.filter((item) => !item.read)} />
                                    </TabsContent>
                                </Tabs>
                            </div>
                        </ResizablePanel>
                        <ResizableHandle withHandle />
                        <ResizablePanel defaultSize={defaultLayout[1]} minSize={30}>
                            <TrainingRequestList items={safeMails.filter((item) => !item.read)} />
                        </ResizablePanel>
                    </ResizablePanelGroup>
                </TooltipProvider>
            </div>
        </div>
    );
}

"use client";

import { useSession } from "next-auth/react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { TrainingRequestSchema } from "@/schema"; // Ensure this schema is correctly defined
import { createTrainingRequest } from "@/app/api/server/route"; // Ensure this function is correctly implemented in your API
import { Label } from "../ui/label";
import { Popover, PopoverTrigger, PopoverContent } from "../ui/popover";
import { Button } from "../ui/button";
import { Check, ChevronsUpDown } from "lucide-react";
import { Command, CommandInput, CommandEmpty, CommandItem, CommandList, CommandGroup } from "../ui/command";
import { useState } from "react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Textarea } from "../ui/textarea";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";

export const TrainingRequestFormHod = ({ courseslist, receiverData, teamsData, setRequests }) => {
    const { data: session } = useSession();
    const router = useRouter();

    const form = useForm({
        resolver: zodResolver(TrainingRequestSchema),
        defaultValues: {
            course: "",
            requester: session?.user.user_id,
            receiver: "",
            mode: "",
            team_id: "",
            additional_notes: "",
            status: "pending",
        },
    });

    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const [selectedReceiver, setSelectedReceiver] = useState("");

    const handleOnSubmit = async (values) => {
        setLoading(true);
        try {
                await createTrainingRequest(session.accessToken, values);
                router.refresh();
            } catch (error) {
                console.error("Error submitting training request:", error.response ? error.response.data : error.message);
                toast.error(error.message || "An error occurred. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    if (!session) {
        return <div>Loading...</div>; // Handle loading or error state
    }

    return (
        <Card className="w-full max-w-2xl">
            <CardHeader>
                <CardTitle>Training Request</CardTitle>
                <CardDescription>Fill out the form below to request a training session</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
                <Form {...form}>
                    <form className="grid gap-4" onSubmit={form.handleSubmit(handleOnSubmit)}>
                        <div className="space-y-6">
                            <Label>To:</Label>
                            <Popover open={open} onOpenChange={setOpen}>
                                <PopoverTrigger asChild>
                                    <Button
                                        variant="outline"
                                        role="combobox"
                                        aria-expanded={open}
                                        className="w-[200px] justify-between"
                                    >
                                        {selectedReceiver || "Select receiver..."}
                                        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-[200px] p-0">
                                    <Command>
                                        <CommandInput placeholder="Search receiver..." />
                                        <CommandList>
                                            <CommandEmpty>No receiver found.</CommandEmpty>
                                            <CommandGroup>
                                                {receiverData?.map((receiver) => (
                                                    <CommandItem
                                                        key={receiver.username}
                                                        onSelect={() => {
                                                            setSelectedReceiver(receiver.username);
                                                            form.setValue('receiver_id', receiver.username); // Set receiver_id
                                                            setOpen(false);
                                                        }}
                                                    >
                                                        <Check
                                                            className={`mr-2 h-4 w-4 ${selectedReceiver === receiver.username ? "opacity-100" : "opacity-0"}`}
                                                        />
                                                        {receiver.username}
                                                    </CommandItem>
                                                ))}
                                            </CommandGroup>
                                        </CommandList>
                                    </Command>
                                </PopoverContent>
                            </Popover>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <FormField
                                    control={form.control}
                                    name="course"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Course Topic</FormLabel>
                                            <Select
                                                disabled={loading || !courseslist?.length}
                                                onValueChange={field.onChange}
                                                value={field.value}
                                            >
                                                <FormControl>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder={courseslist?.length > 0 ? "Course Topic" : "No Courses available"} />
                                                    </SelectTrigger>
                                                </FormControl>
                                                <SelectContent>
                                                    {courseslist?.length > 0 ? (
                                                        courseslist.map((course) => (
                                                            <SelectItem key={course.id} value={course.title}>
                                                                {course.title}
                                                            </SelectItem>
                                                        ))
                                                    ) : (
                                                        <SelectItem disabled>No Topic found</SelectItem>
                                                    )}
                                                </SelectContent>
                                            </Select>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>
                            <div className="space-y-2">
                                <FormField
                                    control={form.control}
                                    name="mode"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Training Mode</FormLabel>
                                            <Select
                                                disabled={loading}
                                                onValueChange={field.onChange}
                                                value={field.value}
                                            >
                                                <FormControl>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Training Mode" />
                                                    </SelectTrigger>
                                                </FormControl>
                                                <SelectContent>
                                                    <SelectItem value="online">Online</SelectItem>
                                                    <SelectItem value="offline">Offline</SelectItem>
                                                    <SelectItem value="self-learning">Self-learning</SelectItem>
                                                </SelectContent>
                                            </Select>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>
                        </div>
                        <FormField
                            control={form.control}
                            name="team_id"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Team</FormLabel>
                                    <Select
                                        disabled={loading || !teamsData?.length}
                                        onValueChange={field.onChange}
                                        value={field.value}
                                    >
                                        <FormControl>
                                            <SelectTrigger>
                                                <SelectValue placeholder={teamsData?.length > 0 ? "Team" : "No Team available"} />
                                            </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            {teamsData?.length > 0 ? (
                                                teamsData.map((team) => (
                                                    <SelectItem key={team.id} value={team.id}>
                                                        {team.name}
                                                    </SelectItem>
                                                ))
                                            ) : (
                                                <SelectItem disabled>No Teams found</SelectItem>
                                            )}
                                        </SelectContent>
                                    </Select>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name="additional_notes"
                            render={({ field }) => (
                                <FormItem>
                                    <FormLabel>Additional Notes</FormLabel>
                                    <FormControl>
                                        <Textarea
                                            {...field}
                                            placeholder="Additional Notes"
                                            disabled={loading}
                                        />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )}
                        />
                        <div className="space-x-4">
                            <Button disabled={loading} className="ml-auto" type="submit">
                                {loading ? 'Submitting...' : 'Submit Request'}
                            </Button>
                            <Button
                                disabled={loading}
                                className="ml-auto"
                                type="button"
                                onClick={() => router.back()}
                            >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </Form>
            </CardContent>
        </Card>
    );
};

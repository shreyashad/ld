// components/ui/Modal.jsx
import { cn } from "@/lib/utils"; // Utility for conditional class names
import { Dialog, DialogOverlay, } from "../ui/dialog";

export const FormModal = ({ isOpen, onClose, children }) => {
    return (
        <Dialog open={isOpen} onClose={onClose} className="relative z-50">
            <DialogOverlay className="fixed inset-0 bg-black bg-opacity-50" />
            <div className="fixed inset-0 flex items-center justify-center p-4">
                <DialogPanel className="bg-white rounded shadow-lg p-6 max-w-lg w-full">
                    <button
                        onClick={onClose}
                        className="absolute top-4 right-4 text-gray-600 hover:text-gray-900"
                    >
                        &times; {/* Close button */}
                    </button>
                    {children}
                </DialogPanel>
            </div>
        </Dialog>
    );
};

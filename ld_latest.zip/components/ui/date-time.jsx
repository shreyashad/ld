import { cn } from "@/lib/utils";
import { useEffect, useRef, useState } from "react";
import { Button } from "./button";
import { CalendarIcon, ClockIcon } from "lucide-react";

// Create a DateTimePicker component without TypeScript typings
const DateTimePicker = ({ value, onChange, className, ...props }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [time, setTime] = useState(value ? new Date(value) : new Date());
  const inputRef = useRef(null);

  useEffect(() => {
    if (value) {
      setTime(new Date(value));
    }
  }, [value]);

  const toggleOpen = () => setIsOpen((prev) => !prev);

  const handleDateChange = (date) => {
    setTime(date);
    if (onChange) {
      onChange(date);
    }
  };

  const handleTimeChange = (event) => {
    const newTime = new Date(time);
    const hours = event.target.value.split(':')[0];
    const minutes = event.target.value.split(':')[1];
    newTime.setHours(hours);
    newTime.setMinutes(minutes);
    setTime(newTime);
    if (onChange) {
      onChange(newTime);
    }
  };

  const formatDate = (date) => {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  };

  const formatTime = (date) => {
    return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  };

  return (
    <div className={cn('relative', className)} {...props}>
      <Button onClick={toggleOpen} className="w-full text-left">
        <span>{formatDate(time)} {formatTime(time)}</span>
        <span className="ml-2">
          {isOpen ? <CalendarIcon /> : <ClockIcon />}
        </span>
      </Button>
      {isOpen && (
        <div className="absolute z-10 mt-2">
          <DatePicker
            selected={time}
            onChange={handleDateChange}
            className="mb-2"
          />
          <input
            ref={inputRef}
            type="time"
            value={formatTime(time)}
            onChange={handleTimeChange}
            className="border p-2 rounded"
          />
        </div>
      )}
    </div>
  );
};

export default DateTimePicker;

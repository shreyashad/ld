import { getToken } from "next-auth/jwt";
import { NextResponse } from "next/server";

export async function middleware(req) {
  const token = await getToken({ req, secret: process.env.AUTH_SECRET});


  if (!token) {
    return NextResponse.redirect(new URL("/login", req.url ));

  }

  const userRole = token.user.roles[0];
  const { pathname } = req.nextUrl;

  if (pathname.startsWith("dashboard/trainers-admin") && userRole !== "Trainers Admin") {
    return NextResponse.redirect(new URL("/login", req.url));
  }
  if (pathname.startsWith("dashboard/trainer") && userRole !== "Trainer") {
    return NextResponse.redirect(new URL("/login", req.url));
  }
  if (pathname.startsWith("dashboard/hod") && userRole !== "HOD's") {
    return NextResponse.redirect(new URL("/login", req.url));
  }
  if (pathname.startsWith("dashboard/employee") && userRole !== "Employee") {
    return NextResponse.redirect(new URL("/login", req.url));
  }


  return NextResponse.next();
}

export const config = {
  matcher: ["/dashboard/:path*"],
};


import { z } from "zod";

const DifficultyLevelEnum = z.enum([
    'Beginner',
    'Intermediate',
    'Advanced',
    'Expert',
    'Foundation',
    'Specialization',
    'Certification/Professional',
]);
    

const StatusChoiceEnum = z.enum([
    'InActive',
    'Published',
]);

const MAX_FILE_SIZE = 5000000;
const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];

export const CourseCategorySchema = z.object({
    name: z.string()
        .min(5, { message: "Name is required" })
        .max(100, { message: "Maximum of 100 characters is allowed" }),
    image: z
        .instanceof(File)
        .refine(file => file.size <= MAX_FILE_SIZE, "Max file size is 5MB.")
        .refine(file => ACCEPTED_IMAGE_TYPES.includes(file.type), ".jpg, .jpeg, .png and .webp files are accepted.")
        .optional(), // Make optional for better user experience
    description: z.string().optional(),
    category_status: z.enum(["Published", "Inactive"]) // Adjust this based on your actual enum values
});


export const VideoSchema = z.object({
    title: z.string().min(1, "Video title is required"),
    video_url: z.any().refine((file) => file instanceof File, {
        message: "Invalid video file",
    }),
    cover_image: z.any().optional().refine((file) => file instanceof File, {
        message: "Invalid cover image file",
    }),
    description: z.string().optional(),
    duration: z.string().regex(/^\d+:\d+:\d+$/, "Invalid duration format"), // HH:MM:SS
    order: z.number().nonnegative().optional(),
    status: z.enum(StatusChoiceEnum),
});

export const ModuleSchema = z.object({
    title: z.string().min(1, "Module title is required"),
    description: z.string().min(1, "Description is required"),
    cover_image: z.any().optional().refine((file) => file instanceof File, {
        message: "Invalid cover image file",
    }),
    order: z.number().nonnegative().optional(),
    status: z.enum(StatusChoiceEnum),
    videos: z.array(VideoSchema).optional(),
});

export const CourseSchema = z.object({
    title: z.string().min(1, "Course title is required"),
    description: z.string().min(1, "Description is required"),
    category: z.string().min(1, "Category is required"),
    cover_image: z.any().optional().refine((file) => file instanceof File, {
        message: "Invalid cover image file",
    }),
    duration: z.string().regex(/^\d+:\d+:\d+$/, "Invalid duration format"), // HH:MM:SS
    difficulty_level: z.string().min(1, "Difficulty level is required"),
    prerequisites: z.array(z.string()).optional(), // Array of course IDs
    certification: z.string().optional(),
    learning_objectives: z.string().optional(),
    status: z.enum(StatusChoiceEnum),
    modules: z.array(ModuleSchema).optional(),
});

// For Material Schema
export const MaterialSchema = z.object({
    title: z.string().min(1, "Material title is required"),
    file: z.any().refine((file) => file instanceof File, {
        message: "Invalid file format",
    }),
    description: z.string().optional(),
    status: z.enum(StatusChoiceEnum),
});



export const TrainingRequestSchema = z.object({
    course: z.string().min(1, "Course topic is required"), // Ensure it's not empty
    receiver: z.string().min(1, "Receiver is required"), // Ensure the receiver is selected
    preferred_mode: z.enum(["online", "offline", "self-learning"], {
        errorMap: () => ({ message: "Invalid training mode" }),
    }),
    employees: z.array(z.string().min(1, "Employee ID is required")).nonempty("At least one employee is required"),
    additional_notes: z.string().optional(),
    status: z.enum(["pending", "approved", "rejected"]).default("pending"),
}); 



export const TrainingRoomsSchema = z.object({
    name : z.string(),
    capacity: z.coerce.number().min(1, "Capacity must be a positive number"),
    
});



export const TrainingRoomAvailabilitySchema = z.object({
    room: z.string().min(1, "Room name is required"), // Room name or ID
    date: z.string().refine((val) => !isNaN(Date.parse(val)), {
      message: "Invalid date format",
    }),
    isAvailable: z.boolean(), // Boolean to check if the room is available
    description: z.string().optional(), // Optional description
  });




// Schema for Trainer Availability
export const TrainerAvailabilitySchema = z.object({
    trainer: z.string().min(1, "Trainer name is required"), // Trainer name or ID
    scheduledDate: z.string().refine((val) => !isNaN(Date.parse(val)), {
      message: "Invalid date format",
    }), // Ensure it's a valid date
    isAvailable: z.boolean(), // Boolean to check if the trainer is available
  });
  








export const AnnouncementCategorySchema = z.object({
    name: z.string().min(5, {
        message: "name is required",
    })
    .max(100, {
        message: "Maximum of 100 characters is allowed"
    }),
    description: z.string().optional(),
    
});

export const AnnouncementSchema = z.object({
    title: z.string().min(5, {
        message: "Title is required",
    })
    .max(100, {
        message: "Maximum of 100 characters is allowed"
    }),
    content:z.string().min(5, {
        message: "name is required",
    })
    .max(1000, {
        message: "Maximum of 100 characters is allowed"
    }),
    category:z.string().min(5, {
        message: "name is required",
    })
    .max(100, {
        message: "Maximum of 100 characters is allowed"
    }),
    expiration_date:z.date(),
    is_active:z.boolean(),
});






export const TodaysWisdomSchema = z.object({
    topic: z.string().min(5, {
        message: "please mention the topic",
    })
    
});


export const CourseLevelSchema = z.object({
    name: z.string(),
});


// for Exam management system

// Fetch question types dynamically from the backend (e.g., ['MultipleChoice', 'TrueFalse', 'FillInTheBlanks'])
const questionTypes = ["MultipleChoice", "TrueFalse", "FillInTheBlanks", "Ordering", "ShortAnswer"];

// Validate the correct format of duration (HH:MM:SS)
const durationSchema = z.string().regex(/^([0-9]{1,2}):([0-5][0-9]):([0-5][0-9])$/, "Duration must be in HH:MM:SS format");

// Question Type Schema (you can extend this to be dynamic based on the database)
const QuestionTypeSchema = z.enum(questionTypes, "Invalid question type");


const MultipleChoiceOptionSchema = z.object({
    text: z.string().min(1, "Option text cannot be empty"),
    isCorrect: z.boolean(),
  });


// Question Schema
const QuestionSchema = z.object({
    question_text: z.string().min(1, "Question text is required"), // The text of the question
    question_type: QuestionTypeSchema, // Type of question (e.g., MultipleChoice, TrueFalse, etc.)
    marks: z.number().positive("Marks must be a positive number"), // Marks for this question
    options: z
      .array(MultipleChoiceOptionSchema)
      .min(2, "Multiple choice questions must have at least two options")
      .optional(), // Options for MultipleChoice questions (optional for others)
    correct_answer: z
      .string()
      .min(1, "Correct answer is required") 
      .optional(), // Correct answer (required for FillInTheBlanks, TrueFalse, etc.)
  });




export const ExaminationSchema = z.object({
    title: z.string()
        .min(1, "Title is required")
        .max(250, "Title can't be longer than 250 characters"),
    course: z.string()
        .uuid("Invalid course ID format")
        .nonempty("Course ID is required"),
    duration: durationSchema,
    total_marks: z
        .number()
        .optional(),
    pass_marks: z
        .number(),
    questions: z
        .array()
        .min(1, "Examination must have at least one question"),

});


export const QueTypeSchema = z.object({
    name: z.string().min(5, {
        message: "name is required",
    }),
    description: z.string().optional()
});


// for teams related schema

export const TeamsSchema = z.object({
    name: z.string()
        .min(1, "Team name is required")
        .max(255, "Team name cannot exceed 255 characters")
        .trim(),
    description: z.string()
        .max(1000, "Description cannot exceed 1000 characters")
        .optional(),
    users: z.array(
        z.object({
            // User field validation: Ensure user ID is a string and not empty
            user: z.string().min(1, "User is required"),
    
            // Role field validation: Only allow 'Leader' or 'Member'
            role: z.enum(["Leader", "Member"], "Role is required"),
        })
        ).min(1, "At least one user is required"),
});
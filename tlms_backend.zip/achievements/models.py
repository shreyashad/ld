import random
import string
from django.db import models
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from accounts.models import BaseModel

from course.utils import StatusChoice
from django.core.exceptions import ValidationError

# Create your models here.

class Badge(BaseModel):
    title = models.CharField(max_length=255)
    description = models.TextField()
    image = models.ImageField(upload_to='badge_images/', blank=True, null=True)
    criteria_type = models.CharField(max_length=50, choices=[
        ('module_completion', 'Module Completion'),
        ('course_completion', 'Course Completion'),
        ('assignment_completion', 'Assignment Completion'),
        ('discussion_participation', 'Discussion Participation'),

    ])
    criteria_value = models.JSONField(default=dict)
    status = models.CharField(max_length=50, choices=StatusChoice)

    class Meta:
        verbose_name = "Badge"
        verbose_name_plural = "Badges"
        ordering = ['title']


    def __str__(self):
        return self.title


class UserBadge(models.Model):
    user = models.CharField(max_length=250)
    badge = models.ForeignKey(Badge, on_delete=models.CASCADE)
    earned_at = models.DateTimeField(auto_now_add=True)
    criteria_details = models.JSONField(default=dict)

    def __str__(self):
        return f"{self.user.username} - {self.badge.name}"



def generate_certificate_code():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))


def validate_certificate_template(value):
    if not value.name.endswith('.pdf'):
        raise ValidationError("Template file must be a PDF.")


class CertificateType(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    template_file = models.FileField(upload_to='certificate_templates/', validators=[validate_certificate_template])  # Store the template file
    background_image = models.ImageField(upload_to='certificate_backgrounds/', blank=True, null=True)

    def __str__(self):
        return self.title


class Certificate(BaseModel):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    certificate_type = models.ForeignKey(CertificateType, on_delete=models.CASCADE)
    issue_date = models.DateTimeField(auto_now_add=True)
    certificate_code = models.CharField(max_length=255, unique=True, default=generate_certificate_code)
    criteria_value = models.JSONField(default=dict)  # Store specific criteria for issuing the certificate
    is_generated = models.BooleanField(default=False)  # To track if the certificate has been generated

    # Generic relation to allow linking the certificate to any model (Course, Module, Badge, etc.)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')

    class Meta:
        unique_together = ('user', 'certificate_type', 'content_type', 'object_id')  # Ensures a user can only have one certificate of a type per course

    def __str__(self):
        return f"{self.user.username} - {self.course.title} Certificate"
from django.urls import path
from.views import *

urlpatterns = [

    # for organization related
    path('badge-list/', BadgeListCreateAPIView.as_view(), name='badge'),
    path('badge/<uuid:pk>/details/', BadgeRetrieveUpdateDestroyAPIView.as_view(), name='badge'),
    path('badge-list/', BadgeListCreateAPIView.as_view(), name='badge'),
    path('badge-list/', BadgeListCreateAPIView.as_view(), name='badge'),
]
# badges/utils.py
from .models import UserBadge

def award_badge(user, badge, context):
    if badge.criteria_type == 'module_completion':
        if context['module_id'] == badge.criteria_value['module_id']:
            UserBadge.objects.get_or_create(user=user, badge=badge)

    elif badge.criteria_type == 'course_completion':
        if context['course_id'] == badge.criteria_value['course_id']:
            UserBadge.objects.get_or_create(user=user, badge=badge)

    elif badge.criteria_type == 'assignment_completion':
        if context['assignment_id'] in badge.criteria_value['assignment_ids']:
            UserBadge.objects.get_or_create(user=user, badge=badge)

    elif badge.criteria_type == 'discussion_participation':
        if context['discussion_id'] == badge.criteria_value['discussion_id'] and \
           context['contributions'] >= badge.criteria_value['min_contributions']:
            UserBadge.objects.get_or_create(user=user, badge=badge)

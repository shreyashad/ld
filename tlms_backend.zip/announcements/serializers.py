from rest_framework import serializers
from .models import *

class AnnouncementCategorySerializers(serializers.ModelSerializer):
    class Meta:
        model = AnnouncementCategory
        fields = ['id', 'name', 'description', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']



class AnnouncementSerializers(serializers.ModelSerializer):
    class Meta:
        model = Announcement
        fields = ['id', 'title', 'content','category','published_date','expiration_date','is_active' 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


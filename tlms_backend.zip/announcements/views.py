from django.shortcuts import render
from rest_framework import generics, status
from .serializers import *
from rest_framework.permissions import IsAuthenticated
from accounts.authentication import CustomCASAuthentication


# Create your views here.

class AnnouncementCategoryListAPIView(generics.ListAPIView):
    queryset = AnnouncementCategory.objects.all()
    serializer_class = AnnouncementCategorySerializers
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class AnnouncementCategoryCreateAPIView(generics.CreateAPIView):
    queryset = AnnouncementCategory.objects.all()
    serializer_class = AnnouncementCategorySerializers
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class AnnouncementCategoryRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = AnnouncementCategory.objects.all()
    serializer_class = AnnouncementCategorySerializers
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


class AnnouncementListAPIView(generics.ListAPIView):
    queryset = Announcement.objects.all()
    serializer_class = AnnouncementSerializers
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

class AnnouncementCreateAPIView(generics.CreateAPIView):
    queryset = Announcement.objects.all()
    serializer_class = AnnouncementSerializers
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class AnnouncementRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Announcement.objects.all()
    serializer_class = AnnouncementSerializers
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)

Given that only the **Trainer Admin** is responsible for assigning trainers, we can streamline the models by removing any assignment logic from the **HOD**. Here’s how the models can be adjusted to reflect this distinction:

### Updated Model Design

1. **TrainingSession Model**
   - This model will handle both requested and directly scheduled training sessions.
   - A `requested_by` field indicates if the session was requested by an **HOD**. If `requested_by` is empty, the session was created directly by the **Trainer Admin**.

   ```python
   class TrainingSession(models.Model):
       course = models.ForeignKey("Course", on_delete=models.CASCADE)
       team_members = models.ManyToManyField(
           settings.AUTH_USER_MODEL, related_name="training_sessions",
           help_text="Participants for this training session"
       )
       created_by = models.ForeignKey(
           settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
           related_name="created_trainings",
           help_text="User who created or initiated the training session (Trainer Admin or HOD)"
       )
       requested_by = models.ForeignKey(
           settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
           null=True, blank=True,
           related_name="training_requests",
           help_text="User who requested the training (HOD); null if direct session by Trainer Admin"
       )
       preferred_mode = models.CharField(
           max_length=20,
           choices=[('online', 'Online'), ('offline', 'Offline'), ('self_learning', 'Self Learning')],
           help_text="Mode of training"
       )
       scheduled_date = models.DateField(null=True, blank=True, help_text="Date for scheduled training")
       start_time = models.TimeField(null=True, blank=True)
       end_time = models.TimeField(null=True, blank=True)
       location = models.ForeignKey(
           "Location", on_delete=models.SET_NULL, null=True, blank=True,
           help_text="Room or online platform details if offline or online"
       )
       status = models.CharField(
           max_length=20,
           choices=[('draft', 'Draft'), ('approved', 'Approved'), ('scheduled', 'Scheduled'), ('completed', 'Completed')],
           default='draft'
       )
       created_at = models.DateTimeField(auto_now_add=True)
       updated_at = models.DateTimeField(auto_now=True)

       def __str__(self):
           return f"{self.course.title} - {self.get_preferred_mode_display()} ({self.status})"
   ```

2. **TrainerAssignment Model**
   - Only the **Trainer Admin** will use this model to assign trainers to a specific **TrainingSession**.
   - This model does not need any **HOD**-related fields or logic.

   ```python
   class TrainerAssignment(models.Model):
       training_session = models.ForeignKey(
           TrainingSession, on_delete=models.CASCADE, related_name="trainer_assignments",
           help_text="The training session for which the trainer is assigned"
       )
       trainer = models.ForeignKey(
           settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
           null=True, blank=True,
           limit_choices_to={'is_trainer': True},
           help_text="Trainer assigned to this session"
       )
       is_confirmed = models.BooleanField(default=False, help_text="Confirmation status of trainer")

       def __str__(self):
           return f"{self.trainer.username} for {self.training_session.course.title}"
   ```

3. **Location Model**
   - This model remains the same, used to manage location availability for **offline** sessions.

   ```python
   class Location(models.Model):
       name = models.CharField(max_length=255)
       capacity = models.PositiveIntegerField()
       is_available = models.BooleanField(default=True)
       location_type = models.CharField(
           max_length=20, choices=[('room', 'Room'), ('lab', 'Lab'), ('hall', 'Hall')]
       )
       description = models.TextField(blank=True, null=True)

       def __str__(self):
           return self.name
   ```

4. **Attendance Model**
   - Tracks attendance per **TrainingSession**.

   ```python
   class Attendance(models.Model):
       training_session = models.ForeignKey(
           TrainingSession, on_delete=models.CASCADE, related_name="attendances",
           help_text="The training session for which attendance is taken"
       )
       participant = models.ForeignKey(
           settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
           help_text="Participant attending the training"
       )
       is_present = models.BooleanField(default=False)
       attendance_date = models.DateField(auto_now_add=True)

       def __str__(self):
           return f"{self.participant.username} attendance for {self.training_session.course.title}"
   ```

5. **Feedback Model**
   - Collects feedback for each **TrainingSession**.

   ```python
   class Feedback(models.Model):
       training_session = models.ForeignKey(
           TrainingSession, on_delete=models.CASCADE, related_name="feedbacks",
           help_text="The training session for which feedback is provided"
       )
       participant = models.ForeignKey(
           settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
           help_text="Participant providing feedback"
       )
       rating = models.PositiveSmallIntegerField(help_text="Rating out of 5")
       comments = models.TextField(blank=True, null=True)
       created_at = models.DateTimeField(auto_now_add=True)

       def __str__(self):
           return f"Feedback by {self.participant.username} for {self.training_session.course.title}"
   ```

### Workflow

1. **Direct Scheduling by Trainer Admin**:
   - The **Trainer Admin** creates a `TrainingSession` directly, without setting the `requested_by` field. They use `TrainerAssignment` to assign trainers.

2. **HOD Training Requests**:
   - If the **HOD** initiates a training request, they create a `TrainingSession` with themselves as the `requested_by` user.
   - The **Trainer Admin** reviews this and schedules the session accordingly, updating the `status` field as needed.

3. **Assignment and Attendance**:
   - Trainers are assigned only by the **Trainer Admin** using the **TrainerAssignment** model.
   - Attendance and feedback are managed as usual.

This structure keeps the **Trainer Admin** exclusively responsible for assigning trainers while providing a dynamic setup for both requested and direct sessions.
------------------------------------
To cover these two cases where **HOD**-initiated requests differ from **Trainer Admin**-directly scheduled sessions, we’ll design a model structure that allows flexibility for both types of training scheduling processes. The models below capture both workflows, ensuring only the **Trainer Admin** schedules training, assigns trainers, and confirms logistical details.

### Updated Model Structure for Training Management

1. **TrainingRequest Model**
   - This model tracks training requests initiated by the **HOD**. If the **Trainer Admin** directly schedules the training without a request, this model won’t be used.
   - The **Trainer Admin** can approve or deny requests and then schedule the training accordingly.

   ```python
   class TrainingRequest(models.Model):
       hod = models.ForeignKey(
           settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
           related_name="training_requests", limit_choices_to={'user_type': 'HOD'},
           help_text="HOD requesting the training"
       )
       team_members = models.ManyToManyField(
           settings.AUTH_USER_MODEL, related_name="requested_trainings",
           help_text="Participants requested for training"
       )
       course = models.ForeignKey("Course", on_delete=models.CASCADE)
       preferred_mode = models.CharField(
           max_length=20,
           choices=[('online', 'Online'), ('offline', 'Offline'), ('self_learning', 'Self Learning')],
           help_text="Requested training mode"
       )
       status = models.CharField(
           max_length=20,
           choices=[('pending', 'Pending'), ('approved', 'Approved'), ('denied', 'Denied')],
           default='pending'
       )
       created_at = models.DateTimeField(auto_now_add=True)

       def __str__(self):
           return f"Request by {self.hod.username} for {self.course.title}"
   ```

2. **TrainingSession Model**
   - This model covers both scheduled trainings initiated through **TrainingRequest** or directly by **Trainer Admin**.
   - A `training_request` field connects to **TrainingRequest** if the session originated from an **HOD** request, otherwise it remains empty for directly scheduled sessions.

   ```python
   class TrainingSession(models.Model):
       training_request = models.OneToOneField(
           TrainingRequest, on_delete=models.SET_NULL, null=True, blank=True,
           related_name="scheduled_session", help_text="Related request if initiated by HOD"
       )
       course = models.ForeignKey("Course", on_delete=models.CASCADE)
       team_members = models.ManyToManyField(
           settings.AUTH_USER_MODEL, related_name="training_sessions",
           help_text="Participants for this training session"
       )
       created_by = models.ForeignKey(
           settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
           related_name="created_trainings",
           help_text="User who scheduled the training (Trainer Admin)"
       )
       mode = models.CharField(
           max_length=20,
           choices=[('online', 'Online'), ('offline', 'Offline'), ('self_learning', 'Self Learning')],
           help_text="Training mode"
       )
       scheduled_date = models.DateField(help_text="Scheduled training date")
       start_time = models.TimeField(null=True, blank=True)
       end_time = models.TimeField(null=True, blank=True)
       location = models.ForeignKey(
           "Location", on_delete=models.SET_NULL, null=True, blank=True,
           help_text="Room or online platform for offline or online mode"
       )
       status = models.CharField(
           max_length=20,
           choices=[('scheduled', 'Scheduled'), ('completed', 'Completed')],
           default='scheduled'
       )
       created_at = models.DateTimeField(auto_now_add=True)

       def __str__(self):
           return f"{self.course.title} - {self.get_mode_display()} ({self.status})"
   ```

3. **TrainerAssignment Model**
   - The **Trainer Admin** uses this model to assign a **Trainer** to the **TrainingSession**.
   - Only **Trainer Admin** schedules training and assigns trainers; this model reflects that.

   ```python
   class TrainerAssignment(models.Model):
       training_session = models.ForeignKey(
           TrainingSession, on_delete=models.CASCADE, related_name="trainer_assignments",
           help_text="Training session for which the trainer is assigned"
       )
       trainer = models.ForeignKey(
           settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
           null=True, blank=True, limit_choices_to={'user_type': 'Trainer'},
           help_text="Trainer assigned to this session"
       )
       is_confirmed = models.BooleanField(default=False, help_text="Confirmation status of trainer")

       def __str__(self):
           return f"{self.trainer.username} assigned to {self.training_session.course.title}"
   ```

4. **Location Model**
   - This model remains as it was, providing available locations for **offline** sessions.

   ```python
   class Location(models.Model):
       name = models.CharField(max_length=255)
       capacity = models.PositiveIntegerField()
       is_available = models.BooleanField(default=True)
       location_type = models.CharField(
           max_length=20, choices=[('room', 'Room'), ('lab', 'Lab'), ('hall', 'Hall')]
       )
       description = models.TextField(blank=True, null=True)

       def __str__(self):
           return self.name
   ```

5. **Attendance Model**
   - Tracks attendance for each **TrainingSession**.

   ```python
   class Attendance(models.Model):
       training_session = models.ForeignKey(
           TrainingSession, on_delete=models.CASCADE, related_name="attendances",
           help_text="Training session for which attendance is taken"
       )
       participant = models.ForeignKey(
           settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
           help_text="Participant attending the training"
       )
       is_present = models.BooleanField(default=False)
       attendance_date = models.DateField(auto_now_add=True)

       def __str__(self):
           return f"{self.participant.username} attendance for {self.training_session.course.title}"
   ```

### Workflow

- **Case 1: HOD Requested Training**
  1. **HOD** creates a `TrainingRequest`.
  2. **Trainer Admin** reviews the request, checks for availability, and if approved, creates a corresponding `TrainingSession` using the `TrainingRequest` information.
  3. **Trainer Admin** uses `TrainerAssignment` to assign a trainer to the session.
  4. On the scheduled date, the **Trainer** executes the training.

- **Case 2: Trainer Admin Scheduled Training**
  1. **Trainer Admin** directly creates a `TrainingSession`, bypassing `TrainingRequest`.
  2. **Trainer Admin** assigns trainers using `TrainerAssignment` and sets the session location and time.
  3. On the scheduled date, the **Trainer** executes the training.

This model structure allows the **Trainer Admin** to handle all scheduling and assignment responsibilities while supporting both HOD-initiated and direct scheduling.
----------------------
The
semi - offline
training
mode
requires
a
detailed
model
setup
to
handle
all
interactions
between ** Trainer ** and ** Employees ** during
a
session.The
steps
involve
tracking
training
progress, breaks, assignments, feedback, and finally marking
the
end
of
the
session.Here’s
a
model
structure
to
capture
all
of
these
interactions
effectively.

### Model Structure for Semi-Offline Training

1. ** TrainingSession
Model **
- This
model
stores
the
session
details, including
schedules and status
updates.
- The
start
time, end
time, and session
status
will
be
captured as the
session
progresses.

```python


class TrainingSession(models.Model):
    course = models.ForeignKey("Course", on_delete=models.CASCADE)
    team_members = models.ManyToManyField(
        settings.AUTH_USER_MODEL, related_name="training_sessions",
        help_text="Participants for this training session"
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="created_trainings", limit_choices_to={'user_type': 'Trainer Admin'},
        help_text="User who scheduled the training"
    )
    trainer = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, limit_choices_to={'user_type': 'Trainer'},
        help_text="Trainer for the session"
    )
    mode = models.CharField(
        max_length=20, choices=[('semi_offline', 'Semi-Offline')],
        default='semi_offline'
    )
    scheduled_date = models.DateField(help_text="Scheduled training date")
    start_time = models.DateTimeField(null=True, blank=True, help_text="Training start time")
    end_time = models.DateTimeField(null=True, blank=True, help_text="Training end time")
    status = models.CharField(
        max_length=20,
        choices=[('scheduled', 'Scheduled'), ('in_progress', 'In Progress'), ('completed', 'Completed')],
        default='scheduled'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.course.title} - {self.trainer.username} ({self.status})"


```

2. ** Attendance
Model **
- Tracks
attendance
of
each
participant,
with attendance allowed only within a specific window defined by the ** Trainer **.

```python


class Attendance(models.Model):
    training_session = models.ForeignKey(
        TrainingSession, on_delete=models.CASCADE, related_name="attendances"
    )
    participant = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        help_text="Employee attending the training"
    )
    is_present = models.BooleanField(default=False)
    marked_at = models.DateTimeField(null=True, blank=True, help_text="Timestamp for marking attendance")
    attendance_window_start = models.DateTimeField(null=True, blank=True)
    attendance_window_end = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.participant.username} attendance for {self.training_session.course.title}"


```

3. ** Break
Model **
- Allows
the ** Trainer ** to
log
breaks, capturing
both
start and end
times.

```python


class Break(models.Model):
    training_session = models.ForeignKey(
        TrainingSession, on_delete=models.CASCADE, related_name="breaks"
    )
    break_start = models.DateTimeField(help_text="Break start time")
    break_end = models.DateTimeField(null=True, blank=True, help_text="Break end time")

    def __str__(self):
        return f"Break for {self.training_session.course.title} ({self.break_start} - {self.break_end})"


```

4. ** Assignment
Model **
- Handles
assignment
creation and tracking,
with an MCQ-style test that employees complete within the session.
- Only
active
during
the ** Trainer ** -defined
window.

```python


class Assignment(models.Model):
    training_session = models.ForeignKey(
        TrainingSession, on_delete=models.CASCADE, related_name="assignments"
    )
    is_active = models.BooleanField(default=False, help_text="Assignment active status")
    start_time = models.DateTimeField(null=True, blank=True, help_text="Assignment start time")
    end_time = models.DateTimeField(null=True, blank=True, help_text="Assignment end time")

    def __str__(self):
        return f"Assignment for {self.training_session.course.title} ({self.is_active})"


```

5. ** AssignmentQuestion and AssignmentResponse
Models **
- Defines
questions
for the assignment(MCQs), and stores employee responses to those questions.

```python


class AssignmentQuestion(models.Model):
    assignment = models.ForeignKey(Assignment, on_delete=models.CASCADE, related_name="questions")
    question_text = models.TextField()
    options = models.JSONField(help_text="Options in JSON format (e.g., {'A': 'Option 1', 'B': 'Option 2'})")
    correct_answer = models.CharField(max_length=10)

    def __str__(self):
        return f"Question for {self.assignment.training_session.course.title}"


class AssignmentResponse(models.Model):
    question = models.ForeignKey(AssignmentQuestion, on_delete=models.CASCADE)
    participant = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    selected_option = models.CharField(max_length=10)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.participant.username}'s response to {self.question.question_text}"


```

6. ** Feedback
Models **
- There
are
three
types
of
feedback
forms:
- ** Training
Feedback **
for employees on the training session,
- ** Trainer
Feedback **
for employees rating the trainer,
- ** Employee
Feedback **
for the ** Trainer ** to provide insights on participants.

```python


class TrainingFeedback(models.Model):
    training_session = models.ForeignKey(
        TrainingSession, on_delete=models.CASCADE, related_name="training_feedback"
    )
    participant = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        help_text="Employee giving feedback on the training"
    )
    feedback_text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Training feedback by {self.participant.username}"


class TrainerFeedback(models.Model):
    training_session = models.ForeignKey(
        TrainingSession, on_delete=models.CASCADE, related_name="trainer_feedback"
    )
    participant = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        help_text="Employee rating the trainer"
    )
    rating = models.PositiveIntegerField(help_text="Rating out of 5")
    suggestions = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Trainer feedback by {self.participant.username}"


class EmployeeFeedback(models.Model):
    training_session = models.ForeignKey(
        TrainingSession, on_delete=models.CASCADE, related_name="employee_feedback"
    )
    trainer = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        help_text="Trainer providing feedback"
    )
    participant = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="feedbacks", help_text="Employee being reviewed"
    )
    feedback_text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.trainer.username}'s feedback for {self.participant.username}"


```

7. ** TrainingExecution
Model **
- Manages
the
overall
flow
of
the
training
session, including
timestamps
for start and end.

```python


class TrainingExecution(models.Model):
    training_session = models.OneToOneField(
        TrainingSession, on_delete=models.CASCADE, related_name="execution"
    )
    started_at = models.DateTimeField(null=True, blank=True, help_text="Session start time")
    ended_at = models.DateTimeField(null=True, blank=True, help_text="Session end time")

    def __str__(self):
        return f"Execution status of {self.training_session.course.title}"


```

### Workflow Summary

1. ** Session
Setup: **
- The ** Trainer ** or ** Trainer
Admin ** schedules
a
`TrainingSession`.

2. ** Session
Execution: **
- When
the
session
begins, the ** Trainer ** marks
it as started in `TrainingExecution`.
- The ** Trainer ** controls
attendance,
break
times, assignments, and feedback
sessions.

3. ** End
of
Session: **
- The ** Trainer ** marks
the
session as completed
by
ending
it in `TrainingExecution`.
- Feedback
forms
for training, trainer, and employees are submitted.

This
setup
captures
each
step and allows
easy
tracking
of
training
progress, participation, feedback, and completion
status.Let
me
know if there
are
additional
requirements!
---------
from rest_framework import serializers
from .models import TrainingRequest, Course


class CourseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Course
        fields = ['id', 'name', 'description']  # Add any other fields you need from Course


class TrainingRequestSerializer(serializers.ModelSerializer):
    course = CourseSerializer()  # Nest the CourseSerializer for detailed course info
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    requester_info = serializers.SerializerMethodField()
    receiver_info = serializers.SerializerMethodField()
    employee_info = serializers.SerializerMethodField()

    class Meta:
        model = TrainingRequest
        fields = [
            'id', 'course', 'requester', 'receiver', 'preferred_mode',
            'employees', 'additional_notes', 'status', 'status_display',
            'requester_info', 'receiver_info', 'employee_info'
        ]

    def get_requester_info(self, obj):
        return obj.get_requester_info()  # You can customize this based on your requirements

    def get_receiver_info(self, obj):
        return obj.get_receiver_info()  # You can customize this based on your requirements

    def get_employee_info(self, obj):
        # Assuming `request` is available in context, you can pass it here
        request = self.context.get('request')
        return obj.get_employee_info(request)



# class TrainingSchedule(models.Model):
#     MODE_CHOICES = [
#         ('online', 'Online'),
#         ('offline', 'Offline'),
#         ('self-learning', 'Self-learning')
#     ]
#     training_request = models.OneToOneField(
#         TrainingRequest, on_delete=models.SET_NULL, null=True, blank=True,
#         related_name="scheduled_session", help_text="Related request if initiated by HOD"
#     )
#     course = models.CharField(max_length=255)
#     preferred_mode = models.CharField(max_length=20, choices=MODE_CHOICES, help_text="Requested training mode")
#     employees = models.CharField(max_length=1024, help_text="Participants requested for training")
#     trainers = models.CharField(max_length=255)
#     room = models.ForeignKey(TrainingRooms, related_name='scheduled_trainings', on_delete=models.SET_NULL, null=True, blank=True,
#         help_text="Room or online platform for offline or online mode")
#     scheduled_date = models.DateField()
#     start_time = models.TimeField()
#     end_time = models.TimeField()
#     duration_hours = models.PositiveIntegerField()
#     additional_notes = models.TextField(blank=True)
#
#     def save(self, *args, **kwargs):
#         super().save(*args, **kwargs)
#         # Mark room as not available for the scheduled date
#         RoomAvailability.objects.update_or_create(
#             room=self.room,
#             date=self.scheduled_date,
#             defaults={'is_available': False}
#         )
#         # Mark trainers as not available for the scheduled date
#         for trainer in self.trainers.all():
#             TrainerAvailability.objects.update_or_create(trainer=trainer, scheduled_date=self.scheduled_date,
#                                                          defaults={'is_available': False})
#
#     def __str__(self):
#         return f"{self.request.course.name} - {', '.join([trainer.username for trainer in self.trainers.all()])}"
#

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Course, Module, VideoLesson, Material
from .serializers import CourseSerializer, ModuleSerializer, VideoLessonSerializer, MaterialSerializer


class CourseCreateView(APIView):
    def post(self, request, *args, **kwargs):
        course_data = request.data.get('course')
        modules_data = request.data.get('modules', [])

        # Create Course
        course_serializer = CourseSerializer(data=course_data)
        if course_serializer.is_valid():
            course = course_serializer.save()

            # Create Modules
            for module_data in modules_data:
                module_data['course'] = course.id  # Associate module with the created course
                module_serializer = ModuleSerializer(data=module_data)
                if module_serializer.is_valid():
                    module_serializer.save()

                    # Create Video Lessons
                    videos_data = module_data.get('video_lessons', [])
                    for video_data in videos_data:
                        video_data['module'] = module_serializer.instance.id  # Associate video with the created module
                        video_serializer = VideoLessonSerializer(data=video_data)
                        if video_serializer.is_valid():
                            video_serializer.save()

                    # Create Materials
                    materials_data = module_data.get('materials', [])
                    for material_data in materials_data:
                        material_data[
                            'module'] = module_serializer.instance.id  # Associate material with the created module
                        material_serializer = MaterialSerializer(data=material_data)
                        if material_serializer.is_valid():
                            material_serializer.save()
                else:
                    return Response(module_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            return Response(course_serializer.data, status=status.HTTP_201_CREATED)
        return Response(course_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
-------
from rest_framework import serializers
from .models import (
    Course,
    Module,
    VideoLesson,
    Material,
    DifficultyLevel,
    CourseCategory,
    CourseReview
)


class DifficultyLevelSerializer(serializers.ModelSerializer):
    class Meta:
        model = DifficultyLevel
        fields = ['id', 'name']


class CourseCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CourseCategory
        fields = ['id', 'name', 'image', 'description', 'category_status']


class VideoLessonSerializer(serializers.ModelSerializer):
    class Meta:
        model = VideoLesson
        fields = [
            'id', 'module', 'title', 'video_url', 'cover_image',
            'description', 'duration', 'order', 'status'
        ]

    def validate_video_url(self, value):
        if value.size > 50 * 1024 * 1024:
            raise serializers.ValidationError("Video file size cannot exceed 50MB.")
        return value

    def validate(self, data):
        if data['order'] < 0:
            raise serializers.ValidationError("Order cannot be negative.")
        return data


class MaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = Material
        fields = ['id', 'module', 'title', 'file', 'description', 'status']

    def validate_file(self, value):
        if value.size > 10 * 1024 * 1024:
            raise serializers.ValidationError("File size cannot exceed 10MB.")
        return value


class ModuleSerializer(serializers.ModelSerializer):
    video_lessons = VideoLessonSerializer(many=True, required=False)
    materials = MaterialSerializer(many=True, required=False)

    class Meta:
        model = Module
        fields = [
            'id', 'title', 'description', 'cover_image', 'order',
            'course', 'status', 'video_lessons', 'materials'
        ]

    def validate_order(self, value):
        if value < 0:
            raise serializers.ValidationError("Order cannot be negative.")
        return value

    def create(self, validated_data):
        video_lessons_data = validated_data.pop('video_lessons', [])
        materials_data = validated_data.pop('materials', [])
        module = Module.objects.create(**validated_data)

        for lesson_data in video_lessons_data:
            VideoLesson.objects.create(module=module, **lesson_data)

        for material_data in materials_data:
            Material.objects.create(module=module, **material_data)

        return module

    def update(self, instance, validated_data):
        video_lessons_data = validated_data.pop('video_lessons', [])
        materials_data = validated_data.pop('materials', [])

        instance = super().update(instance, validated_data)

        for lesson_data in video_lessons_data:
            lesson_id = lesson_data.get('id')
            if lesson_id:
                lesson_instance = VideoLesson.objects.get(id=lesson_id, module=instance)
                for attr, value in lesson_data.items():
                    setattr(lesson_instance, attr, value)
                lesson_instance.save()
            else:
                VideoLesson.objects.create(module=instance, **lesson_data)

        for material_data in materials_data:
            material_id = material_data.get('id')
            if material_id:
                material_instance = Material.objects.get(id=material_id, module=instance)
                for attr, value in material_data.items():
                    setattr(material_instance, attr, value)
                material_instance.save()
            else:
                Material.objects.create(module=instance, **material_data)

        return instance


class CourseSerializer(serializers.ModelSerializer):
    modules = ModuleSerializer(many=True, required=False)
    category = CourseCategorySerializer(read_only=True)
    prerequisites = serializers.PrimaryKeyRelatedField(
        many=True, queryset=Course.objects.all(), required=False
    )

    class Meta:
        model = Course
        fields = [
            'id', 'title', 'slug', 'description', 'category', 'cover_image',
            'duration', 'difficulty_level', 'prerequisites', 'certification',
            'learning_objectives', 'status', 'modules'
        ]
        read_only_fields = ['slug']

    def validate_title(self, value):
        if Course.objects.filter(title__iexact=value).exists():
            raise serializers.ValidationError("A course with this title already exists.")
        return value

    def create(self, validated_data):
        modules_data = validated_data.pop('modules', [])
        prerequisites = validated_data.pop('prerequisites', [])
        course = Course.objects.create(**validated_data)
        course.prerequisites.set(prerequisites)

        for module_data in modules_data:
            ModuleSerializer().create({**module_data, 'course': course})

        return course

    def update(self, instance, validated_data):
        modules_data = validated_data.pop('modules', [])
        prerequisites = validated_data.pop('prerequisites', [])

        instance = super().update(instance, validated_data)
        instance.prerequisites.set(prerequisites)

        for module_data in modules_data:
            module_id = module_data.get('id')
            if module_id:
                module_instance = Module.objects.get(id=module_id, course=instance)
                ModuleSerializer().update(module_instance, module_data)
            else:
                ModuleSerializer().create({**module_data, 'course': instance})

        return instance

# from rest_framework import serializers
# from .models import ForumCategory, ForumPost, Tag, Answers, Comments, Vote
#
#
# class ForumCategorySerializer(serializers.ModelSerializer):
#     class Meta:
#         model = ForumCategory
#         fields = ['id', 'name']
#
#
# class TagSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Tag
#         fields = ['id', 'name']
#
#
# class ForumPostSerializer(serializers.ModelSerializer):
#     author_details = serializers.SerializerMethodField()
#
#     class Meta:
#         model = ForumPost
#         fields = ['id', 'title', 'content', 'category', 'is_answered', 'views', 'tags', 'author_details']
#
#     def get_author_details(self, obj):
#         return obj.get_author_details()
#
#
# class AnswerSerializer(serializers.ModelSerializer):
#     author_details = serializers.SerializerMethodField()
#
#     class Meta:
#         model = Answers
#         fields = ['id', 'content', 'author', 'upvotes', 'downvotes', 'author_details']
#
#     def get_author_details(self, obj):
#         return obj.get_author_details()
#
#
# class CommentSerializer(serializers.ModelSerializer):
#     commenter_details = serializers.SerializerMethodField()
#
#     class Meta:
#         model = Comments
#         fields = ['id', 'content', 'commenter', 'commenter_details', 'post', 'answer']
#
#     def get_commenter_details(self, obj):
#         return obj.get_commenter_details()
#
#
# class VoteSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Vote
#         fields = ['id', 'user', 'post', 'answer', 'vote_type']
# -------------
#
# Core Functionalities Needed:
# Forum Categories:
#
# List all forum categories.
# Forum Posts:
#
# Create a new forum post.
# List all forum posts (with filtering by category or tags).
# Retrieve details of a single post (including answers, comments, and views).
# Update a forum post.
# Delete a forum post.
# Answers:
#
# Add an answer to a forum post.
# Retrieve answers for a post.
# Update an answer.
# Delete an answer.
# Comments:
#
# Add a comment on a post or answer.
# Retrieve comments for a post or answer.
# Update a comment.
# Delete a comment.
# Voting:
#
# Upvote or downvote a post or answer.
# Retrieve votes for a post or answer.
# Utility:
#
# Retrieve author, commenter, or voter details from the centralized authentication system.
#
# from rest_framework import generics
# from .models import ForumCategory
# from .serializers import ForumCategorySerializer
#
# class ForumCategoryListView(generics.ListAPIView):
#     queryset = ForumCategory.objects.all()
#     serializer_class = ForumCategorySerializer
#
#
# from rest_framework import generics, permissions
# from .models import ForumPost
# from .serializers import ForumPostSerializer
#
# class ForumPostListView(generics.ListCreateAPIView):
#     queryset = ForumPost.objects.all().select_related('category').prefetch_related('tags')
#     serializer_class = ForumPostSerializer
#     permission_classes = [permissions.IsAuthenticated]
#
#     def perform_create(self, serializer):
#         serializer.save(created_by=self.request.user.username)
#
#
# class ForumPostDetailView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = ForumPost.objects.all()
#     serializer_class = ForumPostSerializer
#     permission_classes = [permissions.IsAuthenticated]
#
#     def perform_update(self, serializer):
#         serializer.save(updated_by=self.request.user.username)
#
#
# class ForumPostIncreaseViews(generics.UpdateAPIView):
#     queryset = ForumPost.objects.all()
#     serializer_class = ForumPostSerializer
#     permission_classes = [permissions.IsAuthenticated]
#
#     def update(self, request, *args, **kwargs):
#         instance = self.get_object()
#         instance.views += 1
#         instance.save()
#         return Response({'status': 'views increased'})
#
#
#
# from rest_framework import generics, permissions
# from .models import ForumPost
# from .serializers import ForumPostSerializer
#
# class ForumPostCreateView(generics.CreateAPIView):
#     queryset = ForumPost.objects.all()
#     serializer_class = ForumPostSerializer
#     permission_classes = [permissions.IsAuthenticated]
#
#     def perform_create(self, serializer):
#         # Sets the created_by field to the current authenticated user
#         serializer.save(created_by=self.request.user.username)
#
# from .models import Answers
# from .serializers import AnswerSerializer
#
# class AnswerListView(generics.ListCreateAPIView):
#     queryset = Answers.objects.all()
#     serializer_class = AnswerSerializer
#     permission_classes = [permissions.IsAuthenticated]
#
#     def perform_create(self, serializer):
#         serializer.save(created_by=self.request.user.username)
#
#
# class AnswerDetailView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = Answers.objects.all()
#     serializer_class = AnswerSerializer
#     permission_classes = [permissions.IsAuthenticated]
#
#     def perform_update(self, serializer):
#         serializer.save(updated_by=self.request.user.username)
#
# from .models import Comments
# from .serializers import CommentSerializer
#
# class CommentListView(generics.ListCreateAPIView):
#     queryset = Comments.objects.all()
#     serializer_class = CommentSerializer
#     permission_classes = [permissions.IsAuthenticated]
#
#     def perform_create(self, serializer):
#         serializer.save(created_by=self.request.user.username)
#
#
# class CommentDetailView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = Comments.objects.all()
#     serializer_class = CommentSerializer
#     permission_classes = [permissions.IsAuthenticated]
#
#     def perform_update(self, serializer):
#         serializer.save(updated_by=self.request.user.username)
#
# from .models import Vote
# from .serializers import VoteSerializer
#
# class VoteListView(generics.ListCreateAPIView):
#     queryset = Vote.objects.all()
#     serializer_class = VoteSerializer
#     permission_classes = [permissions.IsAuthenticated]
#
#     def perform_create(self, serializer):
#         serializer.save(created_by=self.request.user.username)
#
#
# class VoteDetailView(generics.RetrieveUpdateDestroyAPIView):
#     queryset = Vote.objects.all()
#     serializer_class = VoteSerializer
#     permission_classes = [permissions.IsAuthenticated]
#
# from django.urls import path
# from . import views
#
# urlpatterns = [
#     # Forum categories
#     path('categories/', views.ForumCategoryListView.as_view(), name='forum-category-list'),
#
#     # Forum posts
#     path('posts/', views.ForumPostListView.as_view(), name='forum-post-list'),
#     path('posts/<uuid:pk>/', views.ForumPostDetailView.as_view(), name='forum-post-detail'),
#     path('posts/<uuid:pk>/increase-views/', views.ForumPostIncreaseViews.as_view(), name='forum-post-increase-views'),
#
#     # Answers
#     path('answers/', views.AnswerListView.as_view(), name='answer-list'),
#     path('answers/<uuid:pk>/', views.AnswerDetailView.as_view(), name='answer-detail'),
#
#     # Comments
#     path('comments/', views.CommentListView.as_view(), name='comment-list'),
#     path('comments/<uuid:pk>/', views.CommentDetailView.as_view(), name='comment-detail'),
#
#     # Votes
#     path('votes/', views.VoteListView.as_view(), name='vote-list'),
#     path('votes/<uuid:pk>/', views.VoteDetailView.as_view(), name='vote-detail'),
# ]

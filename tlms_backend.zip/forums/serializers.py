from rest_framework import serializers
from .models import *

class ForumCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = ForumCategory
        fields = ['id', 'name', 'created_at','updated_at','created_by','updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']



class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ['id', 'name','created_at','updated_at','created_by','updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class ForumPostSerializer(serializers.ModelSerializer):
    author_details = serializers.SerializerMethodField()

    class Meta:
        model = ForumPost
        fields = ['id', 'title', 'content', 'category', 'is_answered', 'views', 'tags', 'author_details', 'created_at','updated_at','created_by','updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']

    def get_author_details(self, obj):
        return obj.get_author_details()


class AnswerSerializer(serializers.ModelSerializer):
    author_details = serializers.SerializerMethodField()

    class Meta:
        model = Answers
        fields = ['id', 'content', 'author', 'upvotes', 'downvotes', 'author_details', 'created_at','updated_at','created_by','updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']

    def get_author_details(self, obj):
        return obj.get_author_details()


class CommentSerializer(serializers.ModelSerializer):
    commenter_details = serializers.SerializerMethodField()

    class Meta:
        model = Comments
        fields = ['id', 'content', 'commenter', 'commenter_details', 'post', 'answer', 'created_at','updated_at','created_by','updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']

    def get_commenter_details(self, obj):
        return obj.get_commenter_details()


class VoteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vote
        fields = ['id', 'user', 'post', 'answer', 'vote_type', 'created_at','updated_at','created_by','updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']

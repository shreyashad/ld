from django.urls import path
from .views import *

urlpatterns = [
    path('forum-categories/', ForumCategoryListView.as_view(), name='forum_category_list'),
    path('create-forum-category', ForumCategoryCreateView.as_view(), name='create_forum_category'),
    path('forum-category/<uuid:pk>/details/', ForumCategoryDetailView.as_view(), name='forum_category_details'),
    path('forum-posts/', FormPostListView.as_view(), name='forum_post_list'),
    path('create-forum-post',FormPostCreateView.as_view(), name='create_forum_post'),
    path('forum-posts/<uuid:pk>/details/', FormPostDetailsView.as_view(), name='forum_post_details'),
    path('forum-posts/<uuid:pk>/increase-views/', ForumPostIncreaseViews.as_view(), name='forum_post_increase_views'),
    path('forum-post-answers/', PostAnswersListView.as_view(), name='forum_post_answer_list'),
    path('create-forum-post-answer', PostAnswerCreateView.as_view(), name='create_forum_post_answer'),
    path('forum-post-answers/<uuid:pk>/details/', PostAnswerDetailView.as_view(), name='forum_post_answer_details'),
    path('forum-comments/', PostCommentListView.as_view(), name='forum_post_comments_list'),
    path('create-form-comment/', PostCommentCreateView.as_view(), name='create_forum_post_comments'),
    path('forum-comments/<uuid:pk>/details/', PostCommentDetails.as_view(), name='forum_post_comments_details'),
    path('forum-votes/', PostAnswerVoteListView.as_view(), name='forum_votes_list'),
    path('create-forum-votes/', PostAnswerVoteCreateView.as_view(), name='create_forum_vote'),
    path('forum-votes/<uuid:pk>/details/', PostAnswerVoteDetailView.as_view(), name='forum_votes_details'),

]
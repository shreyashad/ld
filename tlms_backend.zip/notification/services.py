import requests
from django.conf import settings


def send_notification_to_employees(training_request):
    employee_ids = training_request.get_employee_list()  # Assume this method exists
    auth_server_url = f"{settings.AUTH_SERVER_BASE_URL}/api/notifications/"  # Adjust the endpoint as needed

    title = f"Training Scheduled: {training_request.course}"
    message = (
        f"A new training session has been scheduled for the course: {training_request.course}. "
        f"Mode: {training_request.mode}. "
        f"Status: {training_request.status}."
    )

    for employee_id in employee_ids:
        payload = {
            "user": employee_id,
            "application": "Your Application Name",  # Adjust as needed
            "title": title,
            "message": message,
            "notification_type": "info",
        }

        response = requests.post(auth_server_url, json=payload)

        if response.status_code != 201:
            # Handle error (e.g., log it)
            print(f"Failed to send notification to {employee_id}: {response.content}")

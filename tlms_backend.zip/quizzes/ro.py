# views.py

from rest_framework import generics, status
from rest_framework.response import Response
from .models import StudentSubmission, StudentAnswer, Question, Quiz
from .serializers import StudentSubmissionSerializer, StudentAnswerSerializer
from rest_framework.permissions import IsAuthenticated
from .authentication import CustomCASAuthentication


class StudentSubmissionCreateAPIView(generics.CreateAPIView):
    queryset = StudentSubmission.objects.all()
    serializer_class = StudentSubmissionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        quiz_id = self.request.data.get('quiz')
        # Check if the quiz exists and is active, handle logic here
        # Optionally: Check if the student already has a submission
        serializer.save(student_id=self.request.user.id)  # Assuming user ID is used for student_id


class StudentAnswerCreateAPIView(generics.CreateAPIView):
    queryset = StudentAnswer.objects.all()
    serializer_class = StudentAnswerSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        submission_id = self.request.data.get('submission')
        # You can add additional validations here
        serializer.save()  # Save the answer


class StudentSubmissionRetrieveAPIView(generics.RetrieveAPIView):
    queryset = StudentSubmission.objects.all()
    serializer_class = StudentSubmissionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class StudentSubmissionListAPIView(generics.ListAPIView):
    serializer_class = StudentSubmissionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        quiz_id = self.kwargs['quiz_id']
        return StudentSubmission.objects.filter(quiz_id=quiz_id, student_id=self.request.user.id)


class StudentSubmissionSubmitAnswersAPIView(generics.UpdateAPIView):
    queryset = StudentSubmission.objects.all()
    serializer_class = StudentSubmissionSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def update(self, request, *args, **kwargs):
        submission = self.get_object()
        answers_data = request.data.get('answers', [])

        # Process each answer and save it
        for answer_data in answers_data:
            question_id = answer_data.get('question')
            answer_text = answer_data.get('answer_text')
            StudentAnswer.objects.create(
                submission=submission,
                question_id=question_id,
                answer_text=answer_text
            )

        # Calculate marks and update the submission record
        self.calculate_marks(submission)
        return Response({'status': 'answers submitted'}, status=status.HTTP_201_CREATED)

    def calculate_marks(self, submission):
        # Logic to calculate total marks based on answers
        total_marks = 0
        # Example: Loop through answers and calculate marks
        for answer in submission.answers.all():
            # Implement your scoring logic here
            # e.g., if answer is correct, add to total_marks
            pass

        submission.marks_obtained = total_marks
        submission.graded = True
        submission.save()

-------
from rest_framework import serializers
from .models import Quiz, Question, QuestionType, MultipleChoiceOption, FillInTheBlanksAnswer, TrueFalseAnswer, \
    OrderingItem, ShortAnswerResponse


class QuizSerializer(serializers.ModelSerializer):
    questions = QuestionSerializer(many=True, required=False)  # Nested serialization for questions

    class Meta:
        model = Quiz
        fields = ['id', 'title', 'course', 'description', 'duration', 'total_marks', 'pass_marks', 'questions']
        read_only_fields = ['id']

    def create(self, validated_data):
        # Extract the questions data from the validated data
        questions_data = validated_data.pop('questions', [])

        # Create the Quiz object
        quiz = Quiz.objects.create(**validated_data)

        # Handle creating each question and its associated answers/options
        for question_data in questions_data:
            # Extract and handle the question type
            question_type_data = question_data.pop('question_type')
            question_type, _ = QuestionType.objects.get_or_create(
                **question_type_data)  # Create or get existing QuestionType

            # Create the Question object
            question = Question.objects.create(quiz=quiz, question_type=question_type, **question_data)

            # Handle different question types and their associated data
            if question_type.name == 'MultipleChoice':
                # Multiple Choice question - create options
                options_data = question_data.get('options', [])
                for option_data in options_data:
                    MultipleChoiceOption.objects.create(question=question, **option_data)

            elif question_type.name == 'FillInTheBlanks':
                # Fill-in-the-Blanks question - create the correct answers
                answers_data = question_data.get('answers', [])
                for answer_data in answers_data:
                    FillInTheBlanksAnswer.objects.create(question=question, **answer_data)

            elif question_type.name == 'TrueFalse':
                # True/False question - create the true/false answer
                true_false_data = question_data.get('true_false_answer', {})
                TrueFalseAnswer.objects.create(question=question, **true_false_data)

            elif question_type.name == 'Ordering':
                # Ordering question - create ordering items
                ordering_items_data = question_data.get('ordering_items', [])
                for ordering_item_data in ordering_items_data:
                    OrderingItem.objects.create(question=question, **ordering_item_data)

            elif question_type.name == 'ShortAnswer':
                # Short Answer question - create the correct response
                short_answer_responses_data = question_data.get('short_answer_responses', [])
                for short_answer_data in short_answer_responses_data:
                    ShortAnswerResponse.objects.create(question=question, **short_answer_data)

            # You can add more question types and their respective creation logic here as necessary

        # Return the created quiz instance
        return quiz
